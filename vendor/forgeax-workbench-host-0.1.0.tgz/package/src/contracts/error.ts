import { z } from "zod"

export const WorkbenchErrorDataSchema = z.object({
  code: z.string().min(1),
  target: z.string().min(1),
  message: z.string().min(1),
  retryable: z.boolean(),
  details: z.unknown().optional(),
})

export type WorkbenchErrorData = z.infer<typeof WorkbenchErrorDataSchema>

export const WorkbenchErrorEnvelopeSchema = z.object({
  ok: z.literal(false),
  error: WorkbenchErrorDataSchema,
})

export type WorkbenchErrorEnvelope = z.infer<typeof WorkbenchErrorEnvelopeSchema>

export class WorkbenchError extends Error {
  readonly code: string
  readonly target: string
  readonly retryable: boolean
  readonly details: unknown

  constructor(data: unknown) {
    const parsed = WorkbenchErrorDataSchema.parse(data)
    super(parsed.message)
    this.name = "WorkbenchError"
    this.code = parsed.code
    this.target = parsed.target
    this.retryable = parsed.retryable
    this.details = parsed.details
  }
}

export function toErrorEnvelope(error: unknown): WorkbenchErrorEnvelope {
  if (error instanceof WorkbenchError) {
    const data = {
      code: error.code,
      target: error.target,
      message: error.message,
      retryable: error.retryable,
      ...(error.details === undefined ? {} : { details: error.details }),
    }
    return WorkbenchErrorEnvelopeSchema.parse({ ok: false, error: data })
  }

  const parsedEnvelope = WorkbenchErrorEnvelopeSchema.safeParse(error)
  if (parsedEnvelope.success) {
    return parsedEnvelope.data
  }

  return {
    ok: false,
    error: {
      code: "internal_error",
      target: "host",
      message: "Unexpected workbench host error",
      retryable: false,
    },
  }
}
