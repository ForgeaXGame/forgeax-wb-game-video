export interface GameVersion {
  tag: string
  commitHash: string
  message: string
  createdAt: string
}

export interface CurrentVersion {
  tag: string
  commitHash: string
  dirty: boolean
}

export interface WorkspaceAdapter {
  resolveGameRoot(gameId: string): Promise<string>
}

export interface VersionAdapter {
  ensureRepository(gameRoot: string): Promise<void>
  createVersion(gameRoot: string, message: string): Promise<GameVersion>
  currentVersion(gameRoot: string): Promise<CurrentVersion | null>
  listVersions(gameRoot: string): Promise<GameVersion[]>
  readFileAtVersion(
    gameRoot: string,
    tag: string,
    relativePath: string,
  ): Promise<Uint8Array | null>
}

export type MediaType = "audio" | "image" | "video"

export interface MediaQuery {
  type?: MediaType
  cursor?: string
  limit?: number
}

export interface MediaAsset {
  id: string
  type: MediaType
  url: string
  contentType: string
  sizeBytes?: number
  metadata?: Record<string, unknown>
}

export interface MediaBody {
  contentType: string
  bytes: Uint8Array
}

export interface MediaWriteInput {
  filename: string
  contentType: string
  bytes: Uint8Array
  metadata?: Record<string, unknown>
}

export interface MediaCapability {
  list(gameId: string, query?: MediaQuery): Promise<MediaAsset[]>
  read(gameId: string, assetId: string): Promise<MediaBody | null>
  put(gameId: string, input: MediaWriteInput): Promise<MediaAsset>
}

export interface MediaReference {
  assetId?: string
  url?: string
}

export interface TextGenerationInput {
  prompt: string
  system?: string
  model?: string
  temperature?: number
  maxTokens?: number
  metadata?: Record<string, unknown>
}

export interface TextGenerationResult {
  text: string
  model?: string
  usage?: {
    inputTokens?: number
    outputTokens?: number
  }
  metadata?: Record<string, unknown>
}

export interface ImageGenerationInput {
  prompt: string
  references?: MediaReference[]
  model?: string
  aspectRatio?: string
  metadata?: Record<string, unknown>
}

export interface ImageGenerationResult {
  assets: MediaAsset[]
  model?: string
  metadata?: Record<string, unknown>
}

export interface VideoGenerationInput {
  prompt: string
  references?: MediaReference[]
  model?: string
  durationSeconds?: number
  aspectRatio?: string
  metadata?: Record<string, unknown>
}

export interface VideoGenerationResult {
  assets: MediaAsset[]
  model?: string
  metadata?: Record<string, unknown>
}

export interface ModelGateway {
  generateText(input: TextGenerationInput): Promise<TextGenerationResult>
  generateImage(input: ImageGenerationInput): Promise<ImageGenerationResult>
  generateVideo(input: VideoGenerationInput): Promise<VideoGenerationResult>
}
