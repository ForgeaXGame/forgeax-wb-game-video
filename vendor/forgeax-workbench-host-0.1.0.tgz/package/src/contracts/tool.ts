import { z } from "zod"

import { WorkbenchErrorEnvelopeSchema } from "./error.js"
import { isWorkbenchIdentifier } from "./identifier.js"

export const ToolCallInputSchema = z.object({
  caller: z.enum(["ui", "ai"]),
  toolId: z.string().min(1),
  gameId: z.string().refine(isWorkbenchIdentifier, "Invalid game id"),
  args: z.unknown(),
})

export type ToolCallInput = z.infer<typeof ToolCallInputSchema>

export const ToolCallResultSchema = z.union([
  z.object({
    ok: z.literal(true),
    result: z.unknown(),
  }),
  WorkbenchErrorEnvelopeSchema,
])

export type ToolCallResult = z.infer<typeof ToolCallResultSchema>
