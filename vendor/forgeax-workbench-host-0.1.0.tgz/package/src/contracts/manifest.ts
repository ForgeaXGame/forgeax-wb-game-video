import { z } from "zod"

const EntrySchema = z
  .object({
    frontend: z.string().min(1),
    backend: z.string().min(1),
  })
  .passthrough()

const PaneSchema = z
  .object({
    minWidth: z.number().finite().nonnegative(),
  })
  .passthrough()

const WorkbenchPanesSchema = z
  .object({
    left: PaneSchema,
  })
  .passthrough()

export const ToolDescriptorSchema = z
  .object({
    id: z.string().min(1),
    title: z.string().min(1).optional(),
    description: z.string().min(1).optional(),
    inputSchema: z.string().min(1),
    outputSchema: z.string().min(1).optional(),
    permissions: z.array(z.string().min(1)).optional(),
  })
  .passthrough()

export type ToolDescriptor = z.infer<typeof ToolDescriptorSchema>

export const WorkbenchManifestSchema = z
  .object({
    kind: z.literal("workbench"),
    id: z.string().min(1),
    version: z.string().min(1),
    displayName: z.string().min(1),
    entry: EntrySchema,
    provides: z
      .object({
        workbench: z
          .object({
            panes: WorkbenchPanesSchema,
          })
          .passthrough(),
      })
      .passthrough(),
    permissions: z.array(z.string().min(1)),
    requestedEnv: z.array(z.string().min(1)),
    tools: z.array(ToolDescriptorSchema),
  })
  .passthrough()

export type WorkbenchManifest = z.infer<typeof WorkbenchManifestSchema>
