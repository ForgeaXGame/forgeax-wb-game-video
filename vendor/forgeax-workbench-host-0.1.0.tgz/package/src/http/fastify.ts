import type { FastifyInstance } from "fastify"

import { createWorkbenchHttpHandler, isBodylessStatus, MAX_WORKBENCH_REQUEST_BODY_BYTES, stripMountPrefix, type WorkbenchHttpHost } from "./common.js"

export interface FastifyWorkbenchHostOptions { readonly prefix?: string }

/** Registers a scoped raw-body transport projection; it does not implement host business logic. */
export async function registerFastifyWorkbenchHost(app: FastifyInstance, host: WorkbenchHttpHost, options: FastifyWorkbenchHostOptions = {}): Promise<void> {
  const prefix = options.prefix ?? ""
  const handler = createWorkbenchHttpHandler(host)
  await app.register(async (scope) => {
    const parseRaw = (_request: unknown, body: string | Buffer, done: (error: Error | null, value?: unknown) => void) => done(null, new Uint8Array(typeof body === "string" ? Buffer.from(body) : body))
    scope.addContentTypeParser("application/json", { parseAs: "buffer" }, parseRaw)
    scope.addContentTypeParser("*", { parseAs: "buffer" }, parseRaw)
    scope.setErrorHandler((error, _request, reply) => {
      if ((error as { code?: string }).code === "FST_ERR_CTP_BODY_TOO_LARGE") return reply.code(413).type("application/json; charset=utf-8").send({ ok: false, error: { code: "request_too_large", target: "http", message: "Request body is too large", retryable: false } })
      throw error
    })
    scope.all(`${prefix}/*`, { bodyLimit: MAX_WORKBENCH_REQUEST_BODY_BYTES }, async (request, reply) => {
      const response = await handler({ method: request.method, path: stripMountPrefix(request.raw.url ?? request.url, prefix), headers: request.headers as Record<string, string | undefined>, body: request.body instanceof Uint8Array ? request.body : new Uint8Array() })
      for (const [name, value] of Object.entries(response.headers)) reply.header(name, value)
      if (request.method === "HEAD" || isBodylessStatus(response.status)) return reply.code(response.status).send()
      return reply.code(response.status).send(Buffer.from(response.body))
    })
  })
}
