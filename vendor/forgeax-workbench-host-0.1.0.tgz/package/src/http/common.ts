import { createHash } from "node:crypto"
import { lstat, readFile, realpath, stat } from "node:fs/promises"
import { basename, extname, isAbsolute, relative, resolve, sep } from "node:path"

import { WorkbenchError, toErrorEnvelope, type WorkbenchErrorEnvelope } from "../contracts/error.js"
import { isWorkbenchIdentifier } from "../contracts/identifier.js"

export const MAX_WORKBENCH_REQUEST_BODY_BYTES = 1_048_576

export interface WorkbenchHttpRequest {
  readonly method: string
  readonly path: string
  readonly headers?: Readonly<Record<string, string | undefined>>
  readonly body?: Uint8Array<ArrayBufferLike>
  /** Test-only convenience; production adapters always supply raw body bytes. */
  readonly json?: unknown
}

export interface WorkbenchHttpResponse {
  readonly status: number
  readonly headers: Readonly<Record<string, string | readonly string[]>>
  readonly body: Uint8Array<ArrayBufferLike>
  readonly json?: unknown
}

export interface ExtensionHttpRequest {
  readonly gameId: string
  readonly runtimeId: string
  readonly path: string
  readonly query: Readonly<Record<string, readonly string[]>>
  readonly method: string
  readonly headers: Readonly<Record<string, readonly string[]>>
  readonly body: Uint8Array<ArrayBufferLike>
}

export interface ExtensionHttpResponse {
  readonly status: number
  readonly headers?: Readonly<Record<string, string | readonly string[]>>
  readonly body?: Uint8Array<ArrayBufferLike>
}

/** A bounded static projection. Denied paths are relative files or directory prefixes. */
export interface StaticFileRoot {
  readonly root: string
  readonly deniedRelativePaths?: readonly string[]
  readonly deniedFileExtensions?: readonly string[]
  readonly deniedFileNames?: readonly string[]
  readonly deniedFilePrefixes?: readonly string[]
}

/** The complete, product-neutral host surface projected by every HTTP framework. */
export interface WorkbenchHttpHost {
  catalog(gameId: string): Promise<unknown> | unknown
  listTools(gameId: string): Promise<unknown> | unknown
  callTool(input: unknown): Promise<unknown> | unknown
  packageStatus(gameId: string): Promise<unknown> | unknown
  initializePackage(gameId: string, runtimeId: string): Promise<unknown> | unknown
  readPackage(gameId: string): Promise<unknown> | unknown
  updatePackage(gameId: string, value: unknown): Promise<unknown> | unknown
  createVersion(gameId: string, message: string): Promise<unknown> | unknown
  listVersions(gameId: string): Promise<unknown> | unknown
  currentVersion(gameId: string): Promise<unknown> | unknown
  readVersionPackage(gameId: string, tag: string): Promise<unknown> | unknown
  runtimeRoot(runtimeId: string): Promise<StaticFileRoot | null> | StaticFileRoot | null
  componentFile(
    gameId: string,
    relativePath: string,
  ): Promise<Uint8Array<ArrayBufferLike> | null> | Uint8Array<ArrayBufferLike> | null
  extension(request: ExtensionHttpRequest): Promise<ExtensionHttpResponse> | ExtensionHttpResponse
}

const encoder = new TextEncoder()
const decoder = new TextDecoder()
const mimeTypes: Record<string, string> = {
  ".css": "text/css; charset=utf-8", ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".woff2": "font/woff2",
}

export function isBodylessStatus(status: number): boolean { return (status >= 100 && status < 200) || status === 204 || status === 205 || status === 304 }
function response(status: number, headers: Record<string, string | readonly string[]> = {}, body: Uint8Array<ArrayBufferLike> = new Uint8Array()): WorkbenchHttpResponse { return { status, headers, body: isBodylessStatus(status) ? new Uint8Array() : body } }
function jsonResponse(status: number, value: unknown): WorkbenchHttpResponse { const body = encoder.encode(JSON.stringify(value)); return { status, headers: { "content-type": "application/json; charset=utf-8", "content-length": String(body.byteLength) }, body, json: value } }
function requestError(code: string, message: string): WorkbenchError { return new WorkbenchError({ code, target: "http", message, retryable: false }) }

function statusFor(error: unknown): number {
  if (!(error instanceof WorkbenchError)) return 500
  if (["runtime_not_found", "file_not_found", "tool_not_found", "route_not_found", "version_not_found", "game_not_found", "workspace_not_found"].includes(error.code)) return 404
  if (["package_inconsistent", "package_version_pending", "package_conflict"].includes(error.code)) return 409
  if (error.code === "extension_untrusted") return 403
  if (["host_not_configured", "extension_response_invalid"].includes(error.code)) return 500
  if (error.code === "request_too_large") return 413
  return 400
}
function errorResponse(error: unknown): WorkbenchHttpResponse { return jsonResponse(statusFor(error), toErrorEnvelope(error)) }
function isRecord(value: unknown): value is Record<string, unknown> { return typeof value === "object" && value !== null && !Array.isArray(value) }

/** Decodes a path segment exactly once and rejects separators, hidden names, and traversal. */
function decodedPathSegment(value: string): string {
  let decoded: string
  try { decoded = decodeURIComponent(value) } catch { throw requestError("path_invalid", "Request path is invalid") }
  if (decoded.length === 0 || decoded === "." || decoded === ".." || decoded.startsWith(".") || decoded.includes("/") || decoded.includes("\\") || decoded.includes("\0")) throw requestError("path_forbidden", "Request path is not allowed")
  return decoded
}
/** Query values are already decoded by URLSearchParams and must never be decoded again. */
function identifier(value: string): string { if (!isWorkbenchIdentifier(value)) throw requestError("identifier_invalid", "Request identifier is invalid"); return value }
function pathIdentifier(value: string): string { return identifier(decodedPathSegment(value)) }
function versionTag(value: string): string { const decoded = decodedPathSegment(value); if (!/^[\p{L}\p{N}][\p{L}\p{N}._-]*$/u.test(decoded) || decoded.includes("%")) throw requestError("identifier_invalid", "Version tag is invalid"); return decoded }
function parsePath(raw: string): string[] {
  const pathname = raw.split("?", 1)[0] || "/"
  return pathname.split("/").filter(Boolean)
}
function parseQuery(raw: string): Readonly<Record<string, readonly string[]>> {
  const index = raw.indexOf("?"); const query = new URLSearchParams(index < 0 ? "" : raw.slice(index + 1)); const values: Record<string, string[]> = {}
  for (const [key, value] of query) { if (!/^[\p{L}\p{N}_-]+$/u.test(key) || key.startsWith(".")) throw requestError("path_forbidden", "Request path is not allowed"); (values[key] ??= []).push(value) }
  return values
}
function requestHeaders(headers: Readonly<Record<string, string | undefined>>): Readonly<Record<string, readonly string[]>> {
  const result: Record<string, string[]> = {}
  for (const [key, value] of Object.entries(headers)) if (value !== undefined) (result[key.toLowerCase()] ??= []).push(value)
  return result
}
function contained(root: string, candidate: string): boolean { const path = relative(root, candidate); return path === "" || (!isAbsolute(path) && path !== ".." && !path.startsWith(`..${sep}`)) }
function ifNoneMatch(value: string | undefined, etag: string): boolean {
  if (!value) return false
  return value.split(",").map((item) => item.trim()).some((item) => item === "*" || item.replace(/^W\//u, "") === etag)
}

function deniedStaticPath(root: string, actual: string, policy: StaticFileRoot): boolean {
  const actualRelative = relative(root, actual)
  if ((policy.deniedRelativePaths ?? []).some((value) => {
    const deniedAbsolute = resolve(root, value)
    if (!contained(root, deniedAbsolute)) throw requestError("path_forbidden", "Request path is not allowed")
    const deniedRelative = relative(root, deniedAbsolute)
    return actualRelative === deniedRelative || actualRelative.startsWith(`${deniedRelative}${sep}`)
  })) return true
  const fileName = basename(actual).toLowerCase()
  const extension = extname(fileName)
  return (policy.deniedFileExtensions ?? []).some((value) => extension === value.toLowerCase())
    || (policy.deniedFileNames ?? []).some((value) => fileName === value.toLowerCase())
    || (policy.deniedFilePrefixes ?? []).some((value) => fileName.startsWith(value.toLowerCase()))
}

function materializedStaticFile(relativePath: string, bytes: Uint8Array<ArrayBufferLike>, headers: Readonly<Record<string, readonly string[]>>, method: string): WorkbenchHttpResponse {
  const etag = `\"${createHash("sha256").update(bytes).digest("base64url")}\"`
  const base = { "content-type": mimeTypes[extname(relativePath).toLowerCase()] ?? "application/octet-stream", "content-length": String(bytes.byteLength), "accept-ranges": "bytes", etag }
  if (ifNoneMatch(headers["if-none-match"]?.join(","), etag)) return response(304, base)
  const range = headers.range?.[0]
  if (!range) return response(200, base, method === "HEAD" ? new Uint8Array() : bytes)
  const matched = /^bytes=(\d*)-(\d*)$/u.exec(range)
  if (!matched || (matched[1] === "" && matched[2] === "") || bytes.byteLength === 0) return response(416, { "content-range": `bytes */${bytes.byteLength}`, "accept-ranges": "bytes", etag })
  let start: number; let end: number
  if (matched[1] === "") { const length = Number(matched[2]); if (!Number.isSafeInteger(length) || length <= 0) return response(416, { "content-range": `bytes */${bytes.byteLength}`, "accept-ranges": "bytes", etag }); start = Math.max(0, bytes.byteLength - length); end = bytes.byteLength - 1 }
  else { start = Number(matched[1]); end = matched[2] === "" ? bytes.byteLength - 1 : Math.min(Number(matched[2]), bytes.byteLength - 1) }
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start > end || start >= bytes.byteLength) return response(416, { "content-range": `bytes */${bytes.byteLength}`, "accept-ranges": "bytes", etag })
  const body = bytes.slice(start, end + 1)
  return response(206, { ...base, "content-length": String(body.byteLength), "content-range": `bytes ${start}-${end}/${bytes.byteLength}` }, method === "HEAD" ? new Uint8Array() : body)
}

async function staticFile(policy: StaticFileRoot | null, rawParts: string[], headers: Readonly<Record<string, readonly string[]>>, method: string, missingCode: "runtime_not_found" | "file_not_found"): Promise<WorkbenchHttpResponse> {
  if (policy === null) return errorResponse(requestError(missingCode, missingCode === "runtime_not_found" ? "Runtime was not found" : "Static file was not found"))
  try {
    if (rawParts.length === 0) throw requestError("file_not_found", "Static file was not found")
    const parts = rawParts.map(decodedPathSegment)
    const root = await realpath(policy.root)
    let cursor = root
    for (const value of parts) { cursor = resolve(cursor, value); if (!contained(root, cursor)) throw requestError("path_forbidden", "Request path is not allowed"); if ((await lstat(cursor)).isSymbolicLink()) throw requestError("path_forbidden", "Request path is not allowed") }
    const actual = await realpath(cursor)
    if (!contained(root, actual) || deniedStaticPath(root, actual, policy) || !(await stat(actual)).isFile()) throw requestError("file_not_found", "Static file was not found")
    return materializedStaticFile(relative(root, actual), new Uint8Array(await readFile(actual)), headers, method)
  } catch (error) { return errorResponse(error instanceof WorkbenchError ? error : requestError("file_not_found", "Static file was not found")) }
}

function jsonBody(request: WorkbenchHttpRequest): unknown {
  if (request.json !== undefined) return request.json
  const body = request.body ?? new Uint8Array()
  if (body.byteLength === 0) return undefined
  if (!request.headers?.["content-type"]?.toLowerCase().includes("application/json")) return undefined
  try { return JSON.parse(decoder.decode(body)) as unknown } catch { throw requestError("json_invalid", "JSON request body is invalid") }
}
function publicCatalog(value: unknown): unknown {
  if (!Array.isArray(value)) throw requestError("catalog_invalid", "Workbench catalog is invalid")
  return value.map((entry) => { if (!isRecord(entry) || typeof entry.extensionId !== "string" || typeof entry.runtimeId !== "string" || typeof entry.title !== "string") throw requestError("catalog_invalid", "Workbench catalog is invalid"); const allowed = ["icon", "surface", "panes", "runtimeUrl"] as const; return Object.fromEntries([["extensionId", entry.extensionId], ["runtimeId", entry.runtimeId], ["title", entry.title], ...allowed.filter((key) => entry[key] !== undefined).map((key) => [key, entry[key]])]) })
}

/** Shared router: framework adapters supply raw input and serialize this exact response. */
export function createWorkbenchHttpHandler(host: WorkbenchHttpHost) {
  if (!host) throw new TypeError("A workbench host is required")
  return async (request: WorkbenchHttpRequest): Promise<WorkbenchHttpResponse> => {
    try {
      if ((request.body?.byteLength ?? 0) > MAX_WORKBENCH_REQUEST_BODY_BYTES) throw requestError("request_too_large", "Request body is too large")
      const parts = parsePath(request.path); const query = parseQuery(request.path); const headers = requestHeaders(request.headers ?? {}); const method = request.method.toUpperCase()
      const id = (index: number) => pathIdentifier(parts[index] ?? "")
      const queryId = (name: string, required = false) => { const value = query[name]?.[0]; if (value === undefined) { if (required) throw requestError("identifier_invalid", `A ${name} query parameter is required`); return undefined }; return identifier(value) }
      if (method === "GET" && parts.length === 1 && parts[0] === "catalog") return jsonResponse(200, publicCatalog(await host.catalog(queryId("gameId", true)!)))
      if (method === "GET" && parts.length === 1 && parts[0] === "tools") return jsonResponse(200, await host.listTools(queryId("gameId", true)!))
      if (method === "POST" && parts.join("/") === "tools/call") return jsonResponse(200, await host.callTool(jsonBody(request)))
      if ((method === "GET" || method === "HEAD") && parts[0] === "runtime" && parts.length >= 3) return staticFile(await host.runtimeRoot(id(1)), parts.slice(2), headers, method, "runtime_not_found")
      if ((method === "GET" || method === "HEAD") && parts[0] === "games" && parts[2] === "components" && parts.length >= 4) {
        const relativePath = parts.slice(3).map(decodedPathSegment).join("/")
        const bytes = await host.componentFile(id(1), relativePath)
        return bytes === null
          ? errorResponse(requestError("file_not_found", "Static file was not found"))
          : materializedStaticFile(relativePath, bytes, headers, method)
      }
      if (parts[0] === "games" && parts[2] === "package") {
        const gameId = id(1)
        if (method === "GET" && parts[3] === "status" && parts.length === 4) return jsonResponse(200, await host.packageStatus(gameId))
        if (method === "POST" && parts[3] === "initialize" && parts.length === 4) return jsonResponse(200, await host.initializePackage(gameId, queryId("runtimeId", true)!))
        if (method === "GET" && parts.length === 3) return jsonResponse(200, await host.readPackage(gameId))
        if (method === "PUT" && parts.length === 3) return jsonResponse(200, await host.updatePackage(gameId, jsonBody(request)))
      }
      if (parts[0] === "games" && parts[2] === "versions") {
        const gameId = id(1)
        if (method === "POST" && parts.length === 3) { const value = jsonBody(request); return jsonResponse(200, await host.createVersion(gameId, isRecord(value) && typeof value.message === "string" ? value.message : "")) }
        if (method === "GET" && parts.length === 3) return jsonResponse(200, await host.listVersions(gameId))
        if (method === "GET" && parts[3] === "current" && parts.length === 4) return jsonResponse(200, await host.currentVersion(gameId))
        if (method === "GET" && parts[4] === "package" && parts.length === 5) return jsonResponse(200, await host.readVersionPackage(gameId, versionTag(parts[3] ?? "")))
      }
      if (parts[0] === "extension" && parts.length >= 2) { const extension = await host.extension({ gameId: queryId("gameId", true)!, runtimeId: id(1), path: parts.slice(2).map(decodedPathSegment).join("/"), query, method, headers, body: Uint8Array.from(request.body ?? []) as Uint8Array<ArrayBuffer> }); const body = extension.body ?? new Uint8Array(); return response(extension.status, extension.headers ? { ...extension.headers } : {}, method === "HEAD" ? new Uint8Array() : body) }
      throw requestError("route_not_found", "Workbench route was not found")
    } catch (error) { return errorResponse(error) }
  }
}

/** Removes an adapter mount prefix before passing a path to the shared router. */
export function stripMountPrefix(path: string, prefix = ""): string { if (!prefix || prefix === "/") return path; const pathname = path.split("?", 1)[0]; if (pathname === prefix) return "/"; if (pathname.startsWith(`${prefix}/`)) return path.slice(prefix.length); return path }
export function errorEnvelope(value: unknown): WorkbenchErrorEnvelope { return toErrorEnvelope(value) }
