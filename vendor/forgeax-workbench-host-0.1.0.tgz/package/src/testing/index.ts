import type {
  CurrentVersion,
  GameVersion,
  ImageGenerationInput,
  ImageGenerationResult,
  MediaAsset,
  MediaBody,
  MediaCapability,
  MediaQuery,
  MediaWriteInput,
  ModelGateway,
  TextGenerationInput,
  TextGenerationResult,
  VersionAdapter,
  VideoGenerationInput,
  VideoGenerationResult,
  WorkspaceAdapter,
} from "../contracts/adapters.js"
import type { ExtensionHttpResponse, StaticFileRoot, WorkbenchHttpHost } from "../http/common.js"

export type { WorkbenchHttpRequest, WorkbenchHttpResponse } from "../http/common.js"
const clone = <T>(value: T): T => structuredClone(value)

/** Deterministic workspace double for host and package tests. */
export class InMemoryWorkspaceAdapter implements WorkspaceAdapter {
  readonly #roots: Map<string, string>
  constructor(roots: Record<string, string> = {}) { this.#roots = new Map(Object.entries(roots)) }
  async resolveGameRoot(gameId: string): Promise<string> {
    const root = this.#roots.get(gameId)
    if (!root) throw new TypeError("Game was not found")
    return root
  }
  set(gameId: string, root: string): void { this.#roots.set(gameId, root) }
}

/** In-memory immutable-history version adapter; it never shells out or touches Git. */
export class InMemoryVersionAdapter implements VersionAdapter {
  readonly #history = new Map<string, Array<GameVersion & { readonly files: Map<string, Uint8Array> }>>()
  readonly #workingFiles = new Map<string, Map<string, Uint8Array>>()
  setFile(gameRoot: string, relativePath: string, bytes: Uint8Array): void { const files = this.#workingFiles.get(gameRoot) ?? new Map(); files.set(relativePath, new Uint8Array(bytes)); this.#workingFiles.set(gameRoot, files) }
  async ensureRepository(_gameRoot: string): Promise<void> {}
  async createVersion(gameRoot: string, message: string): Promise<GameVersion> {
    const versions = this.#history.get(gameRoot) ?? []
    const files = new Map([... (this.#workingFiles.get(gameRoot) ?? new Map()).entries()].map(([path, bytes]) => [path, new Uint8Array(bytes)]))
    const value = { tag: `v${versions.length + 1}`, commitHash: `memory-${versions.length + 1}`, message, createdAt: new Date(0).toISOString(), files }
    versions.push(value); this.#history.set(gameRoot, versions); const { files: _files, ...publicVersion } = value; return { ...publicVersion }
  }
  async currentVersion(gameRoot: string): Promise<CurrentVersion | null> {
    const value = (this.#history.get(gameRoot) ?? []).at(-1)
    return value ? { tag: value.tag, commitHash: value.commitHash, dirty: false } : null
  }
  async listVersions(gameRoot: string): Promise<GameVersion[]> { return (this.#history.get(gameRoot) ?? []).map(({ files: _files, ...version }) => ({ ...version })) }
  async readFileAtVersion(gameRoot: string, tag: string, relativePath: string): Promise<Uint8Array | null> { const bytes = this.#history.get(gameRoot)?.find((version) => version.tag === tag)?.files.get(relativePath); return bytes ? new Uint8Array(bytes) : null }
}

/** In-memory byte store implementing the media capability boundary. */
export class InMemoryMediaCapability implements MediaCapability {
  readonly #items = new Map<string, Map<string, { asset: MediaAsset; body: MediaBody }>>()
  async list(gameId: string, query: MediaQuery = {}): Promise<MediaAsset[]> {
    let values = [...(this.#items.get(gameId)?.values() ?? [])].map((value) => clone(value.asset))
    if (query.type) values = values.filter((value) => value.type === query.type)
    return values.slice(0, query.limit ?? values.length)
  }
  async read(gameId: string, assetId: string): Promise<MediaBody | null> { const body = this.#items.get(gameId)?.get(assetId)?.body; return body ? { contentType: body.contentType, bytes: new Uint8Array(body.bytes) } : null }
  async put(gameId: string, input: MediaWriteInput): Promise<MediaAsset> {
    const type = input.contentType.startsWith("image/") ? "image" : input.contentType.startsWith("video/") ? "video" : "audio"
    const asset = { id: `${gameId}:${input.filename}`, type, url: `memory://${gameId}/${input.filename}`, contentType: input.contentType, sizeBytes: input.bytes.byteLength, ...(input.metadata ? { metadata: clone(input.metadata) } : {}) } as MediaAsset
    const items = this.#items.get(gameId) ?? new Map(); items.set(asset.id, { asset: clone(asset), body: { contentType: input.contentType, bytes: new Uint8Array(input.bytes) } }); this.#items.set(gameId, items)
    return clone(asset)
  }
}

/** Predictable model double that records no network state and returns input-derived output. */
export class InMemoryModelGateway implements ModelGateway {
  async generateText(input: TextGenerationInput): Promise<TextGenerationResult> { return { text: `memory: ${input.prompt}`, model: input.model ?? "memory" } }
  async generateImage(input: ImageGenerationInput): Promise<ImageGenerationResult> { return { assets: [], model: input.model ?? "memory", metadata: { prompt: input.prompt } } }
  async generateVideo(input: VideoGenerationInput): Promise<VideoGenerationResult> { return { assets: [], model: input.model ?? "memory", metadata: { prompt: input.prompt } } }
}

export interface InMemoryWorkbenchHostOptions { readonly runtimeRoots?: Record<string, string | StaticFileRoot>; readonly componentRoots?: Record<string, string | StaticFileRoot> }
function staticRoot(value: string | StaticFileRoot | undefined): StaticFileRoot | null { return typeof value === "string" ? { root: value } : value ?? null }

/** Complete deterministic host fake for testing a framework transport without business implementations. */
export function createInMemoryWorkbenchHost(options: InMemoryWorkbenchHostOptions = {}): WorkbenchHttpHost {
  const packages = new Map<string, Record<string, unknown>>()
  const versions = new Map<string, Array<{ tag: string; commitHash: string; message: string; createdAt: string; package: Record<string, unknown> }>>()
  const current = (gameId: string) => versions.get(gameId)?.at(-1)
  return {
    catalog: () => clone([{ extensionId: "example", runtimeId: "rt1", title: "Example", runtimeUrl: "runtime/rt1/index.html", packageRoot: "/not-for-catalog" }]),
    listTools: () => clone([{ id: "example:echo" }]),
    callTool: (input) => {
      const args = input as { args?: unknown }
      return { ok: true, result: args.args }
    },
    packageStatus: (gameId) => ({ state: packages.has(gameId) ? "initialized" : "uninitialized" }),
    initializePackage: (gameId) => {
      const value = packages.get(gameId) ?? { project: { name: gameId }, blueprint: {}, assetsManifest: {} }
      packages.set(gameId, structuredClone(value))
      const history = versions.get(gameId) ?? []
      if (history.length === 0) history.push(clone({ tag: "v1", commitHash: "memory-1", message: "initialize", createdAt: new Date(0).toISOString(), package: value }))
      versions.set(gameId, history)
      return { state: "initialized", package: clone(value), version: clone({ tag: history[0].tag, commitHash: history[0].commitHash, message: history[0].message, createdAt: history[0].createdAt }) }
    },
    readPackage: (gameId) => packages.has(gameId) ? structuredClone(packages.get(gameId)!) : (() => { throw new TypeError("Game package is not initialized") })(),
    updatePackage: (gameId, value) => { const next = structuredClone(value as Record<string, unknown>); packages.set(gameId, next); return structuredClone(next) },
    createVersion: (gameId, message) => {
      const value = packages.get(gameId); if (!value) throw new TypeError("Game package is not initialized")
      const history = versions.get(gameId) ?? []; const next = { tag: `v${history.length + 1}`, commitHash: `memory-${history.length + 1}`, message, createdAt: new Date(0).toISOString(), package: clone(value) }; history.push(clone(next)); versions.set(gameId, history); const { package: _package, ...publicVersion } = next; return clone(publicVersion)
    },
    listVersions: (gameId) => (versions.get(gameId) ?? []).map(({ package: _package, ...version }) => clone(version)),
    currentVersion: (gameId) => { const value = current(gameId); return value ? { tag: value.tag, commitHash: value.commitHash, dirty: false } : null },
    readVersionPackage: (gameId, tag) => { const value = versions.get(gameId)?.find((entry) => entry.tag === tag); if (!value) throw new TypeError("Version was not found"); return structuredClone(value.package) },
    runtimeRoot: (runtimeId) => staticRoot(options.runtimeRoots?.[runtimeId]),
    componentRoot: (gameId) => staticRoot(options.componentRoots?.[gameId]),
    extension: ({ runtimeId, path, method, body, query, headers, gameId }) => {
      if (path === "empty-204") return { status: 204, headers: { "x-extension": "memory" }, body: new Uint8Array([1]) } as ExtensionHttpResponse
      if (path === "empty-205") return { status: 205, headers: { "x-extension": "memory" }, body: new Uint8Array([1]) } as ExtensionHttpResponse
      if (path === "empty-304") return { status: 304, headers: { "x-extension": "memory" }, body: new Uint8Array([1]) } as ExtensionHttpResponse
      return { status: 207, headers: { "x-extension": "memory", "set-cookie": ["a=1", "b=2"] }, body: new TextEncoder().encode(JSON.stringify({ gameId, runtimeId, path, method, query, headers, body: [...body] })) } as ExtensionHttpResponse
    },
  }
}
