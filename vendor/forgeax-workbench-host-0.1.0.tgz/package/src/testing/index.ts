import {
  basename,
  extname,
  isAbsolute,
  relative,
  resolve,
  sep,
} from "node:path"

import type {
  CurrentVersion,
  GameFileCapability,
  GameVersion,
  ImageGenerationInput,
  ImageGenerationResult,
  MediaAsset,
  MediaBody,
  MediaCapability,
  MediaQuery,
  MediaWriteInput,
  ModelGateway,
  TextGenerationInput,
  TextGenerationResult,
  VersionAdapter,
  VideoGenerationInput,
  VideoGenerationResult,
  WorkspaceAdapter,
} from "../contracts/adapters.js"
import type { ExtensionHttpResponse, StaticFileRoot, WorkbenchHttpHost } from "../http/common.js"
import { createPathBoundedGameFilesForDevelopment } from "../node/host-context.js"

export type { WorkbenchHttpRequest, WorkbenchHttpResponse } from "../http/common.js"
const clone = <T>(value: T): T => structuredClone(value)

/** Deterministic workspace double for host and package tests. */
export class InMemoryWorkspaceAdapter implements WorkspaceAdapter {
  readonly #roots: Map<string, string>
  readonly #files = new Map<string, Map<string, Uint8Array>>()
  readonly #lockTails = new Map<string, Promise<void>>()
  constructor(roots: Record<string, string> = {}) { this.#roots = new Map(Object.entries(roots)) }
  async resolveGameRoot(gameId: string): Promise<string> {
    const root = this.#roots.get(gameId)
    if (!root) throw new TypeError("Game was not found")
    return root
  }
  async withGameRoot<T>(
    gameId: string,
    options: {
      readonly create: boolean
      readonly versioning: VersionAdapter
    },
    operation: (scope: {
      readonly gameRoot: string
      readonly files: GameFileCapability
      readonly versions: {
        ensureRepository(): Promise<void>
        createVersion(message: string): Promise<GameVersion>
        currentVersion(): Promise<CurrentVersion | null>
        listVersions(): Promise<GameVersion[]>
        readFileAtVersion(
          tag: string,
          relativePath: string,
        ): Promise<Uint8Array | null>
      }
    }) => Promise<T>,
  ): Promise<T> {
    let root = this.#roots.get(gameId)
    if (!root) {
      if (!options.create) throw new TypeError("Game was not found")
      root = `/games/${encodeURIComponent(gameId)}`
      this.#roots.set(gameId, root)
    }
    const rootKey = root
    const values = this.#files.get(rootKey) ?? new Map<string, Uint8Array>()
    const lockTails = this.#lockTails
    this.#files.set(rootKey, values)
    const relativeFile = (path: string): string => {
      if (
        path.length === 0 ||
        path.startsWith("/") ||
        path.split(/[\\/]/u).includes("..")
      ) {
        throw new TypeError("Game file path must be bounded")
      }
      return path.replaceAll("\\", "/")
    }
    const files: GameFileCapability = {
      async list(directory) {
        const prefix = `${relativeFile(directory).replace(/\/+$/u, "")}/`
        return [...values.keys()]
          .filter((path) => path.startsWith(prefix))
          .map((path) => path.slice(prefix.length).split("/")[0]!)
          .filter((name, index, names) => names.indexOf(name) === index)
          .sort()
      },
      async read(path) {
        const bytes = values.get(relativeFile(path))
        return bytes ? new Uint8Array(bytes) : null
      },
      async write(path, contents) {
        values.set(relativeFile(path), new Uint8Array(contents))
      },
      async delete(path) {
        values.delete(relativeFile(path))
      },
      async withLocks(_keys, work) {
        const previous = lockTails.get(rootKey) ?? Promise.resolve()
        let release!: () => void
        const gate = new Promise<void>((resolve) => {
          release = resolve
        })
        const current = previous.then(() => gate)
        lockTails.set(rootKey, current)
        await previous
        try {
          return await work()
        } finally {
          release()
          if (lockTails.get(rootKey) === current) {
            lockTails.delete(rootKey)
          }
        }
      },
    }
    return operation({
      gameRoot: rootKey,
      files,
      versions: {
        ensureRepository: () => options.versioning.ensureRepository(rootKey),
        createVersion: (message) =>
          options.versioning.createVersion(rootKey, message),
        currentVersion: () => options.versioning.currentVersion(rootKey),
        listVersions: () => options.versioning.listVersions(rootKey),
        readFileAtVersion: (tag, relativePath) =>
          options.versioning.readFileAtVersion(rootKey, tag, relativePath),
      },
    })
  }
  set(gameId: string, root: string): void { this.#roots.set(gameId, root) }
}

/** In-memory immutable-history version adapter; it never shells out or touches Git. */
export class InMemoryVersionAdapter implements VersionAdapter {
  readonly #history = new Map<string, Array<GameVersion & { readonly files: Map<string, Uint8Array> }>>()
  readonly #workingFiles = new Map<string, Map<string, Uint8Array>>()
  setFile(gameRoot: string, relativePath: string, bytes: Uint8Array): void { const files = this.#workingFiles.get(gameRoot) ?? new Map(); files.set(relativePath, new Uint8Array(bytes)); this.#workingFiles.set(gameRoot, files) }
  async ensureRepository(_gameRoot: string): Promise<void> {}
  async createVersion(gameRoot: string, message: string): Promise<GameVersion> {
    const versions = this.#history.get(gameRoot) ?? []
    const files = new Map([... (this.#workingFiles.get(gameRoot) ?? new Map()).entries()].map(([path, bytes]) => [path, new Uint8Array(bytes)]))
    const value = { tag: `v${versions.length + 1}`, commitHash: `memory-${versions.length + 1}`, message, createdAt: new Date(0).toISOString(), files }
    versions.push(value); this.#history.set(gameRoot, versions); const { files: _files, ...publicVersion } = value; return { ...publicVersion }
  }
  async currentVersion(gameRoot: string): Promise<CurrentVersion | null> {
    const value = (this.#history.get(gameRoot) ?? []).at(-1)
    return value ? { tag: value.tag, commitHash: value.commitHash, dirty: false } : null
  }
  async listVersions(gameRoot: string): Promise<GameVersion[]> { return (this.#history.get(gameRoot) ?? []).map(({ files: _files, ...version }) => ({ ...version })) }
  async readFileAtVersion(gameRoot: string, tag: string, relativePath: string): Promise<Uint8Array | null> { const bytes = this.#history.get(gameRoot)?.find((version) => version.tag === tag)?.files.get(relativePath); return bytes ? new Uint8Array(bytes) : null }
}

/** In-memory byte store implementing the media capability boundary. */
export class InMemoryMediaCapability implements MediaCapability {
  readonly #items = new Map<string, Map<string, { asset: MediaAsset; body: MediaBody }>>()
  readonly #receipts = new Map<string, Map<string, {
    readonly fingerprint: string
    readonly asset: MediaAsset
  }>>()
  async list(gameId: string, query: MediaQuery = {}): Promise<MediaAsset[]> {
    let values = [...(this.#items.get(gameId)?.values() ?? [])].map((value) => clone(value.asset))
    if (query.type) values = values.filter((value) => value.type === query.type)
    return values.slice(0, query.limit ?? values.length)
  }
  async read(gameId: string, assetId: string): Promise<MediaBody | null> { const body = this.#items.get(gameId)?.get(assetId)?.body; return body ? { contentType: body.contentType, bytes: new Uint8Array(body.bytes) } : null }
  async put(gameId: string, input: MediaWriteInput): Promise<MediaAsset> {
    const fingerprint = JSON.stringify({
      filename: input.filename,
      contentType: input.contentType,
      bytes: [...input.bytes],
      metadata: input.metadata ?? null,
    })
    if (input.idempotencyKey) {
      const receipt = this.#receipts.get(gameId)?.get(input.idempotencyKey)
      if (receipt) {
        if (receipt.fingerprint !== fingerprint) {
          throw new TypeError("Media idempotency key was reused with a different payload")
        }
        return clone(receipt.asset)
      }
    }
    const type = input.contentType.startsWith("image/")
      ? "image"
      : input.contentType.startsWith("video/")
        ? "video"
        : input.contentType.startsWith("font/")
          ? "font"
          : "audio"
    const asset = { id: `${gameId}:media-${(this.#items.get(gameId)?.size ?? 0) + 1}`, type, url: `memory://${gameId}/${encodeURIComponent(input.filename)}`, contentType: input.contentType, sizeBytes: input.bytes.byteLength, ...(input.metadata ? { metadata: clone(input.metadata) } : {}) } as MediaAsset
    const items = this.#items.get(gameId) ?? new Map(); items.set(asset.id, { asset: clone(asset), body: { contentType: input.contentType, bytes: new Uint8Array(input.bytes) } }); this.#items.set(gameId, items)
    if (input.idempotencyKey) {
      const receipts = this.#receipts.get(gameId) ?? new Map()
      receipts.set(input.idempotencyKey, { fingerprint, asset: clone(asset) })
      this.#receipts.set(gameId, receipts)
    }
    return clone(asset)
  }
  async delete(gameId: string, assetId: string): Promise<void> {
    this.#items.get(gameId)?.delete(assetId)
  }
}

/** Predictable model double that records no network state and returns input-derived output. */
export class InMemoryModelGateway implements ModelGateway {
  async generateText(gameId: string, input: TextGenerationInput): Promise<TextGenerationResult> { return { text: `memory: ${input.prompt}`, model: input.model ?? "memory", metadata: { gameId } } }
  async generateImage(gameId: string, input: ImageGenerationInput): Promise<ImageGenerationResult> { return { assets: [], model: input.model ?? "memory", metadata: { gameId, prompt: input.prompt } } }
  async generateVideo(gameId: string, input: VideoGenerationInput): Promise<VideoGenerationResult> { return { assets: [], model: input.model ?? "memory", metadata: { gameId, prompt: input.prompt } } }
}

export interface InMemoryWorkbenchHostOptions { readonly runtimeRoots?: Record<string, string | StaticFileRoot>; readonly componentRoots?: Record<string, string | StaticFileRoot> }
function staticRoot(value: string | StaticFileRoot | undefined): StaticFileRoot | null { return typeof value === "string" ? { root: value } : value ?? null }
function deniedTestingStaticPath(relativePath: string, policy: StaticFileRoot): boolean {
  const root = resolve("/", "__workbench_testing_static_root__")
  const actual = resolve(root, relativePath)
  const actualRelative = relative(root, actual)
  if (
    isAbsolute(actualRelative) ||
    actualRelative === ".." ||
    actualRelative.startsWith(`..${sep}`)
  ) {
    return true
  }
  if ((policy.deniedRelativePaths ?? []).some((value) => {
    const deniedAbsolute = resolve(root, value)
    const deniedRelative = relative(root, deniedAbsolute)
    if (
      isAbsolute(deniedRelative) ||
      deniedRelative === ".." ||
      deniedRelative.startsWith(`..${sep}`)
    ) {
      return true
    }
    return (
      actualRelative === deniedRelative ||
      actualRelative.startsWith(`${deniedRelative}${sep}`)
    )
  })) {
    return true
  }
  const fileName = basename(actualRelative).toLowerCase()
  const extension = extname(fileName)
  return (
    (policy.deniedFileExtensions ?? [])
      .some((value) => extension === value.toLowerCase()) ||
    (policy.deniedFileNames ?? [])
      .some((value) => fileName === value.toLowerCase()) ||
    (policy.deniedFilePrefixes ?? [])
      .some((value) => fileName.startsWith(value.toLowerCase()))
  )
}

/** Complete deterministic host fake for testing a framework transport without business implementations. */
export function createInMemoryWorkbenchHost(options: InMemoryWorkbenchHostOptions = {}): WorkbenchHttpHost {
  const packages = new Map<string, Record<string, unknown>>()
  const versions = new Map<string, Array<{ tag: string; commitHash: string; message: string; createdAt: string; package: Record<string, unknown> }>>()
  const current = (gameId: string) => versions.get(gameId)?.at(-1)
  return {
    catalog: () => clone([{ extensionId: "example", runtimeId: "rt1", title: "Example", runtimeUrl: "runtime/rt1/index.html", packageRoot: "/not-for-catalog" }]),
    listTools: () => clone([{ id: "example:echo" }]),
    callTool: (input) => {
      const args = input as { args?: unknown }
      return { ok: true, result: args.args }
    },
    packageStatus: (gameId) => ({ state: packages.has(gameId) ? "initialized" : "uninitialized" }),
    initializePackage: (gameId) => {
      const value = packages.get(gameId) ?? { project: { name: gameId }, blueprint: {}, assetsManifest: {} }
      packages.set(gameId, structuredClone(value))
      const history = versions.get(gameId) ?? []
      if (history.length === 0) history.push(clone({ tag: "v1", commitHash: "memory-1", message: "initialize", createdAt: new Date(0).toISOString(), package: value }))
      versions.set(gameId, history)
      return { state: "initialized", package: clone(value), version: clone({ tag: history[0].tag, commitHash: history[0].commitHash, message: history[0].message, createdAt: history[0].createdAt }) }
    },
    readPackage: (gameId) => packages.has(gameId) ? structuredClone(packages.get(gameId)!) : (() => { throw new TypeError("Game package is not initialized") })(),
    updatePackage: (gameId, value) => { const next = structuredClone(value as Record<string, unknown>); packages.set(gameId, next); return structuredClone(next) },
    createVersion: (gameId, message) => {
      const value = packages.get(gameId); if (!value) throw new TypeError("Game package is not initialized")
      const history = versions.get(gameId) ?? []; const next = { tag: `v${history.length + 1}`, commitHash: `memory-${history.length + 1}`, message, createdAt: new Date(0).toISOString(), package: clone(value) }; history.push(clone(next)); versions.set(gameId, history); const { package: _package, ...publicVersion } = next; return clone(publicVersion)
    },
    listVersions: (gameId) => (versions.get(gameId) ?? []).map(({ package: _package, ...version }) => clone(version)),
    currentVersion: (gameId) => { const value = current(gameId); return value ? { tag: value.tag, commitHash: value.commitHash, dirty: false } : null },
    readVersionPackage: (gameId, tag) => { const value = versions.get(gameId)?.find((entry) => entry.tag === tag); if (!value) throw new TypeError("Version was not found"); return structuredClone(value.package) },
    runtimeRoot: (runtimeId) => staticRoot(options.runtimeRoots?.[runtimeId]),
    async componentFile(gameId, relativePath) {
      const root = staticRoot(options.componentRoots?.[gameId])
      if (!root) return null
      try {
        if (deniedTestingStaticPath(relativePath, root)) return null
        const bytes = await createPathBoundedGameFilesForDevelopment(root.root)
          .read(relativePath)
        return bytes === null ? null : new Uint8Array(bytes)
      } catch {
        return null
      }
    },
    extension: ({ runtimeId, path, method, body, query, headers, gameId }) => {
      if (path === "empty-204") return { status: 204, headers: { "x-extension": "memory" }, body: new Uint8Array([1]) } as ExtensionHttpResponse
      if (path === "empty-205") return { status: 205, headers: { "x-extension": "memory" }, body: new Uint8Array([1]) } as ExtensionHttpResponse
      if (path === "empty-304") return { status: 304, headers: { "x-extension": "memory" }, body: new Uint8Array([1]) } as ExtensionHttpResponse
      return { status: 207, headers: { "x-extension": "memory", "set-cookie": ["a=1", "b=2"] }, body: new TextEncoder().encode(JSON.stringify({ gameId, runtimeId, path, method, query, headers, body: [...body] })) } as ExtensionHttpResponse
    },
  }
}
