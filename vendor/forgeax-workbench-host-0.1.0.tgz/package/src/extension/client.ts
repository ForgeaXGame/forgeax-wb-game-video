import {
  WorkbenchSessionContextSchema,
  type WorkbenchSessionContext,
} from "../contracts/session.js"
import {
  WorkbenchErrorEnvelopeSchema,
  type WorkbenchErrorEnvelope,
} from "../contracts/error.js"
import {
  WORKBENCH_HANDSHAKE_REQUEST,
  WORKBENCH_HANDSHAKE_RESPONSE,
} from "../browser/frame-controller.js"
import type { WorkbenchFetch } from "../browser/catalog-client.js"
import { resolveContainedUrl } from "../browser/url-containment.js"

export interface ExtensionClientWindow {
  readonly parent: {
    postMessage(message: unknown, targetOrigin: string): void
  }
  readonly document?: { readonly referrer: string }
  addEventListener(
    type: "message",
    listener: (event: MessageEvent) => void,
  ): void
  removeEventListener(
    type: "message",
    listener: (event: MessageEvent) => void,
  ): void
}

export interface CreateExtensionClientOptions {
  readonly window?: ExtensionClientWindow
  readonly fetch?: WorkbenchFetch
  readonly hostOrigin?: string
  readonly nonce?: string
  readonly timeoutMs?: number
}

export interface ExtensionClient {
  readonly context: WorkbenchSessionContext | undefined
  ready(): Promise<WorkbenchSessionContext>
  close(): void
  readonly gamePackage: {
    status(): Promise<unknown>
    initialize(): Promise<unknown>
    load(): Promise<unknown>
    save(patch: unknown): Promise<unknown>
  }
  readonly extension: {
    fetch(path: string, init?: RequestInit): Promise<Response>
  }
  readonly tool: {
    call(toolId: string, args: unknown): Promise<unknown>
  }
}

/** Stable HTTP failure surfaced by the browser extension client. */
export class WorkbenchClientError extends Error {
  readonly status: number
  readonly envelope: WorkbenchErrorEnvelope
  readonly code: string
  readonly target: string
  readonly retryable: boolean
  readonly details: unknown

  constructor(status: number, envelope: WorkbenchErrorEnvelope) {
    const parsed = WorkbenchErrorEnvelopeSchema.parse(envelope)
    super(parsed.error.message)
    this.name = "WorkbenchClientError"
    this.status = status
    this.envelope = parsed
    this.code = parsed.error.code
    this.target = parsed.error.target
    this.retryable = parsed.error.retryable
    this.details = parsed.error.details
  }
}

function originFromReferrer(referrer: string | undefined): string {
  if (!referrer) {
    throw new TypeError("A hostOrigin is required when document.referrer is unavailable")
  }
  return new URL(referrer).origin
}

function createNonce(): string {
  const values = new Uint32Array(4)
  globalThis.crypto.getRandomValues(values)
  return Array.from(values, (value) => value.toString(16).padStart(8, "0")).join("")
}

const endpointSchemePattern = /^[a-z][a-z\d+.-]*:/iu
const syntheticEndpointBase = "https://workbench.invalid"

function parsedEndpoint(endpoint: string): { readonly url: URL; readonly relative: boolean } {
  if (endpoint.length === 0 || endpoint.startsWith("//")) {
    throw new TypeError("Workbench endpoints must not be empty or protocol-relative")
  }
  const relative = !endpointSchemePattern.test(endpoint)
  if (relative && !endpoint.startsWith("/")) {
    throw new TypeError("Relative Workbench endpoints must start with a slash")
  }
  const url = new URL(endpoint, syntheticEndpointBase)
  if (url.pathname.includes("\\")) {
    throw new TypeError("Workbench endpoints must not contain backslashes")
  }
  return { url, relative }
}

function serializedEndpoint(value: { readonly url: URL; readonly relative: boolean }): string {
  return value.relative
    ? `${value.url.pathname}${value.url.search}${value.url.hash}`
    : value.url.toString()
}

function appendEndpoint(endpoint: string, path: string): string {
  const parsed = parsedEndpoint(endpoint)
  const search = parsed.url.search
  const hash = parsed.url.hash
  parsed.url.search = ""
  parsed.url.hash = ""
  const appended = parsedEndpoint(resolveContainedUrl(serializedEndpoint(parsed), path))
  appended.url.search = search
  appended.url.hash = hash
  return serializedEndpoint(appended)
}

function endpointWithQuery(endpoint: string, name: string, value: string): string {
  const parsed = parsedEndpoint(endpoint)
  parsed.url.searchParams.set(name, value)
  return serializedEndpoint(parsed)
}

function isWorkbenchHandshakeResponse(value: unknown): value is {
  readonly type: typeof WORKBENCH_HANDSHAKE_RESPONSE
  readonly nonce?: unknown
  readonly context?: unknown
} {
  return (
    value !== null &&
    typeof value === "object" &&
    (value as { type?: unknown }).type === WORKBENCH_HANDSHAKE_RESPONSE
  )
}

function invalidResponse(status: number, successful: boolean): WorkbenchClientError {
  const code = successful ? "response_invalid" : "response_error_invalid"
  return new WorkbenchClientError(status, {
    ok: false,
    error: {
      code,
      target: "client",
      message: successful
        ? "Workbench host returned an invalid response"
        : "Workbench host returned an invalid error response",
      retryable: false,
    },
  })
}

function isJsonContentType(value: string | null): boolean {
  if (!value) return false
  const mediaType = value.split(";", 1)[0]?.trim().toLowerCase() ?? ""
  return mediaType === "application/json" || mediaType.endsWith("+json")
}

async function readJson(response: Response): Promise<unknown> {
  if (!isJsonContentType(response.headers.get("content-type"))) {
    throw invalidResponse(response.status, response.ok)
  }
  let value: unknown
  try {
    value = await response.json()
  } catch {
    throw invalidResponse(response.status, response.ok)
  }
  if (!response.ok) {
    const parsed = WorkbenchErrorEnvelopeSchema.safeParse(value)
    if (!parsed.success) throw invalidResponse(response.status, false)
    throw new WorkbenchClientError(response.status, parsed.data)
  }
  return value
}

/**
 * Starts a one-time iframe handshake. Every host request uses endpoint strings
 * supplied by that handshake; this client never reads location-derived paths,
 * runtime ids, or game ids.
 */
export function createExtensionClient(
  options: CreateExtensionClientOptions = {},
): ExtensionClient {
  const browserWindow = options.window ?? (globalThis.window as ExtensionClientWindow)
  if (!browserWindow) {
    throw new TypeError("createExtensionClient requires a browser window")
  }
  const fetcher = options.fetch ?? globalThis.fetch
  if (typeof fetcher !== "function") {
    throw new TypeError("A fetch implementation is required")
  }
  const origin = options.hostOrigin ?? originFromReferrer(browserWindow.document?.referrer)
  const nonce = options.nonce ?? createNonce()
  const timeoutMs = options.timeoutMs ?? 10_000
  let context: WorkbenchSessionContext | undefined
  let port: MessagePort | undefined
  let closed = false
  let timer: ReturnType<typeof setTimeout> | undefined
  let retryTimer: ReturnType<typeof setInterval> | undefined
  let settleReady: ((value: WorkbenchSessionContext) => void) | undefined
  let rejectReady: ((reason?: unknown) => void) | undefined
  let listenerAttached = false

  const clearHandshakeTimers = (): void => {
    if (timer !== undefined) {
      clearTimeout(timer)
      timer = undefined
    }
    if (retryTimer !== undefined) {
      clearInterval(retryTimer)
      retryTimer = undefined
    }
  }
  const cleanupHandshake = (): void => {
    if (listenerAttached) {
      browserWindow.removeEventListener("message", onMessage)
      listenerAttached = false
    }
    clearHandshakeTimers()
  }
  const closeTransferredPorts = (event: MessageEvent): void => {
    for (const transferredPort of event.ports) {
      try {
        transferredPort.close()
      } catch {
        // A malformed cross-realm port must not prevent closing its siblings.
      }
    }
  }
  const onMessage = (event: MessageEvent): void => {
    if (!isWorkbenchHandshakeResponse(event.data)) {
      return
    }
    if (
      closed ||
      context !== undefined ||
      event.origin !== origin ||
      event.source !== browserWindow.parent ||
      event.data.nonce !== nonce ||
      event.ports.length !== 1
    ) {
      closeTransferredPorts(event)
      return
    }
    const receivedPort = event.ports[0]
    const parsed = WorkbenchSessionContextSchema.safeParse(
      event.data.context,
    )
    if (!parsed.success) {
      closeTransferredPorts(event)
      return
    }
    try {
      receivedPort.start()
      port = receivedPort
      context = parsed.data
      clearHandshakeTimers()
      settleReady?.(context)
      settleReady = undefined
      rejectReady = undefined
    } catch {
      try {
        receivedPort.close()
      } catch {
        // Nothing else can be reclaimed for a port whose setup threw.
      }
      port = undefined
      context = undefined
    }
  }

  const readyPromise = new Promise<WorkbenchSessionContext>((resolve, reject) => {
    settleReady = resolve
    rejectReady = reject
  })
  browserWindow.addEventListener("message", onMessage)
  listenerAttached = true
  timer = setTimeout(() => {
    if (context || closed) return
    cleanupHandshake()
    rejectReady?.(new Error("Workbench handshake timed out"))
    rejectReady = undefined
    settleReady = undefined
  }, timeoutMs)
  const requestHandshake = (): void => {
    browserWindow.parent.postMessage(
      { type: WORKBENCH_HANDSHAKE_REQUEST, nonce },
      origin,
    )
  }
  requestHandshake()
  // An iframe may reload while its parent replaces the controller. Retrying the
  // nonce-bound request prevents a lost race without opening a global channel.
  retryTimer = setInterval(requestHandshake, Math.min(250, timeoutMs))

  const requireContext = async (): Promise<WorkbenchSessionContext> => readyPromise
  const requestJson = async (
    endpoint: string,
    init?: RequestInit,
  ): Promise<unknown> => readJson(await fetcher(endpoint, init))

  return Object.freeze({
    get context(): WorkbenchSessionContext | undefined {
      return context
    },
    ready(): Promise<WorkbenchSessionContext> {
      return readyPromise
    },
    close(): void {
      if (closed) return
      closed = true
      cleanupHandshake()
      port?.close()
      port = undefined
      if (!context) {
        rejectReady?.(new Error("Workbench extension client was closed"))
        rejectReady = undefined
        settleReady = undefined
      }
    },
    gamePackage: Object.freeze({
      async status(): Promise<unknown> {
        const session = await requireContext()
        return requestJson(appendEndpoint(session.endpoints.gamePackage, "status"))
      },
      async initialize(): Promise<unknown> {
        const session = await requireContext()
        const endpoint = appendEndpoint(session.endpoints.gamePackage, "initialize")
        return requestJson(endpointWithQuery(endpoint, "runtimeId", session.runtimeId), {
          method: "POST",
        })
      },
      async load(): Promise<unknown> {
        const session = await requireContext()
        return requestJson(session.endpoints.gamePackage)
      },
      async save(patch: unknown): Promise<unknown> {
        const session = await requireContext()
        return requestJson(session.endpoints.gamePackage, {
          method: "PUT",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(patch),
        })
      },
    }),
    extension: Object.freeze({
      async fetch(path: string, init?: RequestInit): Promise<Response> {
        const session = await requireContext()
        return fetcher(appendEndpoint(session.endpoints.extensionApi, path), init)
      },
    }),
    tool: Object.freeze({
      async call(toolId: string, args: unknown): Promise<unknown> {
        if (toolId.length === 0) throw new TypeError("toolId must not be empty")
        const session = await requireContext()
        return requestJson(session.endpoints.toolCall, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            caller: "ui",
            gameId: session.gameId,
            toolId,
            args,
          }),
        })
      },
    }),
  })
}
