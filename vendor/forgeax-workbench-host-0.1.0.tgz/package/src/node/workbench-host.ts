import { join } from "node:path"

import type { MediaCapability, ModelGateway, VersionAdapter, WorkspaceAdapter } from "../contracts/adapters.js"
import { WorkbenchError } from "../contracts/error.js"
import type { ToolCallResult } from "../contracts/tool.js"
import { GamePackageService, VersionService } from "../game-host/index.js"
import type { ExtensionHttpRequest, ExtensionHttpResponse, WorkbenchHttpHost } from "../http/common.js"
import { loadTrustedBackend } from "./backend-loader.js"
import { createWorkbenchExtensionContext, type WorkbenchExtensionModule } from "./host-context.js"
import { runtimeStaticProjection, type RuntimeDescriptor, type RuntimeRegistry } from "./runtime-registry.js"
import { ToolExecutor } from "./tool-executor.js"

export interface WorkbenchHostOptions {
  readonly registry: RuntimeRegistry
  readonly workspace: WorkspaceAdapter
  readonly versioning?: VersionAdapter
  readonly isExtensionTrusted: (extension: RuntimeDescriptor) => boolean | Promise<boolean>
  readonly media?: MediaCapability
  readonly models?: ModelGateway
  /** Limits component static serving without exposing the entire game root. */
  readonly resolveComponentRoot?: (gameId: string) => Promise<string | null> | string | null
}

/** A complete host is directly usable by Fastify, Hono, and the development Vite plugin. */
export interface WorkbenchHost extends WorkbenchHttpHost {
  listTools(gameId: string): RuntimeDescriptor["manifest"]["tools"]
  callTool(input: unknown): Promise<ToolCallResult>
}

function hostError(code: string, message: string): WorkbenchError { return new WorkbenchError({ code, target: "host", message, retryable: false }) }
function copyTools(registry: RuntimeRegistry, gameId: string): RuntimeDescriptor["manifest"]["tools"] {
  if (gameId.length === 0) throw hostError("identifier_invalid", "Game id must not be empty")
  return registry.entries().flatMap((extension) => extension.manifest.tools.map((tool) => ({ ...tool, ...(tool.permissions === undefined ? {} : { permissions: [...tool.permissions] }) })))
}
function extensionResponse(value: unknown): ExtensionHttpResponse {
  if (typeof value !== "object" || value === null) throw hostError("extension_response_invalid", "Extension router returned an invalid response")
  const response = value as { status?: unknown; headers?: unknown; body?: unknown }
  const status = response.status
  if (typeof status !== "number" || !Number.isInteger(status) || status < 200 || status > 599) throw hostError("extension_response_invalid", "Extension router returned an invalid response")
  if (response.body !== undefined && !(response.body instanceof Uint8Array)) throw hostError("extension_response_invalid", "Extension router returned an invalid response")
  if (response.headers !== undefined && (typeof response.headers !== "object" || response.headers === null || Array.isArray(response.headers))) throw hostError("extension_response_invalid", "Extension router returned invalid headers")
  for (const [name, value] of Object.entries(response.headers ?? {})) {
    if (!/^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/u.test(name) || /[\r\n]/u.test(name)) throw hostError("extension_response_invalid", "Extension router returned invalid headers")
    const values = typeof value === "string" ? [value] : Array.isArray(value) ? value : []
    if (values.length === 0 || values.some((item) => typeof item !== "string" || /[\r\n]/u.test(item))) throw hostError("extension_response_invalid", "Extension router returned invalid headers")
  }
  const bodyless = (status >= 100 && status < 200) || status === 204 || status === 205 || status === 304
  return { status, ...(response.headers === undefined ? {} : { headers: response.headers as Record<string, string | readonly string[]> }), ...(!bodyless && response.body !== undefined ? { body: new Uint8Array(response.body as Uint8Array) } : {}) }
}

/** Creates one real composition root and one shared tool executor for all transports/callers. */
export function createWorkbenchHost(options: WorkbenchHostOptions): WorkbenchHost {
  const executor = new ToolExecutor(options)
  const packageService = options.versioning ? new GamePackageService({ workspace: options.workspace, versioning: options.versioning, media: options.media, models: options.models }) : undefined
  const versionService = options.versioning ? new VersionService({ workspace: options.workspace, versioning: options.versioning }) : undefined
  const modules = new Map<string, Promise<WorkbenchExtensionModule>>()
  const moduleFor = (descriptor: RuntimeDescriptor): Promise<WorkbenchExtensionModule> => {
    let module = modules.get(descriptor.runtimeId)
    if (!module) { module = loadTrustedBackend(descriptor.source, () => options.isExtensionTrusted(descriptor)); modules.set(descriptor.runtimeId, module) }
    return module
  }
  const descriptorFor = (runtimeId: string): RuntimeDescriptor => options.registry.get(runtimeId) ?? (() => { throw hostError("runtime_not_found", "Runtime was not found") })()
  const packageApi = (): GamePackageService => packageService ?? (() => { throw hostError("host_not_configured", "Versioning is required for game packages") })()
  const versionsApi = (): VersionService => versionService ?? (() => { throw hostError("host_not_configured", "Versioning is required for game versions") })()

  return Object.freeze({
    listTools(gameId: string) { return copyTools(options.registry, gameId) },
    callTool(input: unknown) { return executor.call(input) },
    catalog(gameId: string) { if (gameId.length === 0) throw hostError("identifier_invalid", "Game id must not be empty"); return options.registry.catalog() },
    packageStatus(gameId: string) { return packageApi().status(gameId) },
    async initializePackage(gameId: string, runtimeId: string) {
      const descriptor = descriptorFor(runtimeId)
      const module = await moduleFor(descriptor)
      if (!module.gamePackage) throw hostError("game_package_unsupported", "Runtime does not provide a game package")
      return packageApi().initialize(gameId, { manifest: descriptor.manifest, gamePackage: module.gamePackage })
    },
    readPackage(gameId: string) { return packageApi().read(gameId) },
    updatePackage(gameId: string, value: unknown) { return packageApi().update(gameId, value) },
    createVersion(gameId: string, message: string) { return versionsApi().create(gameId, message) },
    listVersions(gameId: string) { return versionsApi().list(gameId) },
    currentVersion(gameId: string) { return versionsApi().current(gameId) },
    readVersionPackage(gameId: string, tag: string) { return versionsApi().readAtTag(gameId, tag) },
    runtimeRoot(runtimeId: string) { const descriptor = options.registry.get(runtimeId); return descriptor ? runtimeStaticProjection(descriptor.source) : null },
    async componentRoot(gameId: string) { try { const root = options.resolveComponentRoot ? await options.resolveComponentRoot(gameId) : join(await options.workspace.resolveGameRoot(gameId), "components"); return root === null ? null : { root } } catch { throw hostError("workspace_not_found", "Game workspace was not found") } },
    async extension(request: ExtensionHttpRequest): Promise<ExtensionHttpResponse> {
      const descriptor = descriptorFor(request.runtimeId)
      const module = await moduleFor(descriptor)
      if (!module.createRouter) throw hostError("extension_router_not_found", "Runtime does not provide an extension router")
      let gameRoot: string
      try { gameRoot = await options.workspace.resolveGameRoot(request.gameId) } catch { throw hostError("workspace_not_found", "Game workspace was not found") }
      const router = module.createRouter(createWorkbenchExtensionContext({ gameId: request.gameId, gameRoot, media: options.media, models: options.models }))
      if (!router || typeof router.handle !== "function") throw hostError("extension_router_invalid", "Extension router is invalid")
      return extensionResponse(await router.handle({ ...request, body: new Uint8Array(request.body) }))
    },
  })
}
