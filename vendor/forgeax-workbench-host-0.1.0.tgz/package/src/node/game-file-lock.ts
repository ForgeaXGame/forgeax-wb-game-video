import { createHash, randomUUID } from "node:crypto"
import {
  lstat,
  link,
  mkdir,
  open,
  readFile,
  realpath,
  stat,
  unlink,
} from "node:fs/promises"
import type { Stats } from "node:fs"
import { isAbsolute, join, relative, sep } from "node:path"

interface LockMetadata {
  readonly kind: "workbench-game-file-lock"
  readonly keyHash: string
  readonly token: string
  readonly pid: number
  readonly createdAt: string
}

interface ReclaimMetadata {
  readonly kind: "workbench-game-file-lock-reclaim"
  readonly token: string
  readonly pid: number
  readonly createdAt: string
  readonly observed: LockIdentity & { readonly token: string }
}

interface LockIdentity {
  readonly dev: string
  readonly ino: string
}

interface ObservedLock {
  readonly identity: LockIdentity
  readonly metadata: LockMetadata
}

interface OwnedFile {
  readonly identity: LockIdentity
  readonly text: string
}

interface AcquiredLock {
  release(): Promise<void>
}

const LOCK_DIRECTORY = ".workbench-locks"
const WAIT_INTERVAL_MS = 10
const MAX_LOCK_KEY_LENGTH = 256

function missing(error: unknown): boolean {
  return (error as NodeJS.ErrnoException).code === "ENOENT"
}

function identity(value: Stats): LockIdentity {
  return { dev: String(value.dev), ino: String(value.ino) }
}

function sameIdentity(left: LockIdentity, right: LockIdentity): boolean {
  return left.dev === right.dev && left.ino === right.ino
}

function within(root: string, candidate: string): boolean {
  const value = relative(root, candidate)
  return value === "" || (
    !isAbsolute(value)
    && value !== ".."
    && !value.startsWith(`..${sep}`)
  )
}

function ownerIsAlive(pid: number): boolean {
  try {
    process.kill(pid, 0)
    return true
  } catch (error) {
    return (error as NodeJS.ErrnoException).code !== "ESRCH"
  }
}

function lockKey(value: string): string {
  if (
    value.length === 0
    || value.length > MAX_LOCK_KEY_LENGTH
    || value === "."
    || value === ".."
    || value.includes("/")
    || value.includes("\\")
    || /[\u0000-\u001f\u007f]/u.test(value)
  ) {
    throw new TypeError("Game file lock key is invalid")
  }
  return value
}

function keyHash(value: string): string {
  return createHash("sha256").update(value).digest("hex")
}

function parseLockMetadata(text: string, expectedHash: string): LockMetadata {
  const value = JSON.parse(text) as Partial<LockMetadata>
  if (
    value.kind !== "workbench-game-file-lock"
    || value.keyHash !== expectedHash
    || typeof value.token !== "string"
    || !Number.isSafeInteger(value.pid)
    || typeof value.createdAt !== "string"
  ) {
    throw new Error("Game file lock metadata is invalid")
  }
  return value as LockMetadata
}

function parseReclaimMetadata(text: string): ReclaimMetadata {
  const value = JSON.parse(text) as Partial<ReclaimMetadata>
  if (
    value.kind !== "workbench-game-file-lock-reclaim"
    || typeof value.token !== "string"
    || !Number.isSafeInteger(value.pid)
    || typeof value.createdAt !== "string"
    || typeof value.observed?.dev !== "string"
    || typeof value.observed?.ino !== "string"
    || typeof value.observed?.token !== "string"
  ) {
    throw new Error("Game file lock reclaim metadata is invalid")
  }
  return value as ReclaimMetadata
}

async function ownedFileMatches(path: string, owned: OwnedFile): Promise<boolean> {
  try {
    return (
      sameIdentity(identity(await stat(path)), owned.identity)
      && await readFile(path, "utf8") === owned.text
    )
  } catch (error) {
    if (missing(error)) return false
    throw error
  }
}

async function releaseOwnedFile(path: string, owned: OwnedFile): Promise<void> {
  if (await ownedFileMatches(path, owned)) await unlink(path)
}

async function observeLock(path: string, expectedHash: string): Promise<ObservedLock | null> {
  try {
    const before = identity(await stat(path))
    const metadata = parseLockMetadata(await readFile(path, "utf8"), expectedHash)
    const after = identity(await stat(path))
    return sameIdentity(before, after) ? { identity: after, metadata } : null
  } catch (error) {
    if (missing(error)) return null
    throw error
  }
}

async function lockDirectory(gameRoot: string): Promise<string> {
  const root = await realpath(gameRoot)
  const directory = join(root, LOCK_DIRECTORY)
  try {
    const existing = await lstat(directory)
    if (existing.isSymbolicLink() || !existing.isDirectory()) {
      throw new TypeError("Game file lock directory is invalid")
    }
  } catch (error) {
    if (!missing(error)) throw error
    try {
      await mkdir(directory, { mode: 0o700 })
    } catch (mkdirError) {
      if ((mkdirError as NodeJS.ErrnoException).code !== "EEXIST") {
        throw mkdirError
      }
    }
    const created = await lstat(directory)
    if (created.isSymbolicLink() || !created.isDirectory()) {
      throw new TypeError("Game file lock directory is invalid")
    }
  }
  const actual = await realpath(directory)
  if (!within(root, actual)) {
    throw new TypeError("Game file lock directory is outside the game root")
  }
  return actual
}

async function publishExclusive(path: string, text: string): Promise<OwnedFile> {
  const temp = `${path}.${randomUUID()}.tmp`
  let handle: Awaited<ReturnType<typeof open>> | undefined
  try {
    handle = await open(temp, "wx", 0o600)
    await handle.writeFile(text)
    await handle.sync()
    await handle.close()
    handle = undefined
    await link(temp, path)
    return { identity: identity(await stat(path)), text }
  } finally {
    await handle?.close()
    await unlink(temp).catch((error: unknown) => {
      if (!missing(error)) throw error
    })
  }
}

async function reclaim(
  lockPath: string,
  reclaimPath: string,
  observed: ObservedLock,
): Promise<void> {
  const claim: ReclaimMetadata = {
    kind: "workbench-game-file-lock-reclaim",
    token: randomUUID(),
    pid: process.pid,
    createdAt: new Date().toISOString(),
    observed: {
      ...observed.identity,
      token: observed.metadata.token,
    },
  }
  const text = JSON.stringify(claim)
  let owned: OwnedFile
  try {
    owned = await publishExclusive(reclaimPath, text)
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "EEXIST") return
    throw error
  }
  try {
    const current = await observeLock(lockPath, observed.metadata.keyHash)
    if (
      current
      && sameIdentity(current.identity, observed.identity)
      && current.metadata.token === observed.metadata.token
    ) {
      await unlink(lockPath)
    }
  } finally {
    await releaseOwnedFile(reclaimPath, owned)
  }
}

async function reclaimIsLive(path: string): Promise<boolean> {
  try {
    const before = identity(await stat(path))
    const claim = parseReclaimMetadata(await readFile(path, "utf8"))
    const after = identity(await stat(path))
    if (!sameIdentity(before, after)) return false
    if (!ownerIsAlive(claim.pid)) {
      const owned = { identity: after, text: await readFile(path, "utf8") }
      await releaseOwnedFile(path, owned)
      return false
    }
    return true
  } catch (error) {
    if (missing(error)) return false
    throw error
  }
}

async function acquire(gameRoot: string, key: string): Promise<AcquiredLock> {
  const directory = await lockDirectory(gameRoot)
  const hash = keyHash(lockKey(key))
  const path = join(directory, `${hash}.lock`)
  const reclaimPath = join(directory, `${hash}.reclaim`)
  const metadata: LockMetadata = {
    kind: "workbench-game-file-lock",
    keyHash: hash,
    token: randomUUID(),
    pid: process.pid,
    createdAt: new Date().toISOString(),
  }
  const text = JSON.stringify(metadata)

  for (;;) {
    if (await reclaimIsLive(reclaimPath)) {
      await new Promise((resolve) => setTimeout(resolve, WAIT_INTERVAL_MS))
      continue
    }
    try {
      const owned = await publishExclusive(path, text)
      while (await reclaimIsLive(reclaimPath)) {
        await new Promise((resolve) => setTimeout(resolve, WAIT_INTERVAL_MS))
      }
      return {
        release: () => releaseOwnedFile(path, owned),
      }
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error
      if (!await reclaimIsLive(reclaimPath)) {
        const observed = await observeLock(path, hash)
        if (observed && !ownerIsAlive(observed.metadata.pid)) {
          await reclaim(path, reclaimPath, observed)
        }
      }
      await new Promise((resolve) => setTimeout(resolve, WAIT_INTERVAL_MS))
    }
  }
}

/** Runs an operation while holding a deterministic, cross-process lock set. */
export async function withGameFileLocks<T>(
  gameRoot: string,
  keys: readonly string[],
  operation: () => Promise<T>,
): Promise<T> {
  const ordered = [...new Set(keys.map(lockKey))].sort()
  if (ordered.length === 0) {
    throw new TypeError("At least one game file lock key is required")
  }
  const acquired: AcquiredLock[] = []
  try {
    for (const key of ordered) acquired.push(await acquire(gameRoot, key))
    return await operation()
  } finally {
    for (const lock of acquired.reverse()) await lock.release()
  }
}
