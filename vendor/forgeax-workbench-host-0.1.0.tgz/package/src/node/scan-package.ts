import { lstat, readFile, realpath, stat } from "node:fs/promises"
import { createRequire } from "node:module"
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path"

import type { ExtensionSource } from "./extension-source.js"
import {
  mergeManifestLayers,
  type ExtensionManifest,
} from "./merge-manifest.js"

const require = createRequire(import.meta.url)

export interface ScannedExtension {
  readonly manifest: ExtensionManifest
  readonly packageRoot: string
  readonly frontendEntry: string
  readonly backendEntry: string
}

function isWithin(root: string, candidate: string): boolean {
  const path = relative(root, candidate)
  return (
    path === "" ||
    (!isAbsolute(path) && path !== ".." && !path.startsWith(`..${sep}`))
  )
}

async function resolveDirectoryRoot(path: string): Promise<string> {
  const root = await realpath(path)
  if (!(await stat(root)).isDirectory()) {
    throw new TypeError(`Extension source is not a directory: ${path}`)
  }
  return root
}

async function resolvePackageRoot(specifier: string): Promise<string> {
  const packageName = packageSpecifierName(specifier)
  try {
    const packageJson = require.resolve(`${packageName}/package.json`)
    return resolveDirectoryRoot(dirname(await realpath(packageJson)))
  } catch {
    const resolvedExport = require.resolve(specifier)
    const packageJson = await findPackageJson(resolvedExport, packageName)
    return resolveDirectoryRoot(dirname(await realpath(packageJson)))
  }
}

function packageSpecifierName(specifier: string): string {
  const segments = specifier.split("/")
  return specifier.startsWith("@") ? segments.slice(0, 2).join("/") : segments[0]
}

async function findPackageJson(
  resolvedExport: string,
  packageName: string,
): Promise<string> {
  let directory = dirname(resolvedExport)
  while (true) {
    const packageJson = join(directory, "package.json")
    try {
      const metadata = JSON.parse(await readFile(packageJson, "utf8")) as {
        name?: unknown
      }
      if (metadata.name === packageName) {
        return packageJson
      }
    } catch {
      // Continue walking until the package root is found.
    }

    const parent = dirname(directory)
    if (parent === directory) {
      throw new Error(`Could not resolve package root for extension: ${packageName}`)
    }
    directory = parent
  }
}

async function resolveSourceRoot(source: ExtensionSource): Promise<string> {
  return source.kind === "package"
    ? resolvePackageRoot(source.specifier)
    : resolveDirectoryRoot(source.path)
}

function normalizeRelativeEntry(entry: string): string {
  return entry.split("\\").join("/")
}

async function resolveEntry(root: string, entry: string): Promise<string> {
  const normalized = normalizeRelativeEntry(entry)
  const lexicalPath = resolve(root, normalized)
  if (!isWithin(root, lexicalPath)) {
    throw new Error(`Extension entry is outside extension root: ${entry}`)
  }

  const relativeEntry = relative(root, lexicalPath)
  let cursor = root
  for (const segment of relativeEntry.split(sep)) {
    cursor = resolve(cursor, segment)
    if ((await lstat(cursor)).isSymbolicLink()) {
      throw new Error(`Extension entry must not traverse a symlink: ${entry}`)
    }
  }

  const resolvedEntry = await realpath(lexicalPath)
  if (!isWithin(root, resolvedEntry)) {
    throw new Error(`Extension entry is outside extension root: ${entry}`)
  }
  if (!(await stat(resolvedEntry)).isFile()) {
    throw new TypeError(`Extension entry is not a file: ${entry}`)
  }

  return relativeEntry.split(sep).join("/")
}

async function resolveManifestPath(root: string): Promise<string> {
  const manifestPath = resolve(root, "forgeax-extension.json")
  if (!isWithin(root, manifestPath)) {
    throw new Error("Extension manifest is outside extension root")
  }
  if ((await lstat(manifestPath)).isSymbolicLink()) {
    throw new Error("Extension manifest must not traverse a symlink")
  }

  const resolvedManifest = await realpath(manifestPath)
  if (!isWithin(root, resolvedManifest)) {
    throw new Error("Extension manifest is outside extension root")
  }
  if (!(await stat(resolvedManifest)).isFile()) {
    throw new TypeError("Extension manifest is not a file")
  }
  return resolvedManifest
}

/** Resolves and validates one package or directory extension source. */
export async function scanExtensionSource(
  source: ExtensionSource,
): Promise<ScannedExtension> {
  const packageRoot = await resolveSourceRoot(source)
  const manifestPath = await resolveManifestPath(packageRoot)

  const manifest = mergeManifestLayers([
    JSON.parse(await readFile(manifestPath, "utf8")) as unknown,
  ])
  const [frontendEntry, backendEntry] = await Promise.all([
    resolveEntry(packageRoot, manifest.entry.frontend),
    resolveEntry(packageRoot, manifest.entry.backend),
  ])

  return { manifest, packageRoot, frontendEntry, backendEntry }
}
