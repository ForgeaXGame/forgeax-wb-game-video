import { lstat, readFile, realpath, stat } from "node:fs/promises"
import { isAbsolute, relative, resolve, sep } from "node:path"
import { pathToFileURL } from "node:url"

import { WorkbenchError } from "../contracts/error.js"
import type { ScannedExtension } from "./scan-package.js"
import {
  defineWorkbenchExtension,
  type WorkbenchExtensionModule,
} from "./host-context.js"

export type ExtensionTrustPolicy = (
  extension: ScannedExtension,
) => boolean | Promise<boolean>

function isWithin(root: string, candidate: string): boolean {
  const path = relative(root, candidate)
  return (
    path === "" ||
    (!isAbsolute(path) && path !== ".." && !path.startsWith(`..${sep}`))
  )
}

/** Resolves the real extension root before resolving any package-relative file. */
export async function resolveTrustedPackageRoot(packageRoot: string): Promise<string> {
  const root = await realpath(packageRoot)
  if (!(await stat(root)).isDirectory()) {
    throw new TypeError("Extension package root is not a directory")
  }
  return root
}

/** Resolves one regular package file without allowing traversal or symlinks. */
export async function resolveTrustedPackageFile(
  packageRoot: string,
  entry: string,
): Promise<string> {
  if (entry.length === 0 || isAbsolute(entry)) {
    throw new TypeError("Extension entry must be a non-empty relative path")
  }
  const root = await resolveTrustedPackageRoot(packageRoot)
  const lexicalPath = resolve(root, entry)
  if (!isWithin(root, lexicalPath)) {
    throw new TypeError(`Extension entry is outside extension root: ${entry}`)
  }

  let cursor = root
  for (const segment of relative(root, lexicalPath).split(sep)) {
    cursor = resolve(cursor, segment)
    if ((await lstat(cursor)).isSymbolicLink()) {
      throw new TypeError(`Extension entry must not traverse a symlink: ${entry}`)
    }
  }

  const resolvedPath = await realpath(lexicalPath)
  if (!isWithin(root, resolvedPath)) {
    throw new TypeError(`Extension entry is outside extension root: ${entry}`)
  }
  if (!(await stat(resolvedPath)).isFile()) {
    throw new TypeError(`Extension entry is not a file: ${entry}`)
  }
  return resolvedPath
}

export async function readTrustedPackageJson(
  packageRoot: string,
  entry: string,
): Promise<{ readonly path: string; readonly value: unknown }> {
  const path = await resolveTrustedPackageFile(packageRoot, entry)
  return { path, value: JSON.parse(await readFile(path, "utf8")) as unknown }
}

function moduleCandidate(imported: Record<string, unknown>): unknown {
  return imported.default ?? imported.extension ?? imported
}

/** Imports a backend only after trust and fresh package-containment checks pass. */
export async function loadTrustedBackend(
  extension: ScannedExtension,
  isTrusted: ExtensionTrustPolicy,
): Promise<WorkbenchExtensionModule> {
  if (!(await isTrusted(extension))) {
    throw new WorkbenchError({
      code: "extension_untrusted",
      target: "extension",
      message: "Extension backend is not trusted",
      retryable: false,
    })
  }

  const backendPath = await resolveTrustedPackageFile(
    extension.packageRoot,
    extension.backendEntry,
  )
  const imported = (await import(pathToFileURL(backendPath).href)) as Record<
    string,
    unknown
  >
  return defineWorkbenchExtension(moduleCandidate(imported) as WorkbenchExtensionModule)
}
