export interface PackageExtensionSource {
  readonly kind: "package"
  readonly specifier: string
}

export interface DirectoryExtensionSource {
  readonly kind: "directory"
  readonly path: string
}

export type ExtensionSource = PackageExtensionSource | DirectoryExtensionSource

export function packageExtension(specifier: string): PackageExtensionSource {
  if (specifier.length === 0) {
    throw new TypeError("Package extension specifier must not be empty")
  }
  return { kind: "package", specifier }
}

export function directoryExtension(path: string): DirectoryExtensionSource {
  if (path.length === 0) {
    throw new TypeError("Directory extension path must not be empty")
  }
  return { kind: "directory", path }
}
