import { lstat, mkdir, readFile, realpath, writeFile } from "node:fs/promises"
import { dirname, isAbsolute, relative, resolve, sep } from "node:path"

import type {
  MediaCapability,
  ModelGateway,
} from "../contracts/adapters.js"

export interface BoundedGameFiles {
  read(relativePath: string): Promise<Uint8Array | null>
  write(relativePath: string, contents: Uint8Array): Promise<void>
}

export interface WorkbenchExtensionContext {
  readonly gameId: string
  readonly gameRoot: string
  readonly media: MediaCapability
  readonly models: ModelGateway
  readonly files: BoundedGameFiles
}

export type WorkbenchToolHandler = (
  context: WorkbenchExtensionContext,
  args: unknown,
) => unknown | Promise<unknown>

export interface SeedContext extends WorkbenchExtensionContext {}

export type GamePackageSeed = Record<string, unknown>

/** A framework-neutral request delegated to a trusted extension backend. */
export interface WorkbenchExtensionRouterRequest {
  readonly gameId: string
  readonly runtimeId: string
  readonly path: string
  readonly query: Readonly<Record<string, readonly string[]>>
  readonly method: string
  readonly headers: Readonly<Record<string, readonly string[]>>
  readonly body: Uint8Array<ArrayBufferLike>
}

/** Binary-safe result returned by a trusted extension router. */
export interface WorkbenchExtensionRouterResponse {
  readonly status: number
  readonly headers?: Readonly<Record<string, string | readonly string[]>>
  readonly body?: Uint8Array<ArrayBufferLike>
}

export interface WorkbenchExtensionRouter {
  handle(request: WorkbenchExtensionRouterRequest): Promise<WorkbenchExtensionRouterResponse> | WorkbenchExtensionRouterResponse
}

export interface WorkbenchExtensionModule {
  tools?: Record<string, WorkbenchToolHandler>
  gamePackage?: {
    platform: string
    createSeed(context: SeedContext): Promise<GamePackageSeed>
    validateSeed(seed: GamePackageSeed): Promise<void>
  }
  createRouter?: (context: WorkbenchExtensionContext) => WorkbenchExtensionRouter
}

function isWithin(root: string, candidate: string): boolean {
  const path = relative(root, candidate)
  return (
    path === "" ||
    (!isAbsolute(path) && path !== ".." && !path.startsWith(`..${sep}`))
  )
}

function assertRelativePath(relativePath: string): void {
  if (relativePath.length === 0 || isAbsolute(relativePath)) {
    throw new TypeError("Game file path must be a non-empty relative path")
  }
}

async function resolveExistingGamePath(
  gameRoot: string,
  relativePath: string,
): Promise<string> {
  assertRelativePath(relativePath)
  const root = await realpath(gameRoot)
  const candidate = resolve(root, relativePath)
  if (!isWithin(root, candidate)) {
    throw new TypeError("Game file path is outside the game root")
  }

  const relativeCandidate = relative(root, candidate)
  let cursor = root
  for (const segment of relativeCandidate.split(sep)) {
    cursor = resolve(cursor, segment)
    try {
      if ((await lstat(cursor)).isSymbolicLink()) {
        throw new TypeError("Game file path must not traverse a symlink")
      }
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") {
        break
      }
      throw error
    }
  }
  return candidate
}

function unavailableMedia(): MediaCapability {
  const unavailable = async (): Promise<never> => {
    throw new Error("Media capability is not configured")
  }
  return { list: unavailable, read: unavailable, put: unavailable }
}

function unavailableModels(): ModelGateway {
  const unavailable = async (): Promise<never> => {
    throw new Error("Model gateway is not configured")
  }
  return {
    generateText: unavailable,
    generateImage: unavailable,
    generateVideo: unavailable,
  }
}

export interface CreateWorkbenchExtensionContextOptions {
  readonly gameId: string
  readonly gameRoot: string
  readonly media?: MediaCapability
  readonly models?: ModelGateway
}

/** Creates the capability-bounded context passed to trusted tool handlers. */
export function createWorkbenchExtensionContext(
  options: CreateWorkbenchExtensionContextOptions,
): WorkbenchExtensionContext {
  const files: BoundedGameFiles = {
    async read(relativePath) {
      const path = await resolveExistingGamePath(options.gameRoot, relativePath)
      try {
        return new Uint8Array(await readFile(path))
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") {
          return null
        }
        throw error
      }
    },
    async write(relativePath, contents) {
      const path = await resolveExistingGamePath(options.gameRoot, relativePath)
      await mkdir(dirname(path), { recursive: true })
      await writeFile(path, contents)
    },
  }

  return Object.freeze({
    gameId: options.gameId,
    gameRoot: options.gameRoot,
    media: options.media ?? unavailableMedia(),
    models: options.models ?? unavailableModels(),
    files,
  })
}

/** Defines the small, product-neutral module surface accepted from a backend. */
export function defineWorkbenchExtension(
  extension: WorkbenchExtensionModule,
): WorkbenchExtensionModule {
  if (typeof extension !== "object" || extension === null) {
    throw new TypeError("Workbench extension must be an object")
  }
  if (
    extension.tools !== undefined &&
    (typeof extension.tools !== "object" || extension.tools === null)
  ) {
    throw new TypeError("Workbench extension tools must be an object")
  }
  for (const [toolId, handler] of Object.entries(extension.tools ?? {})) {
    if (toolId.length === 0 || typeof handler !== "function") {
      throw new TypeError("Workbench extension tools must map ids to functions")
    }
  }
  if (extension.createRouter !== undefined && typeof extension.createRouter !== "function") {
    throw new TypeError("Workbench extension createRouter must be a function")
  }
  return extension
}
