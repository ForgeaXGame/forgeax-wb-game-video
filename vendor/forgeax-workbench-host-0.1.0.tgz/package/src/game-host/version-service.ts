import type {
  CurrentVersion,
  GameVersion,
  VersionAdapter,
  WorkspaceAdapter,
} from "../contracts/adapters.js"
import { WorkbenchError } from "../contracts/error.js"
import {
  gamePackageFromFiles,
  PACKAGE_FILES,
  type GamePackage,
  type PackageFile,
} from "./package-files.js"

export interface VersionServiceOptions {
  readonly workspace: WorkspaceAdapter
  readonly versioning: VersionAdapter
}

function invalidHistoricalPackageError(): WorkbenchError {
  return new WorkbenchError({
    code: "version_package_invalid",
    target: "version",
    message: "Version does not contain a complete valid game package",
    retryable: false,
  })
}

function parseHistoricalJson(bytes: Uint8Array | null): unknown {
  if (bytes === null) {
    throw invalidHistoricalPackageError()
  }
  try {
    return JSON.parse(new TextDecoder().decode(bytes)) as unknown
  } catch {
    throw invalidHistoricalPackageError()
  }
}

/** Routes all versioning calls through the injected adapter without checkout operations. */
export class VersionService {
  readonly #options: VersionServiceOptions

  constructor(options: VersionServiceOptions) {
    this.#options = options
  }

  async create(gameId: string, message: string): Promise<GameVersion> {
    const gameRoot = await this.#root(gameId)
    await this.#options.versioning.ensureRepository(gameRoot)
    return this.#options.versioning.createVersion(gameRoot, message)
  }

  async current(gameId: string): Promise<CurrentVersion | null> {
    return this.#options.versioning.currentVersion(
      await this.#root(gameId),
    )
  }

  async list(gameId: string): Promise<GameVersion[]> {
    return this.#options.versioning.listVersions(
      await this.#root(gameId),
    )
  }

  async readAtTag(gameId: string, tag: string): Promise<GamePackage> {
    const gameRoot = await this.#root(gameId)
    const exists = (await this.#options.versioning.listVersions(gameRoot)).some((version) => version.tag === tag)
    if (!exists) {
      throw new WorkbenchError({ code: "version_not_found", target: "version", message: "Version was not found", retryable: false })
    }
    const entries = await Promise.all(
      PACKAGE_FILES.map(async (relativePath) => [
        relativePath,
        parseHistoricalJson(
          await this.#options.versioning.readFileAtVersion(
            gameRoot,
            tag,
            relativePath,
          ),
        ),
      ] as const),
    )
    return gamePackageFromFiles(new Map<PackageFile, unknown>(entries))
  }

  async #root(gameId: string): Promise<string> {
    try { return await this.#options.workspace.resolveGameRoot(gameId) }
    catch { throw new WorkbenchError({ code: "workspace_not_found", target: "workspace", message: "Game workspace was not found", retryable: false }) }
  }
}
