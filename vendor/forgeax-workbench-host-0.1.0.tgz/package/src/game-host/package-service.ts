import { link, lstat, mkdir, open, readFile, realpath, rename, stat, unlink } from "node:fs/promises"
import type { Stats } from "node:fs"
import { basename, dirname, join, relative } from "node:path"
import { randomUUID } from "node:crypto"

import type { CurrentVersion, GameVersion, MediaCapability, ModelGateway, VersionAdapter, WorkspaceAdapter } from "../contracts/adapters.js"
import { WorkbenchError } from "../contracts/error.js"
import type { WorkbenchExtensionModule } from "../node/host-context.js"
import { createWorkbenchExtensionContext } from "../node/host-context.js"
import { gamePackageFromFiles, gamePackageFromSeed, packageFiles, PACKAGE_FILES, type GamePackage, type GamePackageStatus, type PackageFile } from "./package-files.js"
import { SingleFlight } from "./single-flight.js"

export { PACKAGE_FILES, type GamePackage, type GamePackageStatus } from "./package-files.js"

const LOCK_FILE = ".workbench-package.lock"
const LOCK_RECLAIM_FILE = `${LOCK_FILE}.reclaim`
const JOURNAL_FILE = ".workbench-package.transaction.json"

export interface PackageFileWriter { write(targetPath: string, contents: Uint8Array): Promise<void> }
export interface PackageLockHooks {
  afterReclaimClaimPublished?(): Promise<void>
  onReclaimClaimWait?(): Promise<void>
  onLiveLockWait?(): Promise<void>
}
export interface GamePackageExtension { readonly manifest: { readonly id: string }; readonly gamePackage: NonNullable<WorkbenchExtensionModule["gamePackage"]> }
export interface InitializeGamePackageResult { readonly state: "initialized"; readonly package: GamePackage; readonly version: GameVersion | CurrentVersion }
export interface GamePackageServiceOptions { readonly workspace: WorkspaceAdapter; readonly versioning: VersionAdapter; readonly media?: MediaCapability; readonly models?: ModelGateway; readonly singleFlight?: SingleFlight; readonly packageFileWriter?: PackageFileWriter; readonly packageLockHooks?: PackageLockHooks }
interface PackageRead { readonly status: GamePackageStatus; readonly package?: GamePackage }
type JournalPhase = "prepared" | "replacing" | "version-pending"
interface Journal { readonly kind: "workbench-package"; readonly phase: JournalPhase; readonly replacement: number; readonly extensionId: string; readonly baseline: { tag: string; commitHash: string } | null; readonly files: readonly PackageFile[]; readonly previous: Partial<Record<PackageFile, string | null>> }
interface LockMetadata { readonly kind: "workbench-package-lock"; readonly token: string; readonly pid: number; readonly createdAt: string }
interface LockIdentity { readonly dev: string; readonly ino: string }
interface LockObservation { readonly identity: LockIdentity; readonly metadata: LockMetadata }
interface ReclaimMetadata {
  readonly kind: "workbench-package-lock-reclaim"
  readonly token: string
  readonly pid: number
  readonly createdAt: string
  readonly observed: LockIdentity & { readonly token: string }
}
interface OwnedFile { readonly identity: LockIdentity; readonly text: string }

function error(code: string, message: string): WorkbenchError { return new WorkbenchError({ code, target: "game_package", message, retryable: false }) }
function missing(e: unknown): boolean { return (e as NodeJS.ErrnoException).code === "ENOENT" }
function within(root: string, path: string): boolean { const r = relative(root, path); return r === "" || (!r.startsWith("..") && !r.includes(`..${process.platform === "win32" ? "\\" : "/"}`)) }
function isRecord(value: unknown): value is Record<string, unknown> { return value !== null && typeof value === "object" && !Array.isArray(value) }
function identity(value: Stats): LockIdentity { return { dev: String(value.dev), ino: String(value.ino) } }
function sameIdentity(left: LockIdentity, right: LockIdentity): boolean { return left.dev === right.dev && left.ino === right.ino }
function ownerIsAlive(pid: number): boolean { try { process.kill(pid, 0); return true } catch (e) { return (e as NodeJS.ErrnoException).code !== "ESRCH" } }
function lockMetadata(text: string): LockMetadata {
  const value = JSON.parse(text) as Partial<LockMetadata>
  if (value.kind !== "workbench-package-lock" || typeof value.token !== "string" || !Number.isSafeInteger(value.pid) || typeof value.createdAt !== "string") throw error("package_lock_invalid", "Game package lock metadata is invalid")
  return value as LockMetadata
}
function reclaimMetadata(text: string): ReclaimMetadata {
  const value = JSON.parse(text) as Partial<ReclaimMetadata>
  const observed = value.observed
  if (value.kind !== "workbench-package-lock-reclaim" || typeof value.token !== "string" || !Number.isSafeInteger(value.pid) || typeof value.createdAt !== "string" || typeof observed?.dev !== "string" || typeof observed?.ino !== "string" || typeof observed?.token !== "string") throw error("package_lock_reclaim_invalid", "Game package lock reclaim claim is invalid")
  return value as ReclaimMetadata
}
function abandonedReclaimError(claim: ReclaimMetadata): WorkbenchError {
  return new WorkbenchError({
    code: "package_lock_reclaim_abandoned",
    target: "game_package",
    message: `Game package lock reclaim claim ${claim.token} was abandoned by process ${claim.pid}`,
    retryable: false,
    details: { claimToken: claim.token, claimPid: claim.pid, observed: claim.observed },
  })
}

async function atomicWrite(path: string, contents: Uint8Array): Promise<void> {
  const parent = dirname(path); await mkdir(parent, { recursive: true })
  const temp = join(parent, `.${randomUUID()}.${basename(path)}.tmp`); let handle: Awaited<ReturnType<typeof open>> | undefined; let moved = false
  try { handle = await open(temp, "wx", 0o600); await handle.writeFile(contents); await handle.sync(); await handle.close(); handle = undefined; await rename(temp, path); moved = true; const d = await open(parent, "r"); try { await d.sync() } finally { await d.close() } }
  finally { await handle?.close(); if (!moved) await unlink(temp).catch((e: unknown) => { if (!missing(e)) throw e }) }
}
function json(value: unknown): Uint8Array { const s = JSON.stringify(value, null, 2); if (s === undefined) throw error("package_invalid", "Game package must contain JSON values for all owned files"); return new TextEncoder().encode(`${s}\n`) }
const PACKAGE_FILE_BY_KEY = {
  project: "project.json",
  blueprint: "blueprint.json",
  assetsManifest: "assets/manifest.json",
} as const satisfies Record<string, PackageFile>
function applyPackagePatch(current: GamePackage, patch: unknown): { value: GamePackage; files: PackageFile[] } {
  if (!isRecord(patch)) throw error("package_invalid", "Game package patch must be an object")
  const keys = Object.keys(patch)
  if (keys.length === 0 || keys.some((key) => !Object.hasOwn(PACKAGE_FILE_BY_KEY, key))) {
    throw error("package_invalid", "Game package patch must contain only project, blueprint, or assetsManifest")
  }
  const files = keys.map((key) => PACKAGE_FILE_BY_KEY[key as keyof typeof PACKAGE_FILE_BY_KEY])
  return {
    value: {
      project: Object.hasOwn(patch, "project") ? patch.project : current.project,
      blueprint: Object.hasOwn(patch, "blueprint") ? patch.blueprint : current.blueprint,
      assetsManifest: Object.hasOwn(patch, "assetsManifest") ? patch.assetsManifest : current.assetsManifest,
    },
    files,
  }
}

/** Manages only the portable three-file game package, never extension-specific files. */
export class GamePackageService {
  readonly #options: GamePackageServiceOptions; readonly #singleFlight: SingleFlight
  constructor(options: GamePackageServiceOptions) { this.#options = options; this.#singleFlight = options.singleFlight ?? new SingleFlight() }

  async status(gameId: string): Promise<GamePackageStatus> { const root = await this.#root(gameId); return this.#locked(root, async () => (await this.#read(root)).status) }
  async read(gameId: string): Promise<GamePackage> { const root = await this.#root(gameId); return this.#locked(root, async () => { const found = await this.#read(root); if (found.status.state === "inconsistent") throw error("package_inconsistent", "Game package is inconsistent and will not be overwritten"); if (!found.package) throw error("package_uninitialized", "Game package has not been initialized"); return found.package }) }

  initialize(gameId: string, extension: GamePackageExtension): Promise<InitializeGamePackageResult> {
    return this.#singleFlight.run(gameId, async () => { const root = await this.#root(gameId); return this.#locked(root, async () => {
      const pending = await this.#journal(root)
      if (pending?.phase === "version-pending") return this.#finishVersion(root, pending, true)
      const existing = await this.#read(root)
      if (existing.status.state === "inconsistent") throw error("package_inconsistent", "Game package is inconsistent and will not be overwritten")
      if (existing.package) { const version = await this.#options.versioning.currentVersion(root); if (version === null) throw error("package_version_pending", "Game package has no version"); return { state: "initialized", package: existing.package, version } }
      await this.#options.versioning.ensureRepository(root)
      const baseline = await this.#currentOrNull(root)
      const seed = await extension.gamePackage.createSeed(createWorkbenchExtensionContext({ gameId, gameRoot: root, media: this.#options.media, models: this.#options.models }))
      await extension.gamePackage.validateSeed(seed); const value = gamePackageFromSeed(seed)
      for (const [, item] of packageFiles(value)) json(item)
      const rechecked = await this.#read(root); if (rechecked.status.state !== "uninitialized") throw error("package_inconsistent", "Game package is inconsistent and will not be overwritten")
      const journal = await this.#replace(root, value, extension.manifest.id, baseline, true)
      return this.#finishVersion(root, journal, false)
    }) })
  }

  async update(gameId: string, patch: unknown): Promise<GamePackage> { const root = await this.#root(gameId); return this.#locked(root, async () => { if (await this.#journal(root)) throw error("package_version_pending", "Initial version creation is pending"); const current = await this.#read(root); if (current.status.state === "inconsistent") throw error("package_inconsistent", "Game package is inconsistent and will not be overwritten"); if (!current.package) throw error("package_uninitialized", "Game package has not been initialized"); const next = applyPackagePatch(current.package, patch); await this.#replace(root, next.value, "", null, false, next.files); return next.value }) }

  async #root(gameId: string): Promise<string> { try { const root = await realpath(await this.#options.workspace.resolveGameRoot(gameId)); const stat = await lstat(root); if (!stat.isDirectory()) throw error("package_path_invalid", "Game root must be a directory"); return root } catch (cause) { if (cause instanceof WorkbenchError) throw cause; throw new WorkbenchError({ code: "workspace_not_found", target: "workspace", message: "Game workspace was not found", retryable: false }) } }
  async #safe(root: string, relativePath: string, createParent = false): Promise<string> {
    let cursor = root; const parts = relativePath.split("/"); for (const part of parts.slice(0, -1)) { cursor = join(cursor, part); try { const st = await lstat(cursor); if (st.isSymbolicLink() || !st.isDirectory()) throw error("package_path_invalid", "Game package path must not traverse a symlink") } catch (e) { if (!missing(e)) throw e; if (!createParent) return join(root, relativePath); await mkdir(cursor); const st = await lstat(cursor); if (st.isSymbolicLink() || !st.isDirectory()) throw error("package_path_invalid", "Game package path must not traverse a symlink") } const actual = await realpath(cursor); if (!within(root, actual)) throw error("package_path_invalid", "Game package path is outside the game root") }
    const path = join(root, relativePath); try { if ((await lstat(path)).isSymbolicLink()) throw error("package_path_invalid", "Game package path must not traverse a symlink") } catch (e) { if (!missing(e)) throw e }
    return path
  }
  async #readFile(root: string, file: PackageFile): Promise<{ exists: boolean; valid: boolean; value?: unknown; bytes?: Uint8Array }> {
    const path = await this.#safe(root, file)
    try {
      const bytes = new Uint8Array(await readFile(path))
      try { return { exists: true, valid: true, value: JSON.parse(new TextDecoder().decode(bytes)), bytes } }
      catch { return { exists: true, valid: false, bytes } }
    } catch (e) { if (missing(e)) return { exists: false, valid: false }; throw e }
  }
  async #read(root: string): Promise<PackageRead> { const entries = await Promise.all(PACKAGE_FILES.map(async f => [f, await this.#readFile(root, f)] as const)); const present = entries.filter(([, v]) => v.exists); if (present.length === 0) return { status: { state: "uninitialized" } }; if (present.length !== 3 || entries.some(([, v]) => !v.valid)) return { status: { state: "inconsistent" } }; return { status: { state: "initialized" }, package: gamePackageFromFiles(new Map(entries.map(([f,v]) => [f,v.value] as const))) } }
  async #journal(root: string): Promise<Journal | null> { const path = await this.#safe(root, JOURNAL_FILE); try { const raw = JSON.parse(await readFile(path, "utf8")) as Partial<Journal>; const candidateFiles: unknown = raw.files === undefined ? [...PACKAGE_FILES] : raw.files; if (!Array.isArray(candidateFiles) || candidateFiles.some((file) => typeof file !== "string" || !PACKAGE_FILES.includes(file as PackageFile))) throw error("package_recovery_invalid", "Game package recovery journal is invalid"); const files = candidateFiles as PackageFile[]; if (raw.kind !== "workbench-package" || !["prepared", "replacing", "version-pending"].includes(raw.phase ?? "") || typeof raw.replacement !== "number" || typeof raw.extensionId !== "string" || !isRecord(raw.previous) || files.length === 0 || new Set(files).size !== files.length || files.some((file) => typeof raw.previous![file] !== "string" && raw.previous![file] !== null)) throw error("package_recovery_invalid", "Game package recovery journal is invalid"); return { ...(raw as Journal), files } } catch (e) { if (missing(e)) return null; throw e } }
  async #writeJournal(root: string, journal: Journal): Promise<void> { await atomicWrite(await this.#safe(root, JOURNAL_FILE, true), json(journal)) }
  async #clearJournal(root: string): Promise<void> { const path = await this.#safe(root, JOURNAL_FILE); await unlink(path).catch((e: unknown) => { if (!missing(e)) throw e }) }
  async #replace(root: string, value: GamePackage, extensionId: string, baseline: { tag: string; commitHash: string } | null, pendingVersion: boolean, files: readonly PackageFile[] = PACKAGE_FILES): Promise<Journal> {
    if (pendingVersion && files.length !== PACKAGE_FILES.length) throw error("package_invalid", "Initial package replacement must contain every owned file")
    const encoded = new Map<PackageFile, Uint8Array>(); for (const [file, item] of packageFiles(value)) if (files.includes(file)) encoded.set(file, json(item))
    const previous: Partial<Record<PackageFile, string | null>> = {}; for (const file of files) { const old = await this.#readFile(root, file); previous[file] = old.exists ? Buffer.from(old.bytes!).toString("base64") : null }
    let journal: Journal = { kind: "workbench-package", phase: "prepared", replacement: 0, extensionId, baseline, files: [...files], previous }; await this.#writeJournal(root, journal)
    try { for (const [index, file] of files.entries()) { journal = { ...journal, phase: "replacing", replacement: index }; await this.#writeJournal(root, journal); const path = await this.#safe(root, file, true); const contents = encoded.get(file)!; if (this.#options.packageFileWriter) await this.#options.packageFileWriter.write(path, contents); else await atomicWrite(path, contents) } if (!pendingVersion) await this.#clearJournal(root); else { journal = { ...journal, phase: "version-pending", replacement: files.length }; await this.#writeJournal(root, journal) } return journal }
    catch (e) { await this.#rollback(root, journal); throw e }
  }
  async #rollback(root: string, journal: Journal): Promise<void> { for (const file of journal.files) { const old = journal.previous[file]!; const path = await this.#safe(root, file, old !== null); if (old === null) await unlink(path).catch((e: unknown) => { if (!missing(e)) throw e }); else await atomicWrite(path, new Uint8Array(Buffer.from(old, "base64"))) } await this.#clearJournal(root) }
  async #finishVersion(root: string, journal: Journal, inspectCurrent: boolean): Promise<InitializeGamePackageResult> {
    let version: GameVersion | CurrentVersion
    if (inspectCurrent) {
      await this.#options.versioning.ensureRepository(root)
      const current = await this.#options.versioning.currentVersion(root)
      if (current !== null && (!journal.baseline || current.tag !== journal.baseline.tag || current.commitHash !== journal.baseline.commitHash)) { await this.#clearJournal(root); return { state: "initialized", package: (await this.#read(root)).package!, version: current } }
    }
    version = await this.#options.versioning.createVersion(root, `[workbench] initialize ${journal.extensionId}`)
    await this.#clearJournal(root)
    return { state: "initialized", package: (await this.#read(root)).package!, version }
  }
  async #currentOrNull(root: string): Promise<{ tag: string; commitHash: string } | null> { const current = await this.#options.versioning.currentVersion(root); return current === null ? null : { tag: current.tag, commitHash: current.commitHash } }
  async #observeLock(path: string): Promise<LockObservation | null> {
    try {
      const before = identity(await stat(path))
      const metadata = lockMetadata(await readFile(path, "utf8"))
      const after = identity(await stat(path))
      return sameIdentity(before, after) ? { identity: after, metadata } : null
    } catch (e) { if (missing(e)) return null; throw e }
  }
  async #ownedFileMatches(path: string, owned: OwnedFile): Promise<boolean> {
    try { return sameIdentity(identity(await stat(path)), owned.identity) && await readFile(path, "utf8") === owned.text }
    catch (e) { if (missing(e)) return false; throw e }
  }
  async #releaseOwnedFile(path: string, owned: OwnedFile): Promise<void> {
    if (await this.#ownedFileMatches(path, owned)) await unlink(path)
  }
  async #inspectReclaimClaim(root: string): Promise<"none" | "live"> {
    const path = await this.#safe(root, LOCK_RECLAIM_FILE)
    try {
      const before = identity(await stat(path))
      const claim = reclaimMetadata(await readFile(path, "utf8"))
      const after = identity(await stat(path))
      if (!sameIdentity(before, after)) return "none"
      if (!ownerIsAlive(claim.pid)) throw abandonedReclaimError(claim)
      await this.#options.packageLockHooks?.onReclaimClaimWait?.()
      return "live"
    } catch (e) { if (missing(e)) return "none"; throw e }
  }
  async #waitForReclaimClaimRelease(root: string): Promise<void> {
    while (await this.#inspectReclaimClaim(root) === "live") {
      await new Promise(resolve => setTimeout(resolve, 10))
    }
  }
  async #publishReclaimClaim(root: string, observed: LockObservation): Promise<OwnedFile | null> {
    const path = await this.#safe(root, LOCK_RECLAIM_FILE, true)
    const claim: ReclaimMetadata = {
      kind: "workbench-package-lock-reclaim",
      token: randomUUID(),
      pid: process.pid,
      createdAt: new Date().toISOString(),
      observed: { ...observed.identity, token: observed.metadata.token },
    }
    const text = JSON.stringify(claim)
    const temp = await this.#safe(root, `${LOCK_RECLAIM_FILE}.${claim.token}.tmp`, true)
    let handle: Awaited<ReturnType<typeof open>> | undefined
    let owned: OwnedFile | undefined
    try {
      handle = await open(temp, "wx", 0o600)
      await handle.writeFile(text)
      await handle.sync()
      await handle.close()
      handle = undefined
      try { await link(temp, path) }
      catch (e) { if ((e as NodeJS.ErrnoException).code === "EEXIST") return null; throw e }
      owned = { identity: identity(await stat(path)), text }
      const directory = await open(root, "r")
      try { await directory.sync() } finally { await directory.close() }
      return owned
    } catch (e) {
      if (owned) await this.#releaseOwnedFile(path, owned)
      throw e
    } finally {
      await handle?.close()
      await unlink(temp).catch((e: unknown) => { if (!missing(e)) throw e })
    }
  }
  async #authoritativeMatches(path: string, observed: LockObservation): Promise<boolean> {
    const current = await this.#observeLock(path)
    return current !== null && sameIdentity(current.identity, observed.identity) && current.metadata.token === observed.metadata.token
  }
  async #reclaim(root: string, path: string, observed: LockObservation): Promise<void> {
    const claimPath = await this.#safe(root, LOCK_RECLAIM_FILE, true)
    const owned = await this.#publishReclaimClaim(root, observed)
    if (!owned) { await this.#inspectReclaimClaim(root); return }
    try {
      await this.#options.packageLockHooks?.afterReclaimClaimPublished?.()
      if (!await this.#ownedFileMatches(claimPath, owned)) throw error("package_lock_reclaim_lost", "Game package lock reclaim claim ownership was lost")
      if (!await this.#authoritativeMatches(path, observed)) return
      if (!await this.#ownedFileMatches(claimPath, owned)) throw error("package_lock_reclaim_lost", "Game package lock reclaim claim ownership was lost")
      await unlink(path)
    } finally {
      await this.#releaseOwnedFile(claimPath, owned)
    }
  }
  async #locked<T>(root: string, work: () => Promise<T>): Promise<T> {
    const path = await this.#safe(root, LOCK_FILE, true)
    const lock: LockMetadata = { kind: "workbench-package-lock", token: randomUUID(), pid: process.pid, createdAt: new Date().toISOString() }
    const text = JSON.stringify(lock)
    let owned: OwnedFile | undefined
    const publish = async () => {
      const temp = await this.#safe(root, `.${LOCK_FILE}.${lock.token}.tmp`, true)
      let handle: Awaited<ReturnType<typeof open>> | undefined
      try {
        handle = await open(temp, "wx", 0o600)
        await handle.writeFile(text)
        await handle.sync()
        await handle.close()
        handle = undefined
        await link(temp, path)
        owned = { identity: identity(await stat(path)), text }
        const directory = await open(root, "r")
        try { await directory.sync() } finally { await directory.close() }
      } finally {
        await handle?.close()
        await unlink(temp).catch((e: unknown) => { if (!missing(e)) throw e })
      }
    }
    for (;;) {
      if (await this.#inspectReclaimClaim(root) === "live") {
        await new Promise(resolve => setTimeout(resolve, 10))
        continue
      }
      try {
        await publish()
        await this.#waitForReclaimClaimRelease(root)
        break
      }
      catch (e) {
        if ((e as NodeJS.ErrnoException).code !== "EEXIST") throw e
        if (await this.#inspectReclaimClaim(root) === "none") {
          const observed = await this.#observeLock(path)
          if (observed) {
            if (ownerIsAlive(observed.metadata.pid)) await this.#options.packageLockHooks?.onLiveLockWait?.()
            else await this.#reclaim(root, path, observed)
          }
        }
        await new Promise(resolve => setTimeout(resolve, 10))
      }
    }
    try {
      const journal = await this.#journal(root)
      if (journal && journal.phase !== "version-pending") await this.#rollback(root, journal)
      return await work()
    } finally {
      if (owned) await this.#releaseOwnedFile(path, owned)
    }
  }
}
