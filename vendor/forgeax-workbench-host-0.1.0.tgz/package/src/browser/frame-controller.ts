import {
  WorkbenchSessionContextSchema,
  type WorkbenchSessionContext,
} from "../contracts/session.js"

export const WORKBENCH_HANDSHAKE_REQUEST = "workbench:handshake:request"
export const WORKBENCH_HANDSHAKE_RESPONSE = "workbench:handshake:response"

export interface WorkbenchFrameWindow {
  postMessage(
    message: unknown,
    targetOrigin: string,
    transfer?: Transferable[],
  ): void
}

export interface WorkbenchOwnerWindow {
  addEventListener(
    type: "message",
    listener: (event: MessageEvent) => void,
  ): void
  removeEventListener(
    type: "message",
    listener: (event: MessageEvent) => void,
  ): void
}

export interface WorkbenchFrameControllerOptions {
  readonly frameWindow: WorkbenchFrameWindow
  readonly ownerWindow: WorkbenchOwnerWindow
  /** Origin observed on the iframe's handshake request. */
  readonly origin: string
  /** PostMessage target used for the response; opaque sandbox frames require "*". */
  readonly targetOrigin?: string
  readonly context: WorkbenchSessionContext
  readonly createMessageChannel?: () => MessageChannel
  readonly onHandshake?: (port: MessagePort) => void
}

export interface WorkbenchFrameController {
  readonly active: boolean
  close(): void
}

function isHandshakeRequest(value: unknown): value is { nonce: string } {
  return (
    value !== null &&
    typeof value === "object" &&
    (value as { type?: unknown }).type === WORKBENCH_HANDSHAKE_REQUEST &&
    typeof (value as { nonce?: unknown }).nonce === "string" &&
    (value as { nonce: string }).nonce.length > 0
  )
}

/**
 * Attaches one nonce-bound handshake to an iframe. A controller owns the only
 * host-side MessagePort and must be closed when the frame is replaced.
 */
export function attachWorkbenchFrame(
  options: WorkbenchFrameControllerOptions,
): WorkbenchFrameController {
  // Parsing at the process boundary strips accidental host-only properties.
  const session = WorkbenchSessionContextSchema.parse(options.context)
  const targetOrigin = options.targetOrigin ?? options.origin
  let active = false
  let closed = false
  let port: MessagePort | undefined

  const onMessage = (event: MessageEvent): void => {
    if (
      closed ||
      active ||
      event.origin !== options.origin ||
      event.source !== options.frameWindow ||
      !isHandshakeRequest(event.data)
    ) {
      return
    }

    const channel = (options.createMessageChannel ?? (() => new MessageChannel()))()
    port = channel.port1
    port.start()
    active = true
    options.frameWindow.postMessage(
      {
        type: WORKBENCH_HANDSHAKE_RESPONSE,
        nonce: event.data.nonce,
        context: session,
      },
      targetOrigin,
      [channel.port2],
    )
    options.onHandshake?.(port)
  }

  options.ownerWindow.addEventListener("message", onMessage)
  return Object.freeze({
    get active(): boolean {
      return active
    },
    close(): void {
      if (closed) return
      closed = true
      options.ownerWindow.removeEventListener("message", onMessage)
      port?.close()
      port = undefined
      active = false
    },
  })
}
