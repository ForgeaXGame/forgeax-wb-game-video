const schemePattern = /^[a-z][a-z\d+.-]*:/iu
const encodedSeparatorPattern = /%(?:2f|5c)/iu

function decodeForValidation(value: string): string {
  let decoded = value
  for (let attempt = 0; attempt < 4; attempt += 1) {
    if (encodedSeparatorPattern.test(decoded)) {
      throw new TypeError("Workbench URLs must not contain encoded separators")
    }
    let next: string
    try {
      next = decodeURIComponent(decoded)
    } catch {
      throw new TypeError("Workbench URLs must use valid percent encoding")
    }
    if (next === decoded) return decoded
    decoded = next
  }
  return decoded
}

function validateRelativePath(candidate: string): string {
  if (
    candidate.length === 0 ||
    candidate.startsWith("//") ||
    schemePattern.test(candidate) ||
    candidate.includes("\\")
  ) {
    throw new TypeError("Workbench URLs must be contained relative paths")
  }
  // The extension API accepts its conventional "/assets" spelling as a path
  // beneath the endpoint, never as an origin-rooted URL.
  const relative = candidate.startsWith("/") ? candidate.slice(1) : candidate
  const decoded = decodeForValidation(relative)
  if (decoded.startsWith("/") || decoded.includes("\\")) {
    throw new TypeError("Workbench URLs must not contain escaped separators")
  }
  const [pathname, queryAndFragment = ""] = decoded.split(/[?#]/u, 2)
  if (
    pathname.length === 0 ||
    pathname.split("/").some((segment) => segment === "." || segment === "..") ||
    queryAndFragment.includes("..") ||
    queryAndFragment.includes("\\")
  ) {
    throw new TypeError("Workbench URLs must not escape their configured base")
  }
  return relative
}

function normalizedBase(baseUrl: string): {
  readonly base: URL
  readonly relative: boolean
} {
  if (baseUrl.length === 0 || baseUrl.startsWith("//")) {
    throw new TypeError("Workbench base URL must not be empty or protocol-relative")
  }
  const relative = !schemePattern.test(baseUrl)
  if (relative && !baseUrl.startsWith("/")) {
    throw new TypeError("Relative Workbench base URLs must start with a slash")
  }
  const base = new URL(baseUrl, "https://workbench.invalid")
  if (base.search || base.hash || base.pathname.includes("\\")) {
    throw new TypeError("Workbench base URLs must be path-only directories")
  }
  base.pathname = base.pathname.endsWith("/")
    ? base.pathname
    : `${base.pathname}/`
  return { base, relative }
}

/** Resolves a safe path beneath a configured API base or extension endpoint. */
export function resolveContainedUrl(baseUrl: string, candidate: string): string {
  const relativeCandidate = validateRelativePath(candidate)
  const { base, relative } = normalizedBase(baseUrl)
  const resolved = new URL(relativeCandidate, base)
  if (
    resolved.origin !== base.origin ||
    !resolved.pathname.startsWith(base.pathname)
  ) {
    throw new TypeError("Workbench URL escapes its configured base")
  }
  return relative
    ? `${resolved.pathname}${resolved.search}${resolved.hash}`
    : resolved.toString()
}
