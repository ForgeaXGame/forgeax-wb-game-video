import { resolveContainedUrl } from "./url-containment.js"

export interface WorkbenchCatalogEntry {
  readonly extensionId: string
  readonly runtimeId: string
  readonly title: string
  readonly icon?: string
  readonly surface?: string
  readonly panes?: unknown
  readonly runtimeUrl: string
}

export type WorkbenchFetch = (
  input: RequestInfo | URL,
  init?: RequestInit,
) => Promise<Response>

export interface WorkbenchBrowserClientOptions {
  /** The explicit Workbench HTTP base, ending in the API version directory. */
  readonly baseUrl: string
  readonly gameId: string
  readonly fetch?: WorkbenchFetch
}

export interface WorkbenchBrowserClient {
  readonly gameId: string
  catalog(signal?: AbortSignal): Promise<WorkbenchCatalogEntry[]>
}

interface CatalogWireEntry {
  readonly extensionId: unknown
  readonly runtimeId: unknown
  readonly title: unknown
  readonly icon?: unknown
  readonly surface?: unknown
  readonly panes?: unknown
  readonly runtimeUrl: unknown
}

function requireString(value: unknown, field: string): string {
  if (typeof value !== "string" || value.length === 0) {
    throw new TypeError(`Invalid workbench catalog ${field}`)
  }
  return value
}

function parseCatalogEntry(value: unknown, baseUrl: string): WorkbenchCatalogEntry {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError("Invalid workbench catalog entry")
  }
  const entry = value as CatalogWireEntry
  const icon = entry.icon
  const surface = entry.surface
  if (icon !== undefined && typeof icon !== "string") {
    throw new TypeError("Invalid workbench catalog icon")
  }
  if (surface !== undefined && typeof surface !== "string") {
    throw new TypeError("Invalid workbench catalog surface")
  }
  return Object.freeze({
    extensionId: requireString(entry.extensionId, "extensionId"),
    runtimeId: requireString(entry.runtimeId, "runtimeId"),
    title: requireString(entry.title, "title"),
    ...(icon === undefined ? {} : { icon }),
    ...(surface === undefined ? {} : { surface }),
    ...(entry.panes === undefined ? {} : { panes: entry.panes }),
    runtimeUrl: resolveContainedUrl(
      baseUrl,
      requireString(entry.runtimeUrl, "runtimeUrl"),
    ),
  })
}

/** Creates a catalog reader without deriving host paths or ids from the page URL. */
export function createWorkbenchBrowserClient(
  options: WorkbenchBrowserClientOptions,
): WorkbenchBrowserClient {
  const baseUrl = options.baseUrl
  const fetcher = options.fetch ?? globalThis.fetch
  if (typeof fetcher !== "function") {
    throw new TypeError("A fetch implementation is required")
  }
  if (options.gameId.length === 0) {
    throw new TypeError("gameId must not be empty")
  }

  return Object.freeze({
    gameId: options.gameId,
    async catalog(signal?: AbortSignal): Promise<WorkbenchCatalogEntry[]> {
      const catalogUrl = `${resolveContainedUrl(baseUrl, "catalog")}?${new URLSearchParams({ gameId: options.gameId }).toString()}`
      const response = await fetcher(catalogUrl, { signal })
      if (!response.ok) {
        throw new Error(`Workbench catalog request failed with ${response.status}`)
      }
      const payload: unknown = await response.json()
      const entries = Array.isArray(payload)
        ? payload
        : payload !== null &&
            typeof payload === "object" &&
            Array.isArray((payload as { entries?: unknown }).entries)
          ? (payload as { entries: unknown[] }).entries
          : undefined
      if (entries === undefined) {
        throw new TypeError("Workbench catalog response must be an array")
      }
      return entries.map((entry) => parseCatalogEntry(entry, baseUrl))
    },
  })
}
