# Changelog

## 0.1.0

- Initial portable Workbench host release, including contracts, trusted extension loading,
  game-package lifecycle, browser clients, framework HTTP adapters, Vite development
  middleware, and in-memory test adapters.
- Bind product model adapters to the authoritative game id before exposing model
  capabilities to extensions, and include font assets in the shared media contract.
- Scope package and version IO to adapter-owned, no-follow game-root authorities;
  only package initialization may create a validated missing game directory.
