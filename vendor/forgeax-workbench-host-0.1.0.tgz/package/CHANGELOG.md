# Changelog

## 0.1.0

- Initial portable Workbench host release, including contracts, trusted extension loading,
  game-package lifecycle, browser clients, framework HTTP adapters, Vite development
  middleware, and in-memory test adapters.
