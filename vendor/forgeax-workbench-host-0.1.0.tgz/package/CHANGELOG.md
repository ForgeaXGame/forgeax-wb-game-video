# Changelog

## 0.1.0

- Initial portable Workbench host release, including contracts, trusted extension loading,
  game-package lifecycle, browser clients, framework HTTP adapters, Vite development
  middleware, and in-memory test adapters.
- Bind product model adapters to the authoritative game id before exposing model
  capabilities to extensions, and include font assets in the shared media contract.
- Scope package and version IO to adapter-owned, no-follow game-root authorities;
  only package initialization may create a validated missing game directory.
- Keep trusted tool handlers, extension routers, response materialization, and
  game component reads inside the same adapter-owned game-root authority.
- Require explicit scoped files when constructing an extension context; retain
  pathname-bounded files only as a named development/testing helper.
