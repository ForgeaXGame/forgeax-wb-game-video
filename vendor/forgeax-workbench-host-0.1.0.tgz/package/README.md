# @forgeax/workbench-host

Portable, adapter-driven host primitives for trusted Workbench extensions.

Use `/node` and `/game-host` to create the host, then project its approved operations
through either `/http/fastify` or `/http/hono`. The `/vite` entry is development-only;
it requires an existing host and refuses to run in production. Browser-safe clients are
available from `/browser`, `/extension`, and `/react`.

The HTTP layer serves runtime and component files only after realpath containment,
symlink, hidden-file, range, and ETag checks. It intentionally exposes no package roots,
backend paths, or requested environment values.
