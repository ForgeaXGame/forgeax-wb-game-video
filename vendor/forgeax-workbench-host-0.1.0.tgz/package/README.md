# @forgeax/workbench-host

Portable, adapter-driven host primitives for trusted Workbench extensions.

Use `/node` and `/game-host` to create the host, then project its approved operations
through either `/http/fastify` or `/http/hono`. The `/vite` entry is development-only;
it requires an existing host and refuses to run in production. Browser-safe clients are
available from `/browser`, `/extension`, and `/react`.

The HTTP layer serves runtime and component files only after realpath containment,
symlink, hidden-file, range, and ETag checks. It intentionally exposes no package roots,
backend paths, or requested environment values.

Product model adapters implement `ModelGateway`, whose text, image, and video methods
receive the authoritative `gameId` as their first argument. Trusted extensions receive
only the game-bound `context.models` capability, so extension inputs cannot select a
different game. Shared media records support `audio`, `font`, `image`, and `video`.

Package and history operations use `WorkspaceAdapter.withGameRoot`. The adapter owns
the directory authority for the full callback and supplies game-bound `files` and
path-free `versions` capabilities. Implementations must use a genuine dirfd,
native/RPC handle, or equivalent no-follow primitive that remains bound when the
user-facing game path is renamed or replaced; pathname revalidation alone is not
sufficient. Only package initialization requests `{ create: true }`. Status, reads,
updates, and every version operation use `{ create: false }` and never create a
missing workspace. `resolveGameRoot` remains for descriptive/static-serving paths and
is never used by the shared package or version services for IO.
