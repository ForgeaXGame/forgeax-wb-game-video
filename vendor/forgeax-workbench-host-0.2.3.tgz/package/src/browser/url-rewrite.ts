export type RewriteRule = {
  from: RegExp
  to: string
}

export function assertRewriteRules(rules: readonly RewriteRule[]): void {
  if (!Array.isArray(rules)) {
    throw new Error("[workbench-host] rewrite must be an array")
  }
  for (const [i, rule] of rules.entries()) {
    if (!(rule?.from instanceof RegExp) || typeof rule?.to !== "string") {
      throw new Error(`[workbench-host] invalid rewrite rule at index ${i}`)
    }
  }
}

function splitUrl(
  url: string,
): {
  origin: string
  path: string
  search: string
  hash: string
  absolute: boolean
} | null {
  const absolute = /^https?:\/\//i.test(url)
  if (!absolute && !url.startsWith("/")) return null
  if (url.startsWith("//")) return null
  let u: URL
  try {
    u = new URL(url, "http://forgeax.local")
  } catch {
    return null
  }
  return {
    origin: absolute ? u.origin : "",
    path: u.pathname,
    search: u.search,
    hash: u.hash,
    absolute,
  }
}

export function rewriteUrl(
  url: string,
  rules: readonly RewriteRule[],
): string {
  assertRewriteRules(rules)
  const parts = splitUrl(url)
  if (!parts) return url
  let path = parts.path
  for (const rule of rules) {
    if (!rule.from.test(path)) continue
    path = path.replace(rule.from, rule.to)
    break
  }
  const rest = `${path}${parts.search}${parts.hash}`
  return parts.absolute ? `${parts.origin}${rest}` : rest
}

export function createRewritingFetch(
  rules: readonly RewriteRule[],
  baseFetch?: typeof fetch,
): typeof fetch {
  assertRewriteRules(rules)
  const callFetch = baseFetch ?? globalThis.fetch.bind(globalThis)
  const staticSource = baseFetch ?? globalThis.fetch
  const wrapped = (input: RequestInfo | URL, init?: RequestInit) => {
    if (typeof input === "string") {
      return callFetch(rewriteUrl(input, rules), init)
    }
    if (input instanceof URL) {
      return callFetch(rewriteUrl(input.href, rules), init)
    }
    const next = rewriteUrl(input.url, rules)
    if (next === input.url) return callFetch(input, init)
    return callFetch(new Request(next, input), init)
  }
  return Object.assign(wrapped, staticSource)
}
