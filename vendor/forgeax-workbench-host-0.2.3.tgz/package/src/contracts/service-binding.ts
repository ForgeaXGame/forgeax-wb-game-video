import type { MediaBody } from "./adapters.js"

/** Response returned by a host-owned service binding. */
export interface ServiceResponse {
  readonly status: number
  readonly headers: Readonly<Record<string, string>>
  readonly body: Uint8Array
}

export interface ServiceRequest {
  readonly path: string
  readonly method: "GET" | "POST"
  readonly headers?: Readonly<Record<string, string>>
  readonly json?: unknown
  readonly body?: Uint8Array
  readonly signal?: AbortSignal
}

export interface ServiceStageMediaInput {
  readonly gameId: string
  readonly filename: string
  readonly contentType: string
  readonly bytes: Uint8Array
  readonly signal?: AbortSignal
}

export interface ServiceDownloadInput {
  readonly locator: string
  readonly maxBytes: number
  readonly allowedContentTypes: readonly string[]
  readonly signal?: AbortSignal
}

/**
 * Error metadata used by the broker to distinguish an unsubmitted request from
 * one whose outcome is unknown. It intentionally contains no product details.
 */
export class ServiceRequestError extends Error {
  readonly code: string
  readonly requestReachedUpstream: boolean
  readonly retryAfterMs?: number
  readonly status?: number

  constructor(input: {
    code: string
    message: string
    requestReachedUpstream: boolean
    retryAfterMs?: number
    status?: number
  }) {
    super(input.message)
    this.name = "ServiceRequestError"
    this.code = input.code
    this.requestReachedUpstream = input.requestReachedUpstream
    this.retryAfterMs = input.retryAfterMs
    this.status = input.status
  }
}

/** Product-owned service transport, exposed only to the host registry. */
export interface ServiceBinding {
  readonly id: string
  scope(gameId: string): Promise<string>
  request(input: ServiceRequest & { readonly gameId: string }): Promise<ServiceResponse>
  stageMedia(input: ServiceStageMediaInput): Promise<{ readonly locator: string }>
  download(input: ServiceDownloadInput & { readonly gameId: string }): Promise<MediaBody>
}

/** Scoped service access exposed to a selected capability provider. */
export interface ServiceCapability {
  scope(serviceId: string): Promise<string>
  request(serviceId: string, input: ServiceRequest): Promise<ServiceResponse>
  stageMedia(
    serviceId: string,
    input: Omit<ServiceStageMediaInput, "gameId">,
  ): Promise<{ readonly locator: string }>
}
