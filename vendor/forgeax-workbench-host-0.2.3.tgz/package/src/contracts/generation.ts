import type {
  MediaAsset,
  MediaCapability,
  VideoGenerationInput,
  VideoGenerationResult,
} from "./adapters.js"
import type { ServiceCapability } from "./service-binding.js"

/** Statuses used by both the host-facing generation gateway and durable broker. */
export type GenerationJobStatus =
  | "created"
  | "submitting"
  | "polling"
  | "output_pending_import"
  | "queued"
  | "running"
  | "importing"
  | "succeeded"
  | "failed"
  | "cancelled"
  | "submission_unknown"

export type GenerationStatus =
  | "queued"
  | "running"
  | "importing"
  | "succeeded"
  | "failed"
  | "cancelled"
  | "submission_unknown"

/** Public, credential-free generation record. Fields are optional only where the
 * two compatible broker APIs intentionally use different identifiers. */
export interface GenerationJob {
  readonly jobId: string
  readonly gameId: string
  readonly requestId: string
  readonly providerId?: string
  readonly externalId?: string | null
  readonly providerReceipt?: unknown
  readonly status: GenerationJobStatus
  readonly progress?: number
  readonly assets: readonly MediaAsset[]
  readonly error?: { readonly code: string; readonly message: string; readonly retryable?: boolean }
  readonly createdAt: string
  readonly updatedAt: string
}

/** Host adapter contract used by the game workbench runtime. */
export interface WorkbenchGenerationBroker {
  start(gameId: string, input: VideoGenerationInput): Promise<GenerationJob>
  get(gameId: string, jobId: string): Promise<GenerationJob>
  cancel(gameId: string, jobId: string): Promise<void>
  generateVideo(gameId: string, input: VideoGenerationInput): Promise<VideoGenerationResult>
  recover(gameId: string): Promise<readonly GenerationJob[]>
}

export interface ProviderMediaOutput {
  readonly serviceId: string
  readonly locator: string
  readonly filename: string
  readonly contentType: string
}

export interface ProviderExecutionContext {
  readonly gameId: string
  readonly traceId: string
  readonly media: MediaCapability
  readonly services: ServiceCapability
}

export type ProviderTaskStatus =
  | { readonly status: "polling"; readonly progress?: number }
  | { readonly status: "succeeded"; readonly outputs: readonly ProviderMediaOutput[] }
  | { readonly status: "failed"; readonly code: string; readonly message: string; readonly retryable: boolean }
  | { readonly status: "cancelled" }

export interface VideoGenerationProviderV1 {
  submit(context: ProviderExecutionContext, input: VideoGenerationInput): Promise<{ readonly providerTaskId: string }>
  query(context: ProviderExecutionContext, providerTaskId: string): Promise<ProviderTaskStatus>
  cancel?(context: ProviderExecutionContext, providerTaskId: string): Promise<void>
}

export interface VideoGenerationGateway {
  start(input: VideoGenerationInput): Promise<GenerationJob>
  get(jobId: string): Promise<GenerationJob>
  cancel(jobId: string): Promise<void>
  generateVideo(input: VideoGenerationInput): Promise<VideoGenerationResult>
}

/** The versioned extension-platform contract used for asynchronous video work. */
export const VIDEO_GENERATION_CAPABILITY = Object.freeze({
  id: "media.video.generate",
  version: 1,
})

export interface GenerationServiceBinding {
  readonly id: string
  readonly invoke: (input: unknown) => unknown | PromiseLike<unknown>
}

/** Product adapters own service credentials; providers receive only this resolver. */
export interface ServiceBindingResolver {
  get(id: string): GenerationServiceBinding | undefined
  require(id: string): GenerationServiceBinding
  list(): readonly string[]
}

export interface GenerationProviderContext {
  readonly gameId: string
  readonly requestId: string
  readonly serviceBindings: ServiceBindingResolver
}

export interface GenerationSubmitOperation {
  readonly kind: "submit"
  readonly input: VideoGenerationInput
  readonly idempotencyKey: string
}

export interface GenerationPollOperation {
  readonly kind: "poll"
  readonly externalId: string
  readonly receipt: unknown
}

export type GenerationCapabilityInvocation = GenerationSubmitOperation | GenerationPollOperation

export interface GeneratedMedia {
  readonly filename: string
  readonly contentType: string
  readonly bytes: Uint8Array
  readonly metadata?: Record<string, unknown>
}

export type GenerationProviderStatus = "queued" | "running" | "succeeded" | "failed" | "cancelled"

interface GenerationProviderResultBase {
  readonly externalId: string
  readonly receipt?: unknown
  readonly error?: { readonly code: string; readonly message: string }
}

export interface SuccessfulGenerationProviderResult extends GenerationProviderResultBase {
  readonly status: "succeeded"
  readonly outputs: readonly [GeneratedMedia, ...GeneratedMedia[]]
}

export interface PendingGenerationProviderResult extends GenerationProviderResultBase {
  readonly status: "queued" | "running"
  readonly outputs?: never
}

export interface TerminalGenerationProviderResult extends GenerationProviderResultBase {
  readonly status: "failed" | "cancelled"
  readonly outputs?: never
}

export type GenerationProviderResult =
  | SuccessfulGenerationProviderResult
  | PendingGenerationProviderResult
  | TerminalGenerationProviderResult

export interface CapabilityProviderRegistryLike<Context> {
  resolve(ref: { readonly id: string; readonly version: number }, providerId?: string): { readonly providerId: string }
  invoke<Output>(ref: { readonly id: string; readonly version: number }, input: unknown, context: Context, providerId?: string): Promise<Output>
}

export interface GenerationReceiptStore {
  get(gameId: string, requestId: string): Promise<GenerationJob | null>
  createIfAbsent(job: GenerationJob): Promise<{ readonly created: boolean; readonly job: GenerationJob }>
  put(job: GenerationJob): Promise<void>
  list(gameId: string): Promise<readonly GenerationJob[]>
}

export interface GenerationSubmitRequest {
  readonly gameId: string
  readonly requestId: string
  readonly input: VideoGenerationInput
  readonly providerId?: string
}

export interface GenerationJobReference {
  readonly gameId: string
  readonly requestId: string
}

/** Durable extension-platform broker contract. */
export interface GenerationBroker {
  submit(request: GenerationSubmitRequest): Promise<GenerationJob>
  get(reference: GenerationJobReference): Promise<GenerationJob | null>
  poll(reference: GenerationJobReference): Promise<GenerationJob>
  recover(gameId: string): Promise<readonly GenerationJob[]>
}

export interface ReadyVideoMediaAsset {
  readonly id: string
  readonly type: "video"
  readonly kind: "video"
  readonly status: "ready"
  readonly url: string
  readonly contentType: string
  readonly sizeBytes?: number
  readonly metadata?: Record<string, unknown>
}

export interface VideoGenerationCapabilityResult {
  readonly asset: ReadyVideoMediaAsset
}

export interface CapabilityInvokeOptions {
  readonly requestId?: string
}

export interface WorkbenchCapabilities {
  invoke(id: string, version: number, input: unknown, options?: CapabilityInvokeOptions): Promise<unknown>
}

export interface WorkbenchCapabilityResolver {
  forGame(gameId: string): WorkbenchCapabilities
}
