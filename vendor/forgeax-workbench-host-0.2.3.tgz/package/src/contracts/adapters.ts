export interface GameVersion {
  tag: string
  commitHash: string
  message: string
  createdAt: string
}

export interface CurrentVersion {
  tag: string
  commitHash: string
  dirty: boolean
}

/**
 * File authority anchored to one game directory for the lifetime of a scoped
 * workspace operation.
 *
 * Implementations must perform each operation without following symlinks out
 * of that directory, including when the user-facing game path is renamed or
 * replaced after the scope is acquired. `write` atomically and durably replaces
 * the target, `delete` is idempotent and durable, and `withLocks` serializes
 * matching keys across all host processes for the anchored directory identity.
 */
export interface GameFileCapability {
  list(relativeDirectory: string): Promise<string[]>
  read(relativePath: string): Promise<Uint8Array | null>
  write(relativePath: string, contents: Uint8Array): Promise<void>
  delete(relativePath: string): Promise<void>
  /**
   * Locks matching keys across every scope, adapter instance, and host process
   * for the same anchored directory identity. Implementations must acquire
   * multiple keys in one canonical order so opposite caller order cannot
   * deadlock; a scope-local mutex is not sufficient.
   */
  withLocks<T>(
    keys: readonly string[],
    operation: () => Promise<T>,
  ): Promise<T>
}

/** Version operations bound to the same directory authority as `files`. */
export interface GameVersionCapability {
  ensureRepository(): Promise<void>
  createVersion(message: string): Promise<GameVersion>
  currentVersion(): Promise<CurrentVersion | null>
  listVersions(): Promise<GameVersion[]>
  readFileAtVersion(
    tag: string,
    relativePath: string,
  ): Promise<Uint8Array | null>
}

export interface ScopedGameRoot {
  /**
   * Descriptive path for diagnostics and trusted extension context only. Host
   * package/version code must perform IO through `files` and `versions`.
   */
  readonly gameRoot: string
  readonly files: GameFileCapability
  readonly versions: GameVersionCapability
}

export interface OpenGameRootOptions {
  /**
   * Only package initialization may request creation. A false value must never
   * create the game directory or any parent.
   */
  readonly create: boolean
  /**
   * Product version adapter to bind to the acquired directory authority.
   * The WorkspaceAdapter, not host services, supplies its anchored root.
   */
  readonly versioning: VersionAdapter
}

export interface WorkspaceAdapter {
  /**
   * Resolves a descriptive path for product diagnostics only. Shared host
   * operations, including component reads, must use withGameRoot instead.
   */
  resolveGameRoot(gameId: string): Promise<string>
  /**
   * Runs one operation under an adapter-owned, no-follow directory authority.
   * Neither the scope nor either of its members may be retained by the caller.
   * Implementations must use a genuine dirfd, native/RPC handle, or equivalent
   * primitive; revalidating a pathname immediately before use is insufficient.
   * After the callback settles, retained capability calls must fail closed
   * rather than act through a closed or subsequently reused native handle.
   */
  withGameRoot<T>(
    gameId: string,
    options: OpenGameRootOptions,
    operation: (scope: ScopedGameRoot) => Promise<T>,
  ): Promise<T>
}

export interface VersionAdapter {
  ensureRepository(gameRoot: string): Promise<void>
  createVersion(gameRoot: string, message: string): Promise<GameVersion>
  currentVersion(gameRoot: string): Promise<CurrentVersion | null>
  listVersions(gameRoot: string): Promise<GameVersion[]>
  readFileAtVersion(
    gameRoot: string,
    tag: string,
    relativePath: string,
  ): Promise<Uint8Array | null>
}

export type MediaType = "audio" | "font" | "image" | "video"

export interface MediaQuery {
  type?: MediaType
  cursor?: string
  limit?: number
}

export interface MediaAsset {
  id: string
  type: MediaType
  url: string
  contentType: string
  sizeBytes?: number
  metadata?: Record<string, unknown>
}

export interface MediaBody {
  contentType: string
  bytes: Uint8Array
}

export interface MediaWriteInput {
  filename: string
  contentType: string
  bytes: Uint8Array
  /**
   * Durable, game-scoped operation identity. Adapters must return the original
   * asset for an exact retry and reject a different payload using the same key.
   */
  idempotencyKey?: string
  metadata?: Record<string, unknown>
}

export interface MediaCapability {
  list(gameId: string, query?: MediaQuery): Promise<MediaAsset[]>
  read(gameId: string, assetId: string): Promise<MediaBody | null>
  put(gameId: string, input: MediaWriteInput): Promise<MediaAsset>
  /** Idempotently reclaims the hosted bytes for an asset. */
  delete(gameId: string, assetId: string): Promise<void>
}

/**
 * A MediaCapability with a durable import primitive. Repeating the same
 * gameId/idempotencyKey must return the original asset without creating a
 * second asset, even after the caller crashes between import and receipt save.
 */
export interface IdempotentMediaCapability extends MediaCapability {
  putIdempotent(
    gameId: string,
    input: MediaWriteInput & { readonly idempotencyKey: string },
  ): Promise<MediaAsset>
}

/** Semantic role of an input supplied to a video generation capability. */
export type VideoGenerationReferenceRole =
  | "reference_image"
  | "first_frame"
  | "last_frame"
  | "style_reference"
  | "character_reference"
  | "scene_reference"
  | "prop_reference"
  | "reference_video"
  | "reference_audio"
  | "voice_sample"
  | (string & {})

export type MediaReferenceKind = "image" | "video" | "audio"

/** A host-owned media reference. assetId is authoritative when both forms exist. */
export interface MediaReference {
  assetId?: string
  url?: string
  role?: VideoGenerationReferenceRole
  mediaKind?: MediaReferenceKind
  metadata?: Record<string, unknown>
}

export interface TextGenerationInput {
  prompt: string
  system?: string
  model?: string
  temperature?: number
  maxTokens?: number
  metadata?: Record<string, unknown>
}

export interface TextGenerationResult {
  text: string
  model?: string
  usage?: {
    inputTokens?: number
    outputTokens?: number
  }
  metadata?: Record<string, unknown>
}

export interface ImageGenerationInput {
  prompt: string
  references?: MediaReference[]
  model?: string
  aspectRatio?: string
  metadata?: Record<string, unknown>
}

export interface ImageGenerationResult {
  assets: MediaAsset[]
  model?: string
  metadata?: Record<string, unknown>
}

export interface VideoGenerationInput {
  prompt: string
  references?: MediaReference[]
  /** Legacy URL-only input retained for callers during migration; Hosts normalize it to references. */
  imageWithRoles?: Array<{ assetId?: string; role?: VideoGenerationReferenceRole; url?: string }>
  model?: string
  durationSeconds?: number
  aspectRatio?: string
  resolution?: string
  generateAudio?: boolean
  idempotencyKey?: string
  seed?: number
  cameraFixed?: boolean
  returnLastFrame?: boolean
  metadata?: Record<string, unknown>
}

export interface VideoGenerationResult {
  assets: MediaAsset[]
  model?: string
  metadata?: Record<string, unknown>
}

/** Game-bound model capability exposed to trusted extension code. */
export interface ModelCapability {
  generateText(input: TextGenerationInput): Promise<TextGenerationResult>
  generateImage(input: ImageGenerationInput): Promise<ImageGenerationResult>
  generateVideo(input: VideoGenerationInput): Promise<VideoGenerationResult>
}

/**
 * Product adapter used by the host. The authoritative game id is supplied by
 * the host for every call and is never selectable by extension input.
 */
export interface ModelGateway {
  generateText(
    gameId: string,
    input: TextGenerationInput,
  ): Promise<TextGenerationResult>
  generateImage(
    gameId: string,
    input: ImageGenerationInput,
  ): Promise<ImageGenerationResult>
  generateVideo(
    gameId: string,
    input: VideoGenerationInput,
  ): Promise<VideoGenerationResult>
}
