import type {
  CurrentVersion,
  GameFileCapability,
  GameVersion,
  GameVersionCapability,
  MediaCapability,
  ModelGateway,
  ScopedGameRoot,
  VersionAdapter,
  WorkspaceAdapter,
} from "../contracts/adapters.js"
import type { WorkbenchCapabilityResolver } from "../contracts/generation.js"
import { WorkbenchError } from "../contracts/error.js"
import {
  createWorkbenchExtensionContext,
  type WorkbenchExtensionModule,
} from "../node/host-context.js"
import {
  gamePackageFromFiles,
  gamePackageFromSeed,
  packageFiles,
  PACKAGE_FILES,
  type GamePackage,
  type GamePackageStatus,
  type PackageFile,
} from "./package-files.js"
import { SingleFlight } from "./single-flight.js"

export {
  PACKAGE_FILES,
  type GamePackage,
  type GamePackageStatus,
} from "./package-files.js"

const PACKAGE_LOCK_KEY = "workbench-package"
const JOURNAL_FILE = ".workbench-package.transaction.json"

export interface PackageFileWriter {
  write(
    files: GameFileCapability,
    relativePath: PackageFile,
    contents: Uint8Array,
  ): Promise<void>
}

export interface GamePackageExtension {
  readonly manifest: { readonly id: string }
  readonly gamePackage: NonNullable<
    WorkbenchExtensionModule["gamePackage"]
  >
}

export interface InitializeGamePackageResult {
  readonly state: "initialized"
  readonly package: GamePackage
  readonly version: GameVersion | CurrentVersion
}

export interface GamePackageServiceOptions {
  readonly workspace: WorkspaceAdapter
  readonly versioning: VersionAdapter
  readonly media?: MediaCapability
  readonly models?: ModelGateway
  readonly capabilities?: WorkbenchCapabilityResolver
  readonly singleFlight?: SingleFlight
  readonly packageFileWriter?: PackageFileWriter
}

interface PackageRead {
  readonly status: GamePackageStatus
  readonly package?: GamePackage
}

type JournalPhase = "prepared" | "replacing" | "version-pending"

interface Journal {
  readonly kind: "workbench-package"
  readonly phase: JournalPhase
  readonly replacement: number
  readonly extensionId: string
  readonly baseline: { tag: string; commitHash: string } | null
  readonly files: readonly PackageFile[]
  readonly previous: Partial<Record<PackageFile, string | null>>
}

function error(code: string, message: string): WorkbenchError {
  return new WorkbenchError({
    code,
    target: "game_package",
    message,
    retryable: false,
  })
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value)
}

function json(value: unknown): Uint8Array {
  const serialized = JSON.stringify(value, null, 2)
  if (serialized === undefined) {
    throw error(
      "package_invalid",
      "Game package must contain JSON values for all owned files",
    )
  }
  return new TextEncoder().encode(`${serialized}\n`)
}

const PACKAGE_FILE_BY_KEY = {
  project: "project.json",
  blueprint: "blueprint.json",
  assetsManifest: "assets/manifest.json",
} as const satisfies Record<string, PackageFile>

function applyPackagePatch(
  current: GamePackage,
  patch: unknown,
): { value: GamePackage; files: PackageFile[] } {
  if (!isRecord(patch)) {
    throw error("package_invalid", "Game package patch must be an object")
  }
  const keys = Object.keys(patch)
  if (
    keys.length === 0 ||
    keys.some((key) => !Object.hasOwn(PACKAGE_FILE_BY_KEY, key))
  ) {
    throw error(
      "package_invalid",
      "Game package patch must contain only project, blueprint, or assetsManifest",
    )
  }
  return {
    value: {
      project: Object.hasOwn(patch, "project")
        ? patch.project
        : current.project,
      blueprint: Object.hasOwn(patch, "blueprint")
        ? patch.blueprint
        : current.blueprint,
      assetsManifest: Object.hasOwn(patch, "assetsManifest")
        ? patch.assetsManifest
        : current.assetsManifest,
    },
    files: keys.map(
      (key) => PACKAGE_FILE_BY_KEY[key as keyof typeof PACKAGE_FILE_BY_KEY],
    ),
  }
}

/** Manages only the portable three-file game package, never extension-specific files. */
export class GamePackageService {
  readonly #options: GamePackageServiceOptions
  readonly #singleFlight: SingleFlight

  constructor(options: GamePackageServiceOptions) {
    this.#options = options
    this.#singleFlight = options.singleFlight ?? new SingleFlight()
  }

  async status(gameId: string): Promise<GamePackageStatus> {
    return this.#withGameRoot(gameId, false, (scope) =>
      this.#locked(scope.files, async () => (await this.#read(scope.files)).status),
    )
  }

  async read(gameId: string): Promise<GamePackage> {
    return this.#withGameRoot(gameId, false, (scope) =>
      this.#locked(scope.files, async () => {
        const found = await this.#read(scope.files)
        if (found.status.state === "inconsistent") {
          throw error(
            "package_inconsistent",
            "Game package is inconsistent and will not be overwritten",
          )
        }
        if (!found.package) {
          throw error(
            "package_uninitialized",
            "Game package has not been initialized",
          )
        }
        return found.package
      }),
    )
  }

  initialize(
    gameId: string,
    extension: GamePackageExtension,
  ): Promise<InitializeGamePackageResult> {
    return this.#singleFlight.run(gameId, () =>
      this.#withGameRoot(gameId, true, (scope) =>
        this.#locked(scope.files, async () => {
          const pending = await this.#journal(scope.files)
          if (pending?.phase === "version-pending") {
            return this.#finishVersion(scope, pending, true)
          }

          const existing = await this.#read(scope.files)
          if (existing.status.state === "inconsistent") {
            throw error(
              "package_inconsistent",
              "Game package is inconsistent and will not be overwritten",
            )
          }
          if (existing.package) {
            const version = await scope.versions.currentVersion()
            if (version === null) {
              throw error(
                "package_version_pending",
                "Game package has no version",
              )
            }
            return {
              state: "initialized",
              package: existing.package,
              version,
            }
          }

          await scope.versions.ensureRepository()
          const baseline = await this.#currentOrNull(scope.versions)
          const seed = await extension.gamePackage.createSeed(
            createWorkbenchExtensionContext({
              gameId,
              gameRoot: scope.gameRoot,
              files: scope.files,
              media: this.#options.media,
              models: this.#options.models,
              capabilities: this.#options.capabilities?.forGame(gameId),
            }),
          )
          await extension.gamePackage.validateSeed(seed)
          const value = gamePackageFromSeed(seed)
          for (const [, item] of packageFiles(value)) {
            json(item)
          }

          const rechecked = await this.#read(scope.files)
          if (rechecked.status.state !== "uninitialized") {
            throw error(
              "package_inconsistent",
              "Game package is inconsistent and will not be overwritten",
            )
          }
          const journal = await this.#replace(
            scope.files,
            value,
            extension.manifest.id,
            baseline,
            true,
          )
          return this.#finishVersion(scope, journal, false)
        }),
      ),
    )
  }

  async update(gameId: string, patch: unknown): Promise<GamePackage> {
    return this.#withGameRoot(gameId, false, (scope) =>
      this.#locked(scope.files, async () => {
        if (await this.#journal(scope.files)) {
          throw error(
            "package_version_pending",
            "Initial version creation is pending",
          )
        }
        const current = await this.#read(scope.files)
        if (current.status.state === "inconsistent") {
          throw error(
            "package_inconsistent",
            "Game package is inconsistent and will not be overwritten",
          )
        }
        if (!current.package) {
          throw error(
            "package_uninitialized",
            "Game package has not been initialized",
          )
        }
        const next = applyPackagePatch(current.package, patch)
        await this.#replace(
          scope.files,
          next.value,
          "",
          null,
          false,
          next.files,
        )
        return next.value
      }),
    )
  }

  async #withGameRoot<T>(
    gameId: string,
    create: boolean,
    operation: (scope: ScopedGameRoot) => Promise<T>,
  ): Promise<T> {
    let entered = false
    try {
      return await this.#options.workspace.withGameRoot(
        gameId,
        { create, versioning: this.#options.versioning },
        async (scope) => {
          entered = true
          if (
            typeof scope.gameRoot !== "string" ||
            scope.gameRoot.length === 0 ||
            typeof scope.files !== "object" ||
            scope.files === null
          ) {
            throw error(
              "package_path_invalid",
              "Workspace returned an invalid scoped game root",
            )
          }
          return operation(scope)
        },
      )
    } catch (cause) {
      if (entered || cause instanceof WorkbenchError) {
        throw cause
      }
      throw new WorkbenchError({
        code: "workspace_not_found",
        target: "workspace",
        message: "Game workspace was not found",
        retryable: false,
      })
    }
  }

  async #readFile(
    files: GameFileCapability,
    relativePath: PackageFile,
  ): Promise<{
    exists: boolean
    valid: boolean
    value?: unknown
    bytes?: Uint8Array
  }> {
    const bytes = await files.read(relativePath)
    if (bytes === null) {
      return { exists: false, valid: false }
    }
    try {
      return {
        exists: true,
        valid: true,
        value: JSON.parse(new TextDecoder().decode(bytes)) as unknown,
        bytes,
      }
    } catch {
      return { exists: true, valid: false, bytes }
    }
  }

  async #read(files: GameFileCapability): Promise<PackageRead> {
    const entries = await Promise.all(
      PACKAGE_FILES.map(async (relativePath) => [
        relativePath,
        await this.#readFile(files, relativePath),
      ] as const),
    )
    const present = entries.filter(([, value]) => value.exists)
    if (present.length === 0) {
      return { status: { state: "uninitialized" } }
    }
    if (
      present.length !== PACKAGE_FILES.length ||
      entries.some(([, value]) => !value.valid)
    ) {
      return { status: { state: "inconsistent" } }
    }
    return {
      status: { state: "initialized" },
      package: gamePackageFromFiles(
        new Map(
          entries.map(([relativePath, value]) => [
            relativePath,
            value.value,
          ] as const),
        ),
      ),
    }
  }

  async #journal(files: GameFileCapability): Promise<Journal | null> {
    const bytes = await files.read(JOURNAL_FILE)
    if (bytes === null) {
      return null
    }
    let raw: Partial<Journal>
    try {
      raw = JSON.parse(new TextDecoder().decode(bytes)) as Partial<Journal>
    } catch {
      throw error(
        "package_recovery_invalid",
        "Game package recovery journal is invalid",
      )
    }
    const candidateFiles: unknown = raw.files ?? [...PACKAGE_FILES]
    if (
      !Array.isArray(candidateFiles) ||
      candidateFiles.some(
        (file) =>
          typeof file !== "string" ||
          !PACKAGE_FILES.includes(file as PackageFile),
      )
    ) {
      throw error(
        "package_recovery_invalid",
        "Game package recovery journal is invalid",
      )
    }
    const journalFiles = candidateFiles as PackageFile[]
    if (
      raw.kind !== "workbench-package" ||
      !["prepared", "replacing", "version-pending"].includes(raw.phase ?? "") ||
      typeof raw.replacement !== "number" ||
      typeof raw.extensionId !== "string" ||
      !isRecord(raw.previous) ||
      journalFiles.length === 0 ||
      new Set(journalFiles).size !== journalFiles.length ||
      journalFiles.some(
        (file) =>
          typeof raw.previous![file] !== "string" &&
          raw.previous![file] !== null,
      )
    ) {
      throw error(
        "package_recovery_invalid",
        "Game package recovery journal is invalid",
      )
    }
    return { ...(raw as Journal), files: journalFiles }
  }

  async #writeJournal(
    files: GameFileCapability,
    journal: Journal,
  ): Promise<void> {
    await files.write(JOURNAL_FILE, json(journal))
  }

  async #clearJournal(files: GameFileCapability): Promise<void> {
    await files.delete(JOURNAL_FILE)
  }

  async #replace(
    filesCapability: GameFileCapability,
    value: GamePackage,
    extensionId: string,
    baseline: { tag: string; commitHash: string } | null,
    pendingVersion: boolean,
    files: readonly PackageFile[] = PACKAGE_FILES,
  ): Promise<Journal> {
    if (pendingVersion && files.length !== PACKAGE_FILES.length) {
      throw error(
        "package_invalid",
        "Initial package replacement must contain every owned file",
      )
    }
    const encoded = new Map<PackageFile, Uint8Array>()
    for (const [relativePath, item] of packageFiles(value)) {
      if (files.includes(relativePath)) {
        encoded.set(relativePath, json(item))
      }
    }

    const previous: Partial<Record<PackageFile, string | null>> = {}
    for (const relativePath of files) {
      const old = await this.#readFile(filesCapability, relativePath)
      previous[relativePath] = old.exists
        ? Buffer.from(old.bytes!).toString("base64")
        : null
    }
    let journal: Journal = {
      kind: "workbench-package",
      phase: "prepared",
      replacement: 0,
      extensionId,
      baseline,
      files: [...files],
      previous,
    }
    await this.#writeJournal(filesCapability, journal)

    try {
      for (const [index, relativePath] of files.entries()) {
        journal = {
          ...journal,
          phase: "replacing",
          replacement: index,
        }
        await this.#writeJournal(filesCapability, journal)
        const contents = encoded.get(relativePath)!
        if (this.#options.packageFileWriter) {
          await this.#options.packageFileWriter.write(
            filesCapability,
            relativePath,
            contents,
          )
        } else {
          await filesCapability.write(relativePath, contents)
        }
      }
      if (pendingVersion) {
        journal = {
          ...journal,
          phase: "version-pending",
          replacement: files.length,
        }
        await this.#writeJournal(filesCapability, journal)
      } else {
        await this.#clearJournal(filesCapability)
      }
      return journal
    } catch (cause) {
      await this.#rollback(filesCapability, journal)
      throw cause
    }
  }

  async #rollback(
    files: GameFileCapability,
    journal: Journal,
  ): Promise<void> {
    for (const relativePath of journal.files) {
      const old = journal.previous[relativePath]!
      if (old === null) {
        await files.delete(relativePath)
      } else {
        await files.write(
          relativePath,
          new Uint8Array(Buffer.from(old, "base64")),
        )
      }
    }
    await this.#clearJournal(files)
  }

  async #finishVersion(
    scope: ScopedGameRoot,
    journal: Journal,
    inspectCurrent: boolean,
  ): Promise<InitializeGamePackageResult> {
    let version: GameVersion | CurrentVersion
    if (inspectCurrent) {
      await scope.versions.ensureRepository()
      const current = await scope.versions.currentVersion()
      if (
        current !== null &&
        (
          !journal.baseline ||
          current.tag !== journal.baseline.tag ||
          current.commitHash !== journal.baseline.commitHash
        )
      ) {
        await this.#clearJournal(scope.files)
        return {
          state: "initialized",
          package: (await this.#read(scope.files)).package!,
          version: current,
        }
      }
    }
    version = await scope.versions.createVersion(
      `[workbench] initialize ${journal.extensionId}`,
    )
    await this.#clearJournal(scope.files)
    return {
      state: "initialized",
      package: (await this.#read(scope.files)).package!,
      version,
    }
  }

  async #currentOrNull(
    versions: GameVersionCapability,
  ): Promise<{ tag: string; commitHash: string } | null> {
    const current = await versions.currentVersion()
    return current === null
      ? null
      : { tag: current.tag, commitHash: current.commitHash }
  }

  async #locked<T>(
    files: GameFileCapability,
    work: () => Promise<T>,
  ): Promise<T> {
    return files.withLocks([PACKAGE_LOCK_KEY], async () => {
      const journal = await this.#journal(files)
      if (journal && journal.phase !== "version-pending") {
        await this.#rollback(files, journal)
      }
      return work()
    })
  }
}
