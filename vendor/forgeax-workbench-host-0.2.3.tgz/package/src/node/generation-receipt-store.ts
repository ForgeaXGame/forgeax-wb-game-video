import { createHash, randomUUID } from "node:crypto"

import type {
  GenerationJob,
  VideoGenerationInput,
  VersionAdapter,
  WorkspaceAdapter,
} from "../contracts/index.js"
import { WorkbenchError } from "../contracts/index.js"

const encoder = new TextEncoder()
const decoder = new TextDecoder()
const RECEIPT_DIRECTORY = ".workbench/generation-jobs/video"
const sensitiveJobKeys = new Set([
  "token",
  "cookie",
  "authorization",
  "signedurl",
  "providertaskid",
])
const sensitiveMetadataKeys = new Set([
  ...sensitiveJobKeys,
  "locator",
  "outputlocator",
  "outputurl",
  "url",
])
const sensitiveSignedQueryKeys = new Set([
  "signature",
  "sig",
  "token",
  "authorization",
  "x-amz-signature",
  "x-amz-credential",
  "q-signature",
  "q-ak",
  "q-sign-time",
  "q-key-time",
  "q-sign-algorithm",
  "q-url-param-list",
  "q-header-list",
])

export interface GenerationReceiptV1 {
  readonly version: 1
  readonly job: GenerationJob
  readonly gameScopeHash: string
  readonly providerId: string
  readonly providerTaskId?: string
  readonly request: VideoGenerationInput
  readonly requestFingerprint: string
  readonly idempotencyKey: string
  readonly submitAttempts: number
  readonly queryAttempts: number
}

export interface GenerationReceiptStoreOptions {
  readonly workspace: WorkspaceAdapter
  readonly versioning: VersionAdapter
  readonly now?: () => Date
  readonly createJobId?: () => string
}

export interface StartGenerationReceiptInput {
  readonly providerId: string
  readonly input: VideoGenerationInput
}

export interface ConditionalGenerationReceiptUpdate {
  readonly receipt: GenerationReceiptV1
  readonly updated: boolean
}

function receiptError(code: string, message: string): WorkbenchError {
  return new WorkbenchError({ code, target: "host", message, retryable: false })
}

function hash(value: string): string {
  return createHash("sha256").update(value).digest("hex")
}

function normalizeJson(value: unknown): unknown {
  if (value === null || typeof value === "string" || typeof value === "boolean") return value
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new TypeError("Generation requests must contain finite numbers")
    return value
  }
  if (Array.isArray(value)) return value.map((entry) => normalizeJson(entry === undefined ? null : entry))
  if (typeof value === "object") {
    const prototype = Object.getPrototypeOf(value)
    if (prototype !== Object.prototype && prototype !== null) {
      throw new TypeError("Generation requests must contain JSON-compatible objects")
    }
    const normalized: Record<string, unknown> = {}
    for (const key of Object.keys(value).sort()) {
      const entry = (value as Record<string, unknown>)[key]
      if (entry !== undefined) normalized[key] = normalizeJson(entry)
    }
    return normalized
  }
  throw new TypeError("Generation requests must contain JSON-compatible values")
}

function normalizedInput(input: VideoGenerationInput): VideoGenerationInput {
  assertSafeMetadata(input.metadata)
  return normalizeJson(input) as VideoGenerationInput
}

function assertSafeMetadata(value: unknown): void {
  if (value === undefined || value === null) return
  if (Array.isArray(value)) {
    for (const entry of value) assertSafeMetadata(entry)
    return
  }
  if (typeof value === "string") {
    if (hasSensitiveUrlQuery(value)) {
      throw receiptError(
        "generation_request_sensitive_metadata",
        "Generation request metadata contains a sensitive value",
      )
    }
    return
  }
  if (typeof value !== "object") return
  for (const [key, entry] of Object.entries(value)) {
    if (sensitiveMetadataKeys.has(key.toLowerCase())) {
      throw receiptError(
        "generation_request_sensitive_metadata",
        "Generation request metadata contains a sensitive field",
      )
    }
    assertSafeMetadata(entry)
  }
}

function hasSensitiveUrlQuery(value: string): boolean {
  try {
    const url = new URL(value)
    for (const key of url.searchParams.keys()) {
      if (sensitiveSignedQueryKeys.has(key.toLowerCase())) return true
    }
    return false
  } catch {
    return /(?:[?&](?:signature|sig|token|authorization|x-amz-signature|x-amz-credential|q-signature|q-ak|q-sign-time|q-key-time)=)/iu.test(value)
  }
}

function receiptPath(jobId: string): string {
  if (!/^gen_[a-z0-9-]+$/u.test(jobId)) {
    throw receiptError("generation_receipt_invalid", "Generation job id is invalid")
  }
  return `${RECEIPT_DIRECTORY}/${jobId}.json`
}

function assertNoSensitiveJobFields(value: unknown): void {
  if (Array.isArray(value)) {
    for (const item of value) assertNoSensitiveJobFields(item)
    return
  }
  if (value === null || typeof value !== "object") return
  for (const [key, item] of Object.entries(value)) {
    if (sensitiveJobKeys.has(key.toLowerCase())) {
      throw receiptError("generation_receipt_invalid", "Generation job contains a sensitive field")
    }
    assertNoSensitiveJobFields(item)
  }
}

function publicJob(job: GenerationJob): GenerationJob {
  assertNoSensitiveJobFields(job)
  return structuredClone(job)
}

function parseReceipt(value: unknown, gameId: string): GenerationReceiptV1 {
  if (value === null || typeof value !== "object") {
    throw receiptError("generation_receipt_invalid", "Generation receipt must be an object")
  }
  const receipt = value as Partial<GenerationReceiptV1>
  if (
    receipt.version !== 1 ||
    typeof receipt.gameScopeHash !== "string" ||
    receipt.gameScopeHash !== hash(gameId) ||
    typeof receipt.providerId !== "string" ||
    typeof receipt.providerTaskId !== "undefined" && typeof receipt.providerTaskId !== "string" ||
    typeof receipt.requestFingerprint !== "string" ||
    typeof receipt.idempotencyKey !== "string" ||
    typeof receipt.submitAttempts !== "number" ||
    typeof receipt.queryAttempts !== "number" ||
    receipt.job === undefined ||
    receipt.request === undefined
  ) {
    throw receiptError("generation_receipt_invalid", "Generation receipt has an invalid shape")
  }
  const request = normalizedInput(receipt.request)
  if (hash(JSON.stringify(request)) !== receipt.requestFingerprint) {
    throw receiptError("generation_receipt_invalid", "Generation receipt request fingerprint is invalid")
  }
  return {
    version: 1,
    job: publicJob({
      ...receipt.job,
      gameId,
      requestId: receipt.job.requestId ?? receipt.idempotencyKey,
      assets: receipt.job.assets ?? [],
    }),
    gameScopeHash: receipt.gameScopeHash,
    providerId: receipt.providerId,
    ...(receipt.providerTaskId === undefined ? {} : { providerTaskId: receipt.providerTaskId }),
    request,
    requestFingerprint: receipt.requestFingerprint,
    idempotencyKey: receipt.idempotencyKey,
    submitAttempts: receipt.submitAttempts,
    queryAttempts: receipt.queryAttempts,
  }
}

/**
 * Game-scoped durable storage for the internal state of an asynchronous video
 * generation. It only exposes a sanitized GenerationJob to browser callers.
 */
export class GenerationReceiptStore {
  readonly #workspace: WorkspaceAdapter
  readonly #versioning: VersionAdapter
  readonly #now: () => Date
  readonly #createJobId: () => string

  constructor(options: GenerationReceiptStoreOptions) {
    this.#workspace = options.workspace
    this.#versioning = options.versioning
    this.#now = options.now ?? (() => new Date())
    this.#createJobId = options.createJobId ?? (() => `gen_${randomUUID()}`)
  }

  async start(gameId: string, input: StartGenerationReceiptInput): Promise<GenerationJob> {
    const request = normalizedInput(input.input)
    const idempotencyKey = request.idempotencyKey ?? `generated:${randomUUID()}`
    const requestFingerprint = hash(JSON.stringify(request))
    const jobId = request.idempotencyKey
      ? `gen_${hash(request.idempotencyKey)}`
      : this.#createJobId()
    const path = receiptPath(jobId)

    return this.#workspace.withGameRoot(gameId, {
      create: false,
      versioning: this.#versioning,
    }, async (scope) => scope.files.withLocks([`generation-job:${jobId}`], async () => {
      const existing = await this.#read(scope.files.read(path), gameId)
      if (existing !== null) {
        if (existing.idempotencyKey !== idempotencyKey || existing.requestFingerprint !== requestFingerprint) {
          throw receiptError(
            "generation_idempotency_conflict",
            "Generation idempotency key was reused with a different request",
          )
        }
        return publicJob(existing.job)
      }
      const timestamp = this.#now().toISOString()
      const receipt: GenerationReceiptV1 = {
        version: 1,
        job: {
          jobId,
          gameId,
          requestId: idempotencyKey,
          status: "created",
          assets: [],
          createdAt: timestamp,
          updatedAt: timestamp,
        },
        gameScopeHash: hash(gameId),
        providerId: input.providerId,
        request,
        requestFingerprint,
        idempotencyKey,
        submitAttempts: 0,
        queryAttempts: 0,
      }
      await scope.files.write(path, encoder.encode(JSON.stringify(receipt)))
      return publicJob(receipt.job)
    }))
  }

  async get(gameId: string, jobId: string): Promise<GenerationJob> {
    return publicJob((await this.read(gameId, jobId)).job)
  }

  async read(gameId: string, jobId: string): Promise<GenerationReceiptV1> {
    const path = receiptPath(jobId)
    return this.#workspace.withGameRoot(gameId, {
      create: false,
      versioning: this.#versioning,
    }, async (scope) => scope.files.withLocks([`generation-job:${jobId}`], async () => {
      const receipt = await this.#read(scope.files.read(path), gameId)
      if (receipt === null) throw receiptError("generation_job_not_found", "Generation job was not found")
      return receipt
    }))
  }

  async update(
    gameId: string,
    jobId: string,
    operation: (receipt: GenerationReceiptV1) => GenerationReceiptV1,
  ): Promise<GenerationReceiptV1> {
    return (await this.updateIf(gameId, jobId, () => true, operation)).receipt
  }

  async updateIf(
    gameId: string,
    jobId: string,
    predicate: (receipt: GenerationReceiptV1) => boolean,
    operation: (receipt: GenerationReceiptV1) => GenerationReceiptV1,
  ): Promise<ConditionalGenerationReceiptUpdate> {
    const path = receiptPath(jobId)
    return this.#workspace.withGameRoot(gameId, {
      create: false,
      versioning: this.#versioning,
    }, async (scope) => scope.files.withLocks([`generation-job:${jobId}`], async () => {
      const current = await this.#read(scope.files.read(path), gameId)
      if (current === null) throw receiptError("generation_job_not_found", "Generation job was not found")
      if (!predicate(current)) return { receipt: current, updated: false }
      const next = operation(current)
      const checked = parseReceipt(next, gameId)
      await scope.files.write(path, encoder.encode(JSON.stringify(checked)))
      return { receipt: checked, updated: true }
    }))
  }

  async list(gameId: string): Promise<readonly GenerationReceiptV1[]> {
    return this.#workspace.withGameRoot(gameId, {
      create: false,
      versioning: this.#versioning,
    }, async (scope) => {
      const names = await scope.files.list(RECEIPT_DIRECTORY)
      return Promise.all(names
        .filter((name) => /^gen_[a-z0-9-]+\.json$/u.test(name))
        .sort()
        .map(async (name) => {
          const jobId = name.slice(0, -".json".length)
          return scope.files.withLocks([`generation-job:${jobId}`], async () => {
            const receipt = await this.#read(scope.files.read(`${RECEIPT_DIRECTORY}/${name}`), gameId)
            if (receipt === null) throw receiptError("generation_job_not_found", "Generation job was not found")
            return receipt
          })
        }))
    })
  }

  async #read(read: Promise<Uint8Array | null>, gameId: string): Promise<GenerationReceiptV1 | null> {
    const bytes = await read
    if (bytes === null) return null
    try {
      return parseReceipt(JSON.parse(decoder.decode(bytes)), gameId)
    } catch (error) {
      if (error instanceof WorkbenchError) throw error
      throw receiptError("generation_receipt_invalid", "Generation receipt contains invalid JSON")
    }
  }
}
