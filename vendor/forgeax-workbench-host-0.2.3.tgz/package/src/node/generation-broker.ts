import type {
  IdempotentMediaCapability,
  GenerationJob,
  MediaAsset,
  MediaCapability,
  ProviderExecutionContext,
  ProviderMediaOutput,
  ProviderTaskStatus,
  VideoGenerationInput,
  VideoGenerationProviderV1,
  VideoGenerationResult,
  WorkbenchGenerationBroker,
} from "../contracts/index.js"
import { ServiceRequestError, WorkbenchError } from "../contracts/index.js"
import { CapabilityRegistry } from "./capability-registry.js"
import {
  GenerationReceiptStore,
  type GenerationReceiptV1,
} from "./generation-receipt-store.js"
import { ServiceBindingRegistry } from "./service-binding-registry.js"

const videoCapability = { id: "media.video.generate", version: 1 } as const
const terminalStatuses = new Set(["succeeded", "failed", "cancelled"])
const allowedVideoContentTypes = [
  "video/mp4",
] as const

function requiredJobId(job: GenerationJob): string {
  if (typeof job.jobId !== "string" || job.jobId.length === 0) {
    throw new WorkbenchError({ code: "generation_job_invalid", target: "host", message: "Generation job has no job id", retryable: false })
  }
  return job.jobId
}

class ProviderOutputValidationError extends Error {
  constructor() {
    super("Provider output content type is not allowed")
    this.name = "ProviderOutputValidationError"
  }
}

export interface GenerationBrokerOptions {
  readonly receipts: GenerationReceiptStore
  readonly capabilities: CapabilityRegistry<VideoGenerationProviderV1>
  readonly services: ServiceBindingRegistry
  readonly media: MediaCapability
  /** Provider identity selected by product configuration for the video capability. */
  readonly providerId: string
  readonly pollIntervalMs?: number
  readonly synchronousTimeoutMs?: number
  readonly now?: () => Date
  readonly sleep?: (milliseconds: number) => Promise<void>
}

function isTerminal(status: GenerationJob["status"]): boolean {
  return terminalStatuses.has(status)
}

function errorDetails(code: string, message: string, retryable: boolean): GenerationJob["error"] {
  return { code, message, retryable }
}

function isKnownNotReachedUpstream(error: unknown): boolean {
  if (error instanceof ServiceRequestError) return error.requestReachedUpstream === false
  return typeof error === "object" && error !== null &&
    (error as { requestReachedUpstream?: unknown }).requestReachedUpstream === false
}

/**
 * Drives the selected asynchronous video provider while keeping upstream task
 * ids and output locators inside a game-scoped receipt. Browser callers only
 * ever receive host-owned GenerationJob and MediaAsset values.
 */
export class GenerationBroker implements WorkbenchGenerationBroker {
  readonly #receipts: GenerationReceiptStore
  readonly #capabilities: CapabilityRegistry<VideoGenerationProviderV1>
  readonly #services: ServiceBindingRegistry
  readonly #media: MediaCapability
  readonly #providerId: string
  readonly #pollIntervalMs: number
  readonly #synchronousTimeoutMs: number
  readonly #now: () => Date
  readonly #sleep: (milliseconds: number) => Promise<void>
  readonly #ticks = new Map<string, Promise<GenerationJob>>()
  readonly #background = new Map<string, Promise<void>>()

  constructor(options: GenerationBrokerOptions) {
    this.#receipts = options.receipts
    this.#capabilities = options.capabilities
    this.#services = options.services
    this.#media = options.media
    this.#providerId = options.providerId
    this.#pollIntervalMs = options.pollIntervalMs ?? 1_000
    this.#synchronousTimeoutMs = options.synchronousTimeoutMs ?? 5_000
    this.#now = options.now ?? (() => new Date())
    this.#sleep = options.sleep ?? ((milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)))
  }

  async start(gameId: string, input: VideoGenerationInput): Promise<GenerationJob> {
    this.#configuredProvider()
    const job = await this.#receipts.start(gameId, { providerId: this.#providerId, input })
    if (!isTerminal(job.status)) this.#runInBackground(gameId, requiredJobId(job))
    return job
  }

  async get(gameId: string, jobId: string): Promise<GenerationJob> {
    const job = await this.#receipts.get(gameId, jobId)
    if (!isTerminal(job.status)) this.#runInBackground(gameId, jobId)
    return job
  }

  async cancel(gameId: string, jobId: string): Promise<void> {
    const transition = await this.#receipts.updateIf(gameId, jobId, (receipt) => (
      !isTerminal(receipt.job.status)
    ), (receipt) => ({
      ...receipt,
      job: {
        ...receipt.job,
        status: "cancelled",
        updatedAt: this.#now().toISOString(),
        error: undefined,
      },
    }))
    if (transition.updated && transition.receipt.providerTaskId !== undefined) {
      try {
        await this.#provider(transition.receipt).cancel?.(
          this.#context(gameId, requiredJobId(transition.receipt.job)),
          transition.receipt.providerTaskId,
        )
      } catch {
        // Provider cancellation is best effort; the durable terminal state wins.
      }
    }
  }

  async tick(gameId: string, jobId: string): Promise<GenerationJob> {
    const key = `${gameId}\u0000${jobId}`
    const existing = this.#ticks.get(key)
    if (existing !== undefined) return existing
    const work = this.#tick(gameId, jobId).finally(() => this.#ticks.delete(key))
    this.#ticks.set(key, work)
    return work
  }

  async recover(gameId: string): Promise<readonly GenerationJob[]> {
    const receipts = await this.#receipts.list(gameId)
    return Promise.all(receipts
      .filter((receipt) => (
        receipt.job.status === "created" ||
        receipt.job.status === "submitting" ||
        receipt.job.status === "polling" ||
        receipt.job.status === "output_pending_import"
      ))
      .map(async (receipt) => {
        if (receipt.job.status === "submitting") {
          return this.tick(gameId, requiredJobId(receipt.job))
        }
        const job = await this.tick(gameId, requiredJobId(receipt.job))
        if (!isTerminal(job.status)) this.#runInBackground(gameId, requiredJobId(receipt.job))
        return job
      }))
  }

  async generateVideo(gameId: string, input: VideoGenerationInput): Promise<VideoGenerationResult> {
    const job = await this.start(gameId, input)
    const jobId = requiredJobId(job)
    const background = this.#runInBackground(gameId, jobId)
    const completed = await Promise.race([
      background.then(async () => this.get(gameId, jobId)),
      this.#sleep(this.#synchronousTimeoutMs).then(() => null),
    ])
    if (completed !== null && completed.status === "succeeded") {
      return { assets: [...(completed.assets ?? [])], metadata: { jobId } }
    }
    return { assets: [], metadata: { jobId } }
  }

  async #tick(gameId: string, jobId: string): Promise<GenerationJob> {
    const receipt = await this.#receipts.read(gameId, jobId)
    if (isTerminal(receipt.job.status)) return receipt.job
    if (receipt.job.status === "submitting") {
      return this.#failUnknownSubmission(gameId, jobId)
    }
    if (receipt.job.status === "created") {
      return this.#submit(gameId, receipt)
    }
    return this.#query(gameId, receipt)
  }

  async #submit(gameId: string, receipt: GenerationReceiptV1): Promise<GenerationJob> {
    const transition = await this.#receipts.updateIf(gameId, requiredJobId(receipt.job), (current) => (
      current.job.status === "created"
    ), (current) => ({
      ...current,
      submitAttempts: current.submitAttempts + 1,
      job: {
        ...current.job,
        status: "submitting",
        updatedAt: this.#now().toISOString(),
        error: undefined,
      },
    }))
    const submitting = transition.receipt
    if (!transition.updated) return submitting.job
    try {
      const submitted = await this.#provider(submitting).submit(
        this.#context(gameId, requiredJobId(submitting.job)),
        submitting.request,
      )
      if (submitted.providerTaskId.length === 0) {
        return this.#failUnknownSubmission(gameId, requiredJobId(submitting.job))
      }
      const persisted = await this.#receipts.updateIf(gameId, requiredJobId(submitting.job), (current) => (
        current.job.status === "submitting"
      ), (current) => ({
        ...current,
        providerTaskId: submitted.providerTaskId,
        job: {
          ...current.job,
          status: "polling",
          updatedAt: this.#now().toISOString(),
          error: undefined,
        },
      }))
      if (!persisted.updated) return persisted.receipt.job
      return this.#query(gameId, persisted.receipt)
    } catch (error) {
      if (isKnownNotReachedUpstream(error)) {
        return this.#setJob(gameId, submitting.job.jobId, ["submitting"], (job) => ({
          ...job,
          status: "created",
          updatedAt: this.#now().toISOString(),
          error: errorDetails("provider_submission_retryable", "Provider submission can be retried", true),
        }))
      }
      return this.#failUnknownSubmission(gameId, submitting.job.jobId, ["submitting"])
    }
  }

  async #query(gameId: string, receipt: GenerationReceiptV1): Promise<GenerationJob> {
    if (receipt.providerTaskId === undefined) {
      return this.#failUnknownSubmission(gameId, requiredJobId(receipt.job), ["polling", "output_pending_import"])
    }
    const queryTransition = await this.#receipts.updateIf(gameId, requiredJobId(receipt.job), (current) => (
      current.job.status === receipt.job.status
    ), (current) => ({
      ...current,
      queryAttempts: current.queryAttempts + 1,
    }))
    const queried = queryTransition.receipt
    if (!queryTransition.updated) return queried.job
    let result: ProviderTaskStatus
    try {
      result = await this.#provider(queried).query(
        this.#context(gameId, requiredJobId(queried.job)),
        queried.providerTaskId!,
      )
    } catch (error) {
      return this.#setJob(gameId, requiredJobId(queried.job), [queried.job.status], (job) => ({
        ...job,
        updatedAt: this.#now().toISOString(),
        error: errorDetails("provider_query_retryable", "Provider status cannot be read yet", true),
      }))
    }
    if (result.status === "polling") {
      return this.#setJob(gameId, requiredJobId(queried.job), [queried.job.status], (job) => ({
        ...job,
        status: "polling",
        ...(result.progress === undefined ? {} : { progress: result.progress }),
        updatedAt: this.#now().toISOString(),
        error: undefined,
      }))
    }
    if (result.status === "failed") {
      return this.#setJob(gameId, requiredJobId(queried.job), [queried.job.status], (job) => ({
        ...job,
        status: "failed",
        updatedAt: this.#now().toISOString(),
        error: errorDetails(
          "provider_generation_failed",
          "Provider reported that video generation failed",
          result.retryable,
        ),
      }))
    }
    if (result.status === "cancelled") {
      return this.#setJob(gameId, requiredJobId(queried.job), [queried.job.status], (job) => ({
        ...job,
        status: "cancelled",
        updatedAt: this.#now().toISOString(),
        error: undefined,
      }))
    }
    const pending = await this.#setJob(gameId, requiredJobId(queried.job), [queried.job.status], (job) => ({
      ...job,
      status: "output_pending_import",
      updatedAt: this.#now().toISOString(),
      error: undefined,
    }))
    if (pending.status !== "output_pending_import") return pending
    return this.#importOutputs(gameId, queried, result.outputs)
  }

  async #importOutputs(
    gameId: string,
    receipt: GenerationReceiptV1,
    outputs: readonly ProviderMediaOutput[],
  ): Promise<GenerationJob> {
    try {
      const assets: MediaAsset[] = []
      for (const [index, output] of outputs.entries()) {
        if (!allowedVideoContentTypes.includes(output.contentType as typeof allowedVideoContentTypes[number])) {
          throw new ProviderOutputValidationError()
        }
        const body = await this.#services.download(output.serviceId, gameId, {
          locator: output.locator,
          maxBytes: 512 * 1024 * 1024,
          allowedContentTypes: allowedVideoContentTypes,
        })
        if (!allowedVideoContentTypes.includes(body.contentType as typeof allowedVideoContentTypes[number])) {
          throw new ProviderOutputValidationError()
        }
        assets.push(await this.#media.put(gameId, {
          filename: output.filename,
          contentType: body.contentType,
          bytes: body.bytes,
          idempotencyKey: `generation:${requiredJobId(receipt.job)}:${String(index)}`,
          metadata: {
            capabilityId: videoCapability.id,
            providerId: receipt.providerId,
            jobId: requiredJobId(receipt.job),
          },
        }))
      }
      return this.#setJob(gameId, requiredJobId(receipt.job), ["output_pending_import"], (job) => ({
        ...job,
        status: "succeeded",
        assets,
        updatedAt: this.#now().toISOString(),
        error: undefined,
      }))
    } catch (error) {
      if (error instanceof ProviderOutputValidationError) {
        return this.#setJob(gameId, requiredJobId(receipt.job), ["output_pending_import"], (job) => ({
          ...job,
          status: "failed",
          updatedAt: this.#now().toISOString(),
          error: errorDetails(
            "provider_output_content_type_invalid",
            "Provider output content type is not allowed",
            false,
          ),
        }))
      }
        return this.#setJob(gameId, requiredJobId(receipt.job), ["output_pending_import"], (job) => ({
        ...job,
        status: "output_pending_import",
        updatedAt: this.#now().toISOString(),
        error: errorDetails("generation_import_retryable", "Video output import can be retried", true),
      }))
    }
  }

  #configuredProvider(): VideoGenerationProviderV1 {
    const configured = this.#capabilities.requireProvider(videoCapability, this.#providerId)
    if (this.#capabilities.require(videoCapability) !== configured) {
      throw new WorkbenchError({
        code: "generation_provider_selection_mismatch",
        target: "host",
        message: "Configured video generation provider is not selected",
        retryable: false,
      })
    }
    return configured
  }

  #provider(receipt: GenerationReceiptV1): VideoGenerationProviderV1 {
    return this.#capabilities.requireProvider(videoCapability, receipt.providerId)
  }

  #context(gameId: string, jobId: string): ProviderExecutionContext {
    return {
      gameId,
      traceId: `generation:${jobId}`,
      media: this.#media,
      services: this.#services.forGame(gameId),
    }
  }

  async #failUnknownSubmission(
    gameId: string,
    jobId: string,
    expectedStatuses: readonly GenerationJob["status"][] = ["submitting"],
  ): Promise<GenerationJob> {
    return this.#setJob(gameId, jobId, expectedStatuses, (job) => ({
      ...job,
      status: "failed",
      updatedAt: this.#now().toISOString(),
      error: errorDetails(
        "provider_submission_unknown",
        "Provider submission outcome is unknown and will not be retried",
        false,
      ),
    }))
  }

  async #setJob(
    gameId: string,
    jobId: string,
    expectedStatuses: readonly GenerationJob["status"][],
    operation: (job: GenerationJob) => GenerationJob,
  ): Promise<GenerationJob> {
    const transition = await this.#receipts.updateIf(gameId, jobId, (current) => (
      expectedStatuses.includes(current.job.status)
    ), (current) => ({
      ...current,
      job: operation(current.job),
    }))
    return transition.receipt.job
  }

  #runInBackground(gameId: string, jobId: string): Promise<void> {
    const key = `${gameId}\u0000${jobId}`
    const existing = this.#background.get(key)
    if (existing !== undefined) return existing
    const work = (async () => {
      for (;;) {
        const job = await this.tick(gameId, jobId)
        if (isTerminal(job.status)) return
        await this.#sleep(this.#pollIntervalMs)
      }
    })().catch(() => undefined).finally(() => this.#background.delete(key))
    this.#background.set(key, work)
    return work
  }
}
import {
  VIDEO_GENERATION_CAPABILITY,
  type CapabilityProviderRegistryLike,
  type GeneratedMedia,
  type GenerationCapabilityInvocation,
  type GenerationBroker as DurableGenerationBrokerContract,
  type GenerationJobReference,
  type GenerationProviderContext,
  type GenerationProviderResult,
  type GenerationReceiptStore as DurableReceiptStore,
  type GenerationStatus,
  type GenerationSubmitRequest,
  type GenerationServiceBinding,
  type ServiceBindingResolver,
} from "../contracts/generation.js"

const ACTIVE_STATUSES = new Set<GenerationStatus>(["queued", "running", "importing"])

function clone<T>(value: T): T { return structuredClone(value) }
function assertNonEmpty(value: string, name: string): void {
  if (typeof value !== "string" || value.trim().length === 0) throw new TypeError(`${name} must be a non-empty string`)
}
function assertGameReference(reference: GenerationJobReference): void {
  assertNonEmpty(reference.gameId, "gameId")
  assertNonEmpty(reference.requestId, "requestId")
}
function assertGeneratedMedia(output: GeneratedMedia): void {
  assertNonEmpty(output.filename, "generated media filename")
  assertNonEmpty(output.contentType, "generated media contentType")
  if (!(output.bytes instanceof Uint8Array)) throw new TypeError("generated media bytes must be a Uint8Array")
}
function validateProviderResult(value: unknown): GenerationProviderResult {
  if (typeof value !== "object" || value === null) throw new TypeError("generation provider returned an invalid result")
  const result = value as Partial<GenerationProviderResult>
  if (typeof result.externalId !== "string" || result.externalId.length === 0) throw new TypeError("generation provider returned an invalid externalId")
  if (typeof result.status !== "string" || !["queued", "running", "succeeded", "failed", "cancelled"].includes(result.status)) throw new TypeError("generation provider returned an invalid status")
  if (result.outputs !== undefined) {
    if (!Array.isArray(result.outputs)) throw new TypeError("generation provider returned invalid outputs")
    result.outputs.forEach(assertGeneratedMedia)
  }
  if (result.status === "succeeded" && (!Array.isArray(result.outputs) || result.outputs.length === 0)) {
    throw new TypeError("generation provider returned succeeded without media outputs")
  }
  return result as GenerationProviderResult
}
function recoverableSucceededResult(value: unknown): { externalId: string; receipt: unknown } | null {
  if (typeof value !== "object" || value === null) return null
  const result = value as { externalId?: unknown; status?: unknown; receipt?: unknown }
  if (result.status !== "succeeded" || typeof result.externalId !== "string" || result.externalId.length === 0) return null
  return { externalId: result.externalId, receipt: clone(result.receipt ?? null) }
}
function selectedProviderId(value: unknown): string {
  if (typeof value !== "object" || value === null || typeof (value as { providerId?: unknown }).providerId !== "string" || (value as { providerId: string }).providerId.length === 0) {
    throw new TypeError("capability registry returned an invalid provider")
  }
  return (value as { providerId: string }).providerId
}
function publicJob(job: GenerationJob): GenerationJob { return clone(job) }
function recordKey(reference: GenerationJobReference): string { return JSON.stringify([reference.gameId, reference.requestId]) }
function providerIdempotencyKey(reference: GenerationJobReference): string {
  return `workbench-generation:v1:${recordKey(reference)}`
}

/** Stable, credential-free service bindings available to a capability provider. */
export class DurableServiceBindingRegistry implements ServiceBindingResolver {
  readonly #bindings = new Map<string, GenerationServiceBinding>()

  constructor(bindings: readonly GenerationServiceBinding[] = []) {
    for (const binding of bindings) {
      assertNonEmpty(binding.id, "service binding id")
      if (typeof binding.invoke !== "function") throw new TypeError("service binding invoke must be a function")
      if (this.#bindings.has(binding.id)) throw new TypeError(`duplicate service binding: ${binding.id}`)
      this.#bindings.set(binding.id, binding)
    }
  }

  get(id: string): GenerationServiceBinding | undefined { return this.#bindings.get(id) }
  require(id: string): GenerationServiceBinding {
    const binding = this.get(id)
    if (!binding) throw new Error(`service binding is not configured: ${id}`)
    return binding
  }
  list(): readonly string[] { return [...this.#bindings.keys()].sort() }
}

export function createServiceBindingRegistry(bindings: readonly GenerationServiceBinding[] = []): DurableServiceBindingRegistry {
  return new DurableServiceBindingRegistry(bindings)
}

export interface DurableGenerationBrokerOptions {
  readonly capabilities: CapabilityProviderRegistryLike<GenerationProviderContext>
  readonly receipts: DurableReceiptStore
  readonly media: IdempotentMediaCapability
  readonly serviceBindings?: ServiceBindingResolver
  readonly now?: () => Date
}

/**
 * Durable asynchronous execution for media.video.generate@1.
 *
 * It never calls a product API: the selected extension-platform provider owns
 * submission and polling, while the host owns durable receipts and MediaAsset
 * imports. Existing receipts are always polled or returned; they are never
 * submitted again automatically.
 */
export class DurableGenerationBroker implements DurableGenerationBrokerContract {
  readonly #inFlight = new Map<string, Promise<GenerationJob>>()
  readonly #serviceBindings: ServiceBindingResolver
  readonly #now: () => Date

  constructor(readonly options: DurableGenerationBrokerOptions) {
    if (!options.capabilities || typeof options.capabilities.resolve !== "function" || typeof options.capabilities.invoke !== "function") throw new TypeError("capabilities must provide resolve and invoke")
    if (!options.receipts || typeof options.receipts.get !== "function" || typeof options.receipts.createIfAbsent !== "function" || typeof options.receipts.put !== "function" || typeof options.receipts.list !== "function") throw new TypeError("receipts must provide get, createIfAbsent, put, and list")
    if (!options.media || typeof options.media.putIdempotent !== "function") throw new TypeError("media must provide putIdempotent")
    this.#serviceBindings = options.serviceBindings ?? createServiceBindingRegistry()
    this.#now = options.now ?? (() => new Date())
  }

  async submit(request: GenerationSubmitRequest): Promise<GenerationJob> {
    assertGameReference(request)
    if (!request.input || typeof request.input.prompt !== "string" || request.input.prompt.length === 0) throw new TypeError("video generation prompt must be a non-empty string")
    const key = recordKey(request)
    const existing = this.#inFlight.get(key)
    if (existing) return publicJob(await existing)
    const pending = this.#submitOnce(request)
    this.#inFlight.set(key, pending)
    try { return publicJob(await pending) } finally { this.#inFlight.delete(key) }
  }

  async get(reference: GenerationJobReference): Promise<GenerationJob | null> {
    assertGameReference(reference)
    const job = await this.options.receipts.get(reference.gameId, reference.requestId)
    return job ? publicJob(job) : null
  }

  async poll(reference: GenerationJobReference): Promise<GenerationJob> {
    assertGameReference(reference)
    const job = await this.options.receipts.get(reference.gameId, reference.requestId)
    if (!job) throw new Error("generation receipt was not found")
    if (!ACTIVE_STATUSES.has(job.status as GenerationStatus)) return publicJob(job)
    if (!job.externalId) return publicJob(await this.#markUnknown(job))
    return publicJob(await this.#pollExisting(job))
  }

  async recover(gameId: string): Promise<readonly GenerationJob[]> {
    assertNonEmpty(gameId, "gameId")
    const jobs = await this.options.receipts.list(gameId)
    const recovered: GenerationJob[] = []
    for (const job of jobs) {
      if (job.gameId !== gameId) throw new TypeError("receipt store returned a job outside the requested game")
      if (ACTIVE_STATUSES.has(job.status as GenerationStatus)) recovered.push(await this.poll({ gameId, requestId: job.requestId }))
      else recovered.push(publicJob(job))
    }
    return recovered
  }

  async #submitOnce(request: GenerationSubmitRequest): Promise<GenerationJob> {
    const existing = await this.options.receipts.get(request.gameId, request.requestId)
    if (existing) return existing
    const providerId = selectedProviderId(this.options.capabilities.resolve(VIDEO_GENERATION_CAPABILITY, request.providerId))
    const now = this.#now().toISOString()
    // Persist before the provider call. A timeout after the remote side accepts
    // the request is ambiguous, so a later host process must not submit again.
    const provisional: GenerationJob = {
      jobId: request.requestId,
      gameId: request.gameId,
      requestId: request.requestId,
      providerId,
      externalId: null,
      providerReceipt: null,
      status: "submission_unknown",
      assets: [],
      createdAt: now,
      updatedAt: now,
    }
    const reservation = await this.options.receipts.createIfAbsent(provisional)
    if (!reservation.created) return reservation.job
    const context = this.#context(request.gameId, request.requestId)
    const rawResult = await this.options.capabilities.invoke<unknown>(
      VIDEO_GENERATION_CAPABILITY,
      { kind: "submit", input: clone(request.input), idempotencyKey: providerIdempotencyKey(request) } satisfies GenerationCapabilityInvocation,
      context,
      providerId,
    )
    let result: GenerationProviderResult
    try { result = validateProviderResult(rawResult) } catch (error) {
      const recoverable = recoverableSucceededResult(rawResult)
      if (recoverable) {
        await this.options.receipts.put({
          ...provisional,
          externalId: recoverable.externalId,
          providerReceipt: recoverable.receipt,
          status: "running",
          updatedAt: this.#now().toISOString(),
        })
      }
      throw error
    }
    const job: GenerationJob = {
      jobId: request.requestId,
      gameId: request.gameId,
      requestId: request.requestId,
      providerId,
      externalId: result.externalId,
      providerReceipt: clone(result.receipt ?? null),
      status: result.status,
      assets: [],
      ...(result.error === undefined ? {} : { error: clone(result.error) }),
      createdAt: provisional.createdAt,
      updatedAt: this.#now().toISOString(),
    }
    if (result.status !== "succeeded") {
      await this.options.receipts.put(job)
      return job
    }
    return this.#importSuccessfulResult(job, result.outputs ?? [])
  }

  async #pollExisting(job: GenerationJob): Promise<GenerationJob> {
    const context = this.#context(job.gameId, job.requestId)
    const rawResult = await this.options.capabilities.invoke<unknown>(
      VIDEO_GENERATION_CAPABILITY,
      { kind: "poll", externalId: job.externalId!, receipt: clone(job.providerReceipt) } satisfies GenerationCapabilityInvocation,
      context,
      job.providerId,
    )
    let result: GenerationProviderResult
    try { result = validateProviderResult(rawResult) } catch (error) {
      // Keep the existing active receipt so recovery can poll it later. An
      // invalid "succeeded" response must never become a terminal empty job.
      throw error
    }
    if (result.externalId !== job.externalId) throw new TypeError("generation provider changed the externalId")
    const next: GenerationJob = {
      ...job,
      providerReceipt: clone(result.receipt ?? job.providerReceipt),
      status: result.status,
      ...(result.error === undefined ? {} : { error: clone(result.error) }),
      updatedAt: this.#now().toISOString(),
    }
    if (result.status !== "succeeded") {
      await this.options.receipts.put(next)
      return next
    }
    return this.#importSuccessfulResult(next, result.outputs ?? [])
  }

  async #markUnknown(job: GenerationJob): Promise<GenerationJob> {
    const next: GenerationJob = {
      ...job,
      status: "submission_unknown",
      updatedAt: this.#now().toISOString(),
    }
    await this.options.receipts.put(next)
    return next
  }

  async #importSuccessfulResult(job: GenerationJob, outputs: readonly GeneratedMedia[]): Promise<GenerationJob> {
    let current: GenerationJob = {
      ...job,
      status: "importing",
      updatedAt: this.#now().toISOString(),
    }
    // Store this transition before the first media write. Recovery polls the
    // durable provider receipt again and resumes only missing output indexes.
    await this.options.receipts.put(current)
    for (const [index, output] of outputs.entries()) {
      assertGeneratedMedia(output)
      if (current.assets[index] !== undefined) continue
      const asset = await this.options.media.putIdempotent(job.gameId, {
        filename: output.filename,
        contentType: output.contentType,
        bytes: new Uint8Array(output.bytes),
        idempotencyKey: `generation:${job.requestId}:${index}`,
        metadata: {
          ...(output.metadata ? clone(output.metadata) : {}),
          generationRequestId: job.requestId,
          generationProviderId: job.providerId ?? null,
        },
      })
      current = {
        ...current,
        assets: [...current.assets, asset],
        updatedAt: this.#now().toISOString(),
      }
      await this.options.receipts.put(current)
    }
    const finalized: GenerationJob = {
      ...current,
      status: "succeeded",
      updatedAt: this.#now().toISOString(),
    }
    await this.options.receipts.put(finalized)
    return finalized
  }

  #context(gameId: string, requestId: string): GenerationProviderContext {
    return Object.freeze({ gameId, requestId, serviceBindings: this.#serviceBindings })
  }
}

export function createGenerationBroker(options: DurableGenerationBrokerOptions): DurableGenerationBrokerContract {
  return new DurableGenerationBroker(options)
}
