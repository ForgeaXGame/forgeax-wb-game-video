import type {
  MediaBody,
} from "../contracts/adapters.js"
import { WorkbenchError } from "../contracts/error.js"
import type {
  ServiceBinding,
  ServiceCapability,
  ServiceDownloadInput,
} from "../contracts/service-binding.js"

function serviceError(code: string, message: string): WorkbenchError {
  return new WorkbenchError({ code, target: "host", message, retryable: false })
}

/**
 * Stores host-owned service bindings and exposes only game-scoped operations
 * to extension providers. Credentials and direct media downloads stay private.
 */
export class ServiceBindingRegistry {
  readonly #bindings = new Map<string, ServiceBinding>()

  constructor(bindings: readonly ServiceBinding[] = []) {
    for (const binding of bindings) this.register(binding)
  }

  register(binding: ServiceBinding): void {
    const existing = this.#bindings.get(binding.id)
    if (existing === binding) return
    if (existing !== undefined) {
      throw serviceError(
        "service_binding_conflict",
        "A service binding is already registered for this id",
      )
    }
    this.#bindings.set(binding.id, binding)
  }

  require(serviceId: string): ServiceBinding {
    const binding = this.#bindings.get(serviceId)
    if (binding === undefined) {
      throw serviceError("service_binding_not_found", "Service binding was not found")
    }
    return binding
  }

  forGame(gameId: string): ServiceCapability {
    const scoped: ServiceCapability = {
      scope: (serviceId) => this.require(serviceId).scope(gameId),
      request: (serviceId, input) =>
        this.require(serviceId).request({ ...input, gameId }),
      stageMedia: (serviceId, input) =>
        this.require(serviceId).stageMedia({ ...input, gameId }),
    }
    return Object.freeze(scoped)
  }

  download(
    serviceId: string,
    gameId: string,
    input: ServiceDownloadInput,
  ): Promise<MediaBody> {
    return this.require(serviceId).download({ ...input, gameId })
  }
}
