import type { VideoGenerationProviderV1 } from "../contracts/generation.js"
import type { CapabilityProviderDescriptor } from "../contracts/capability.js"
import { WorkbenchError } from "../contracts/error.js"
import {
  importTrustedPackageModule,
  type ExtensionTrustPolicy,
} from "./backend-loader.js"
import type { ScannedExtension } from "./scan-package.js"

export interface WorkbenchProviderModule {
  readonly capabilities: Readonly<Record<string, VideoGenerationProviderV1>>
}

/**
 * A headless provider extension supplied by the product composition root.
 *
 * Unlike a Workbench runtime, a headless extension has no frontend/backend
 * entrypoint to scan. The product owns the package trust decision and hands
 * this already-imported, manifest-matched module to the Host.
 */
export interface WorkbenchProviderExtension {
  readonly extensionId: string
  readonly capabilities: readonly CapabilityProviderDescriptor[]
  readonly module: WorkbenchProviderModule
}

function providerKey(value: { readonly id: string; readonly version: number; readonly providerId: string }): string {
  return `${value.id}@${String(value.version)}#${value.providerId}`
}

function providerError(message: string): TypeError {
  return new TypeError(`Workbench provider module ${message}`)
}

function isProvider(value: unknown): value is VideoGenerationProviderV1 {
  return typeof value === "object" && value !== null &&
    "submit" in value && typeof value.submit === "function" &&
    "query" in value && typeof value.query === "function" &&
    (!("cancel" in value) || value.cancel === undefined || typeof value.cancel === "function")
}

/** Validates the narrow provider surface loaded from a trusted extension package. */
export function defineWorkbenchProviderModule(value: unknown): WorkbenchProviderModule {
  if (typeof value !== "object" || value === null || !("capabilities" in value)) {
    throw providerError("must export a capabilities object")
  }
  const capabilities = (value as { capabilities: unknown }).capabilities
  if (typeof capabilities !== "object" || capabilities === null || Array.isArray(capabilities)) {
    throw providerError("capabilities must be an object")
  }
  for (const [key, provider] of Object.entries(capabilities)) {
    if (key.length === 0 || !isProvider(provider)) {
      throw providerError("capabilities must map keys to submit/query providers")
    }
  }
  return Object.freeze({ capabilities: Object.freeze({ ...capabilities }) })
}

/** Validates a product-supplied headless provider before registration. */
export function defineWorkbenchProviderExtension(value: unknown): WorkbenchProviderExtension {
  if (typeof value !== "object" || value === null) {
    throw providerError("extension must be an object")
  }
  const candidate = value as {
    extensionId?: unknown
    capabilities?: unknown
    module?: unknown
  }
  if (typeof candidate.extensionId !== "string" || candidate.extensionId.length === 0) {
    throw providerError("extensionId must be a non-empty string")
  }
  if (!Array.isArray(candidate.capabilities) || candidate.capabilities.length === 0) {
    throw providerError("extension capabilities must be a non-empty array")
  }
  const capabilities: CapabilityProviderDescriptor[] = candidate.capabilities.map((descriptor): CapabilityProviderDescriptor => {
    if (typeof descriptor !== "object" || descriptor === null) {
      throw providerError("extension capabilities must contain descriptors")
    }
    const value = descriptor as Partial<CapabilityProviderDescriptor>
    const id = value.id
    const version = value.version
    const providerId = value.providerId
    if (
      typeof id !== "string" || id.length === 0 ||
      typeof version !== "number" || !Number.isSafeInteger(version) || version <= 0 ||
      typeof providerId !== "string" || providerId.length === 0
    ) {
      throw providerError("extension capabilities contain an invalid descriptor")
    }
    return Object.freeze({ id, version, providerId })
  })
  const module = defineWorkbenchProviderModule(candidate.module)
  const declaredKeys = new Set(capabilities.map(providerKey))
  const actualKeys = Object.keys(module.capabilities)
  if (
    actualKeys.length !== declaredKeys.size ||
    actualKeys.some((key) => !declaredKeys.has(key)) ||
    [...declaredKeys].some((key) => !Object.hasOwn(module.capabilities, key))
  ) {
    throw providerError("extension capabilities must exactly match its module")
  }
  return Object.freeze({
    extensionId: candidate.extensionId,
    capabilities: Object.freeze(capabilities),
    module,
  })
}

/**
 * Loads a provider module through the same trust/path boundary as a backend.
 * The module must implement exactly the capability/provider tuples declared in
 * its manifest; this prevents a provider from silently claiming another key.
 */
export async function loadTrustedProviderModule(
  extension: ScannedExtension,
  isTrusted: ExtensionTrustPolicy,
): Promise<WorkbenchProviderModule> {
  if (!(await isTrusted(extension))) {
    throw new WorkbenchError({
      code: "extension_untrusted",
      target: "extension",
      message: "Extension provider is not trusted",
      retryable: false,
    })
  }
  const declared = extension.manifest.provides.capabilities ?? []
  if (declared.length === 0) {
    if (extension.manifest.entry.providers !== undefined) {
      const module = defineWorkbenchProviderModule(await importTrustedPackageModule(
        extension.packageRoot,
        extension.manifest.entry.providers,
      ))
      if (Object.keys(module.capabilities).length !== 0) {
        throw providerError("contains a capability that is not declared by its manifest")
      }
    }
    return Object.freeze({ capabilities: Object.freeze({}) })
  }
  const entry = extension.manifest.entry.providers
  if (entry === undefined) {
    throw providerError("entry is required for declared capabilities")
  }
  const module = defineWorkbenchProviderModule(await importTrustedPackageModule(
    extension.packageRoot,
    entry,
  ))
  const declaredKeys = new Set(declared.map(providerKey))
  const actualKeys = Object.keys(module.capabilities)
  if (
    actualKeys.length !== declaredKeys.size ||
    actualKeys.some((key) => !declaredKeys.has(key)) ||
    [...declaredKeys].some((key) => !Object.hasOwn(module.capabilities, key))
  ) {
    throw providerError("capabilities must exactly match those declared by its manifest")
  }
  return module
}
