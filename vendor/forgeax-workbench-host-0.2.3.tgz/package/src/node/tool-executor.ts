import Ajv, { type AnySchemaObject, type ValidateFunction } from "ajv"
import Ajv2020 from "ajv/dist/2020.js"
import { isAbsolute, relative, sep } from "node:path"
import { fileURLToPath, pathToFileURL } from "node:url"

import type {
  MediaCapability,
  ModelGateway,
  VersionAdapter,
  WorkspaceAdapter,
} from "../contracts/adapters.js"
import type {
  VideoGenerationGateway,
  VideoGenerationProviderV1,
  WorkbenchCapabilityResolver,
} from "../contracts/generation.js"
import {
  toErrorEnvelope,
  WorkbenchError,
  type WorkbenchErrorEnvelope,
} from "../contracts/error.js"
import { ToolCallInputSchema, type ToolCallResult } from "../contracts/tool.js"
import {
  loadTrustedBackend,
  readTrustedPackageJson,
  resolveTrustedPackageFile,
  resolveTrustedPackageRoot,
} from "./backend-loader.js"
import { createWorkbenchExtensionContext } from "./host-context.js"
import type { RuntimeDescriptor, RuntimeRegistry } from "./runtime-registry.js"
import { CapabilityRegistry } from "./capability-registry.js"
import { ServiceBindingRegistry } from "./service-binding-registry.js"

export interface ToolExecutorOptions {
  readonly registry: RuntimeRegistry
  readonly workspace: WorkspaceAdapter
  readonly versioning: VersionAdapter
  readonly isExtensionTrusted: (
    extension: RuntimeDescriptor,
  ) => boolean | Promise<boolean>
  readonly media?: MediaCapability
  readonly models?: ModelGateway
  readonly capabilities?: CapabilityRegistry<VideoGenerationProviderV1> | WorkbenchCapabilityResolver
  /** Extension-facing capability resolver (kept separate from provider registry). */
  readonly capabilityResolver?: WorkbenchCapabilityResolver
  readonly services?: ServiceBindingRegistry
  /** Loads trusted providers before a required capability is evaluated. */
  readonly prepareCapabilities?: () => Promise<void>
  /** Returns a game-scoped broker facade after recovering active generation receipts. */
  readonly videoGeneration?: (gameId: string) => Promise<VideoGenerationGateway>
}

interface ToolLocation {
  readonly extension: RuntimeDescriptor
  readonly descriptor: RuntimeDescriptor["manifest"]["tools"][number]
}

function errorResult(
  code: string,
  target: string,
  message: string,
  details?: unknown,
): WorkbenchErrorEnvelope {
  return toErrorEnvelope(
    new WorkbenchError({
      code,
      target,
      message,
      retryable: false,
      ...(details === undefined ? {} : { details }),
    }),
  )
}

function isJsonObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value)
}

function isDraft2020Schema(schema: Record<string, unknown>): boolean {
  return (
    typeof schema.$schema === "string" &&
    schema.$schema.replace(/#$/, "") ===
      "https://json-schema.org/draft/2020-12/schema"
  )
}

class AsyncToolSchemaError extends Error {
  constructor() {
    super("Async JSON Schemas are not supported for workbench tools")
  }
}

function hasThen(value: unknown): value is Promise<unknown> {
  return (
    typeof value === "object" &&
    value !== null &&
    "then" in value &&
    typeof value.then === "function"
  )
}

function lazyVideoGenerationGateway(
  resolveGateway: (gameId: string) => Promise<VideoGenerationGateway>,
  gameId: string,
): VideoGenerationGateway {
  return Object.freeze({
    start: async (input: Parameters<VideoGenerationGateway["start"]>[0]) => (
      await resolveGateway(gameId)
    ).start(input),
    get: async (jobId: string) => (await resolveGateway(gameId)).get(jobId),
    cancel: async (jobId: string) => (await resolveGateway(gameId)).cancel(jobId),
    generateVideo: async (input: Parameters<VideoGenerationGateway["generateVideo"]>[0]) => (
      await resolveGateway(gameId)
    ).generateVideo(input),
  })
}

function unavailableVideoGenerationGateway(): VideoGenerationGateway {
  const unavailable = async (): Promise<never> => {
    throw new WorkbenchError({
      code: "capability_unavailable",
      target: "media.video.generate@1",
      message: "A required workbench capability is unavailable",
      retryable: false,
    })
  }
  return { start: unavailable, get: unavailable, cancel: unavailable, generateVideo: unavailable }
}

function lifecycleVideoGenerationGateway(
  resolveGateway: (gameId: string) => Promise<VideoGenerationGateway>,
  gameId: string,
): VideoGenerationGateway {
  const unavailable = unavailableVideoGenerationGateway()
  const lazy = lazyVideoGenerationGateway(resolveGateway, gameId)
  return Object.freeze({
    start: unavailable.start,
    get: lazy.get,
    cancel: lazy.cancel,
    generateVideo: unavailable.generateVideo,
  })
}

/** The sole trusted route from UI or AI tool calls to extension handlers. */
export class ToolExecutor {
  readonly #tools = new Map<string, ToolLocation>()
  readonly #modules = new Map<string, ReturnType<typeof loadTrustedBackend>>()
  readonly #validators = new Map<string, Promise<ValidateFunction>>()
  readonly #options: ToolExecutorOptions

  constructor(options: ToolExecutorOptions) {
    this.#options = options
    for (const extension of options.registry.entries()) {
      for (const descriptor of extension.manifest.tools) {
        if (this.#tools.has(descriptor.id)) {
          throw new TypeError(`Duplicate workbench tool id: ${descriptor.id}`)
        }
        this.#tools.set(descriptor.id, { extension, descriptor })
      }
    }
  }

  async call(input: unknown): Promise<ToolCallResult> {
    const parsed = ToolCallInputSchema.safeParse(input)
    if (!parsed.success) {
      return errorResult(
        "tool_call_invalid",
        "tool_call",
        "Invalid workbench tool call",
        parsed.error.flatten(),
      )
    }

    const location = this.#tools.get(parsed.data.toolId)
    if (!location) {
      return errorResult("tool_not_found", "tool", "Workbench tool was not found")
    }

    try {
      if (!(await this.#options.isExtensionTrusted(location.extension))) {
        return errorResult(
          "extension_untrusted",
          "extension",
          "Extension backend is not trusted",
        )
      }
      if (parsed.data.caller === "ai" && !location.descriptor.exposedToAI) {
        return errorResult(
          "tool_not_allowed",
          "tool",
          "Workbench tool is not exposed to AI callers",
        )
      }
      const requirements = location.descriptor.requiresCapabilities ?? []
      if (requirements.length > 0) {
        await this.#options.prepareCapabilities?.()
        for (const requirement of requirements) {
          try {
            const registry = this.#options.capabilities
            if (!registry || typeof (registry as CapabilityRegistry<VideoGenerationProviderV1>).requireSelected !== "function") {
              throw new Error("missing registry")
            }
            ;(registry as CapabilityRegistry<VideoGenerationProviderV1>).requireSelected(requirement)
          } catch {
            return errorResult(
              "capability_unavailable",
              `${requirement.id}@${String(requirement.version)}`,
              "A required workbench capability is unavailable",
            )
          }
        }
      }

      const inputValidation = await this.#validate(
        location.extension,
        location.descriptor.inputSchema,
        parsed.data.args,
      )
      if (!inputValidation.valid) {
        return errorResult(
          "tool_args_invalid",
          "tool_args",
          "Workbench tool arguments do not match its schema",
          inputValidation.errors,
        )
      }

      const module = await this.#moduleFor(location.extension)
      const tools = module.tools
      const handler =
        tools && Object.hasOwn(tools, location.descriptor.id)
          ? tools[location.descriptor.id]
          : undefined
      if (typeof handler !== "function") {
        return errorResult("tool_not_found", "tool", "Workbench tool was not found")
      }
      let scopeEntered = false
      try {
        return await this.#options.workspace.withGameRoot(
          parsed.data.gameId,
          { create: false, versioning: this.#options.versioning },
          async (scope) => {
            scopeEntered = true
            const videoGeneration = requirements.some((requirement) => (
              requirement.id === "media.video.generate" && requirement.version === 1
            ))
              ? await this.#options.videoGeneration?.(parsed.data.gameId)
              : this.#options.videoGeneration === undefined
                ? undefined
                : lifecycleVideoGenerationGateway(this.#options.videoGeneration, parsed.data.gameId)
            const context = createWorkbenchExtensionContext({
              gameId: parsed.data.gameId,
              gameRoot: scope.gameRoot,
              files: scope.files,
              media: this.#options.media,
              models: this.#options.models,
              videoGeneration,
              services: this.#options.services?.forGame(parsed.data.gameId),
              capabilities: this.#options.capabilityResolver?.forGame(parsed.data.gameId),
            })
            const result = await handler(context, parsed.data.args)

            if (location.descriptor.outputSchema) {
              const outputValidation = await this.#validate(
                location.extension,
                location.descriptor.outputSchema,
                result,
              )
              if (!outputValidation.valid) {
                return errorResult(
                  "tool_result_invalid",
                  "tool_result",
                  "Workbench tool result does not match its schema",
                  outputValidation.errors,
                )
              }
            }
            return { ok: true, result }
          },
        )
      } catch (error) {
        if (!scopeEntered) {
          return errorResult(
            "workspace_not_found",
            "workspace",
            "Game workspace was not found",
          )
        }
        throw error
      }
    } catch (error) {
      return toErrorEnvelope(error)
    }
  }

  async #moduleFor(extension: RuntimeDescriptor) {
    let module = this.#modules.get(extension.runtimeId)
    if (!module) {
      module = loadTrustedBackend(extension.source, () =>
        this.#options.isExtensionTrusted(extension),
      )
      this.#modules.set(extension.runtimeId, module)
    }
    return module
  }

  #validatorFor(
    extension: RuntimeDescriptor,
    schemaReference: string,
  ): Promise<ValidateFunction> {
    const cacheKey = `${extension.runtimeId}\u0000${schemaReference}`
    let validator = this.#validators.get(cacheKey)
    if (!validator) {
      validator = this.#createValidator(extension, schemaReference)
      this.#validators.set(cacheKey, validator)
    }
    return validator
  }

  async #validate(
    extension: RuntimeDescriptor,
    schemaReference: string,
    value: unknown,
  ): Promise<{ readonly valid: boolean; readonly errors?: unknown }> {
    try {
      const validator = await this.#validatorFor(extension, schemaReference)
      const validation = validator(value) as unknown
      if (hasThen(validation)) {
        void validation.catch(() => undefined)
        return { valid: false }
      }
      return validation
        ? { valid: true }
        : { valid: false, errors: validator.errors }
    } catch (error) {
      if (error instanceof AsyncToolSchemaError) {
        return { valid: false, errors: { reason: "async_schema_unsupported" } }
      }
      throw error
    }
  }

  async #createValidator(
    extension: RuntimeDescriptor,
    schemaReference: string,
  ): Promise<ValidateFunction> {
    const root = extension.source.packageRoot
    const document = await readTrustedPackageJson(root, schemaReference)
    if (!isJsonObject(document.value)) {
      throw new TypeError("Tool schema must be a JSON object")
    }
    const loadSchema = async (uri: string) => this.#loadSchema(root, uri)
    const ajv = isDraft2020Schema(document.value)
      ? new Ajv2020({ allErrors: true, loadSchema, strict: true })
      : new Ajv({ allErrors: true, loadSchema, strict: false })
    const schema: AnySchemaObject = {
      ...document.value,
      $id: pathToFileURL(document.path).href,
    }
    const validator = await ajv.compileAsync(schema)
    if ((validator as ValidateFunction & { $async?: boolean }).$async) {
      throw new AsyncToolSchemaError()
    }
    return validator
  }

  async #loadSchema(packageRoot: string, uri: string): Promise<AnySchemaObject> {
    let path: string
    try {
      const url = new URL(uri)
      if (url.protocol !== "file:") {
        throw new TypeError("Only package-local JSON Schema references are allowed")
      }
      path = fileURLToPath(url)
    } catch (error) {
      if (error instanceof TypeError) {
        throw error
      }
      throw new TypeError("Invalid JSON Schema reference")
    }
    const root = await resolveTrustedPackageRoot(packageRoot)
    const relativeSchema = relative(root, path)
    if (
      relativeSchema.length === 0 ||
      isAbsolute(relativeSchema) ||
      relativeSchema === ".." ||
      relativeSchema.startsWith(`..${sep}`)
    ) {
      throw new TypeError("JSON Schema reference is outside the extension root")
    }
    const document = await readTrustedPackageJson(packageRoot, relativeSchema)
    if (!isJsonObject(document.value)) {
      throw new TypeError("Referenced tool schema must be a JSON object")
    }
    return { ...document.value, $id: pathToFileURL(document.path).href }
  }
}
