import {
  VIDEO_GENERATION_CAPABILITY,
  type CapabilityInvokeOptions,
  type GenerationBroker,
  type GenerationJob,
  type ReadyVideoMediaAsset,
  type VideoGenerationCapabilityResult,
  type WorkbenchCapabilityResolver,
  type WorkbenchCapabilities,
} from "../contracts/generation.js"
import type { MediaReference, VideoGenerationInput } from "../contracts/adapters.js"

export interface GenerationCapabilityBridgeOptions {
  readonly broker: GenerationBroker
  /** Product-selected provider; trusted extensions cannot override it. */
  readonly providerId?: string
  /** Delay between durable receipt polls. Defaults to one second. */
  readonly pollIntervalMs?: number
  /** Injectable for deterministic tests and product-specific scheduling. */
  readonly sleep?: (milliseconds: number) => Promise<void>
}

function assertNonEmpty(value: unknown, name: string): asserts value is string {
  if (typeof value !== "string" || value.trim().length === 0) throw new TypeError(`${name} must be a non-empty string`)
}

function record(value: unknown): Record<string, unknown> | null {
  return typeof value === "object" && value !== null && !Array.isArray(value) ? value as Record<string, unknown> : null
}

function optionalString(value: unknown): string | undefined {
  return typeof value === "string" && value.trim().length > 0 ? value : undefined
}

function optionalMetadata(value: unknown): Record<string, unknown> | undefined {
  const result = record(value)
  return result ? { ...result } : undefined
}

function normalizeReference(value: unknown): MediaReference | null {
  const raw = record(value)
  if (!raw) return null
  const assetId = optionalString(raw.assetId)
  const url = optionalString(raw.url)
  if (!assetId && !url) return null
  const role = optionalString(raw.role)
  const mediaKind = raw.mediaKind === "image" || raw.mediaKind === "video" || raw.mediaKind === "audio" ? raw.mediaKind : undefined
  const metadata = optionalMetadata(raw.metadata)
  return {
    ...(assetId === undefined ? {} : { assetId }),
    ...(url === undefined ? {} : { url }),
    ...(role === undefined ? {} : { role }),
    ...(mediaKind === undefined ? {} : { mediaKind }),
    ...(metadata === undefined ? {} : { metadata }),
  }
}

/**
 * Makes the common contract unambiguous before it reaches the durable broker:
 * canonical references and legacy imageWithRoles are accepted, but the broker
 * only receives canonical role-tagged references. assetId references win over
 * URL-only duplicates so a provider can resolve host-owned media first.
 */
export function normalizeVideoGenerationInput(value: unknown): VideoGenerationInput {
  const raw = record(value)
  if (!raw || typeof raw.prompt !== "string") throw new TypeError("video generation input must include a prompt")
  const references: MediaReference[] = []
  const byAssetId = new Set<string>()
  const byUrl = new Map<string, number>()
  const addReference = (candidate: unknown): void => {
    const reference = normalizeReference(candidate)
    if (!reference) return
    if (reference.assetId) {
      if (byAssetId.has(reference.assetId)) return
      const urlIndex = reference.url === undefined ? undefined : byUrl.get(reference.url)
      if (urlIndex !== undefined && references[urlIndex]?.assetId !== undefined) return
      byAssetId.add(reference.assetId)
      if (urlIndex !== undefined) references[urlIndex] = reference
      else references.push(reference)
      if (reference.url !== undefined) byUrl.set(reference.url, urlIndex ?? references.length - 1)
      return
    }
    if (reference.url === undefined || byUrl.has(reference.url)) return
    byUrl.set(reference.url, references.length)
    references.push(reference)
  }
  for (const reference of Array.isArray(raw.references) ? raw.references : []) addReference(reference)
  for (const reference of Array.isArray(raw.imageWithRoles) ? raw.imageWithRoles : []) addReference(reference)

  const model = optionalString(raw.model)
  const aspectRatio = optionalString(raw.aspectRatio)
  const resolution = optionalString(raw.resolution)
  const metadata = optionalMetadata(raw.metadata)
  return {
    prompt: raw.prompt,
    ...(references.length === 0 ? {} : { references }),
    ...(model === undefined ? {} : { model }),
    ...(typeof raw.durationSeconds !== "number" ? {} : { durationSeconds: raw.durationSeconds }),
    ...(aspectRatio === undefined ? {} : { aspectRatio }),
    ...(resolution === undefined ? {} : { resolution }),
    ...(typeof raw.generateAudio !== "boolean" ? {} : { generateAudio: raw.generateAudio }),
    ...(typeof raw.seed !== "number" ? {} : { seed: raw.seed }),
    ...(typeof raw.cameraFixed !== "boolean" ? {} : { cameraFixed: raw.cameraFixed }),
    ...(typeof raw.returnLastFrame !== "boolean" ? {} : { returnLastFrame: raw.returnLastFrame }),
    ...(metadata === undefined ? {} : { metadata }),
  }
}

function defaultSleep(milliseconds: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, milliseconds))
}

function readyAsset(job: GenerationJob): VideoGenerationCapabilityResult {
  const asset = job.assets.find((candidate) => candidate.type === "video")
  if (!asset || asset.id.trim().length === 0 || asset.url.trim().length === 0 || asset.contentType.trim().length === 0) {
    throw new Error("video generation succeeded without a ready video MediaAsset")
  }
  const result: ReadyVideoMediaAsset = {
    id: asset.id,
    type: "video",
    kind: "video",
    status: "ready",
    url: asset.url,
    contentType: asset.contentType,
    ...(asset.sizeBytes === undefined ? {} : { sizeBytes: asset.sizeBytes }),
    ...(asset.metadata === undefined ? {} : { metadata: { ...asset.metadata } }),
  }
  return { asset: result }
}

function terminalError(job: GenerationJob): Error {
  const message = job.error?.message ?? `video generation ${job.status}`
  return Object.assign(new Error(message), { code: job.error?.code ?? `generation_${job.status}` })
}

function assertJobScope(job: GenerationJob, gameId: string, requestId: string): void {
  if (job.gameId !== gameId || job.requestId !== requestId) throw new TypeError("generation broker returned a job outside the capability scope")
}

/**
 * Projects the durable generation broker as the single extension-platform
 * capability currently supported by this Host. The result is always a
 * host-owned GenerationJob; extensions never receive a provider task id.
 */
export function createGenerationCapabilityBridge(options: GenerationCapabilityBridgeOptions): WorkbenchCapabilityResolver {
  if (!options.broker || typeof options.broker.submit !== "function") throw new TypeError("broker must provide submit")
  if (options.providerId !== undefined) assertNonEmpty(options.providerId, "providerId")
  if (options.pollIntervalMs !== undefined && (!Number.isFinite(options.pollIntervalMs) || options.pollIntervalMs < 0)) throw new TypeError("pollIntervalMs must be a non-negative finite number")
  if (options.sleep !== undefined && typeof options.sleep !== "function") throw new TypeError("sleep must be a function")
  const pollIntervalMs = options.pollIntervalMs ?? 1_000
  const sleep = options.sleep ?? defaultSleep
  return Object.freeze({
    forGame(gameId: string): WorkbenchCapabilities {
      assertNonEmpty(gameId, "gameId")
      return Object.freeze({
        async invoke(id: string, version: number, input: unknown, invocationOptions: CapabilityInvokeOptions = {}): Promise<unknown> {
          if (id !== VIDEO_GENERATION_CAPABILITY.id || version !== VIDEO_GENERATION_CAPABILITY.version) {
            throw new Error(`Capability ${id}@${version} is not available`)
          }
          assertNonEmpty(invocationOptions.requestId, "capability requestId")
          let job = await options.broker.submit({
            gameId,
            requestId: invocationOptions.requestId,
            input: normalizeVideoGenerationInput(input),
            ...(options.providerId === undefined ? {} : { providerId: options.providerId }),
          })
          assertJobScope(job, gameId, invocationOptions.requestId)
          while (job.status === "queued" || job.status === "running" || job.status === "importing") {
            await sleep(pollIntervalMs)
            job = await options.broker.poll({ gameId, requestId: invocationOptions.requestId })
            assertJobScope(job, gameId, invocationOptions.requestId)
          }
          if (job.status === "succeeded") return readyAsset(job)
          throw terminalError(job)
        },
      })
    },
  })
}
