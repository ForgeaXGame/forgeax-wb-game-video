import {
  lstat,
  mkdir,
  open,
  readFile,
  readdir,
  realpath,
  rename,
  unlink,
} from "node:fs/promises"
import { randomUUID } from "node:crypto"
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from "node:path"

import type {
  GameFileCapability,
  ImageGenerationInput,
  MediaCapability,
  ModelCapability,
  ModelGateway,
  TextGenerationInput,
  VideoGenerationInput,
} from "../contracts/adapters.js"
import type { ServiceCapability } from "../contracts/service-binding.js"
import type {
  VideoGenerationGateway,
  WorkbenchCapabilities,
} from "../contracts/generation.js"
import { withGameFileLocks } from "./game-file-lock.js"

/** Backwards-compatible name for the adapter-owned game file authority. */
export type BoundedGameFiles = GameFileCapability

export interface WorkbenchExtensionContext {
  readonly gameId: string
  readonly gameRoot: string
  readonly media: MediaCapability
  readonly models: ModelCapability
  readonly videoGeneration: VideoGenerationGateway
  readonly services: ServiceCapability
  readonly capabilities: WorkbenchCapabilities
  readonly files: BoundedGameFiles
}

export type WorkbenchToolHandler = (
  context: WorkbenchExtensionContext,
  args: unknown,
) => unknown | Promise<unknown>

export interface SeedContext extends WorkbenchExtensionContext {}

export type GamePackageSeed = Record<string, unknown>

/** A framework-neutral request delegated to a trusted extension backend. */
export interface WorkbenchExtensionRouterRequest {
  readonly gameId: string
  readonly runtimeId: string
  readonly path: string
  readonly query: Readonly<Record<string, readonly string[]>>
  readonly method: string
  readonly headers: Readonly<Record<string, readonly string[]>>
  readonly body: Uint8Array<ArrayBufferLike>
}

/** Binary-safe result returned by a trusted extension router. */
export interface WorkbenchExtensionRouterResponse {
  readonly status: number
  readonly headers?: Readonly<Record<string, string | readonly string[]>>
  readonly body?: Uint8Array<ArrayBufferLike>
}

export interface WorkbenchExtensionRouter {
  handle(request: WorkbenchExtensionRouterRequest): Promise<WorkbenchExtensionRouterResponse> | WorkbenchExtensionRouterResponse
}

export interface WorkbenchExtensionModule {
  tools?: Record<string, WorkbenchToolHandler>
  gamePackage?: {
    platform: string
    createSeed(context: SeedContext): Promise<GamePackageSeed>
    validateSeed(seed: GamePackageSeed): Promise<void>
  }
  createRouter?: (context: WorkbenchExtensionContext) => WorkbenchExtensionRouter
}

function isWithin(root: string, candidate: string): boolean {
  const path = relative(root, candidate)
  return (
    path === "" ||
    (!isAbsolute(path) && path !== ".." && !path.startsWith(`..${sep}`))
  )
}

function assertRelativePath(relativePath: string): void {
  if (relativePath.length === 0 || isAbsolute(relativePath)) {
    throw new TypeError("Game file path must be a non-empty relative path")
  }
}

function assertRelativeDirectory(relativeDirectory: string): void {
  assertRelativePath(relativeDirectory)
  if (relativeDirectory.split(/[\\/]/u).includes("..")) {
    throw new TypeError("Game file directory must not contain parent traversal")
  }
}

async function resolveExistingGamePath(
  gameRoot: string,
  relativePath: string,
): Promise<string> {
  assertRelativePath(relativePath)
  const root = await realpath(gameRoot)
  const candidate = resolve(root, relativePath)
  if (!isWithin(root, candidate)) {
    throw new TypeError("Game file path is outside the game root")
  }

  const relativeCandidate = relative(root, candidate)
  let cursor = root
  for (const segment of relativeCandidate.split(sep)) {
    cursor = resolve(cursor, segment)
    try {
      if ((await lstat(cursor)).isSymbolicLink()) {
        throw new TypeError("Game file path must not traverse a symlink")
      }
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") {
        break
      }
      throw error
    }
  }
  return candidate
}

function unavailableMedia(): MediaCapability {
  const unavailable = async (): Promise<never> => {
    throw new Error("Media capability is not configured")
  }
  return { list: unavailable, read: unavailable, put: unavailable, delete: unavailable }
}

function unavailableModels(): ModelCapability {
  const unavailable = async (): Promise<never> => {
    throw new Error("Model gateway is not configured")
  }
  return {
    generateText: unavailable,
    generateImage: unavailable,
    generateVideo: unavailable,
  }
}

function unavailableVideoGeneration(): VideoGenerationGateway {
  const unavailable = async (): Promise<never> => {
    throw new Error("Video generation capability is not configured")
  }
  return { start: unavailable, get: unavailable, cancel: unavailable, generateVideo: unavailable }
}

function unavailableServices(): ServiceCapability {
  const unavailable = async (): Promise<never> => {
    throw new Error("Service capability is not configured")
  }
  return { scope: unavailable, request: unavailable, stageMedia: unavailable }
}

function unavailableCapabilities(): WorkbenchCapabilities {
  return {
    async invoke(): Promise<never> {
      throw new Error("Extension capabilities are not configured")
    },
  }
}

export interface CreateWorkbenchExtensionContextOptions {
  readonly gameId: string
  readonly gameRoot: string
  readonly media?: MediaCapability
  readonly models?: ModelGateway
  readonly videoGeneration?: VideoGenerationGateway
  readonly services?: ServiceCapability
  readonly capabilities?: WorkbenchCapabilities
  /** Exact adapter-owned authority for the lifetime of the enclosing scope. */
  readonly files?: GameFileCapability
}

/**
 * Creates a pathname-bounded file helper for development and isolated tests.
 *
 * This helper is not rename-stable and must not be used by a production host.
 * Production hosts obtain GameFileCapability from WorkspaceAdapter.withGameRoot.
 */
export function createPathBoundedGameFilesForDevelopment(
  gameRoot: string,
): GameFileCapability {
  return {
    async list(relativeDirectory) {
      assertRelativeDirectory(relativeDirectory)
      const path = await resolveExistingGamePath(
        gameRoot,
        relativeDirectory,
      )
      try {
        if (!(await lstat(path)).isDirectory()) {
          throw new TypeError("Game file path is not a directory")
        }
        return (await readdir(path, { withFileTypes: true }))
          .filter((entry) => !entry.isSymbolicLink())
          .map((entry) => entry.name)
          .sort()
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") {
          return []
        }
        throw error
      }
    },
    async read(relativePath) {
      const path = await resolveExistingGamePath(gameRoot, relativePath)
      try {
        return new Uint8Array(await readFile(path))
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") {
          return null
        }
        throw error
      }
    },
    async write(relativePath, contents) {
      const path = await resolveExistingGamePath(gameRoot, relativePath)
      await mkdir(dirname(path), { recursive: true })
      const checked = await resolveExistingGamePath(gameRoot, relativePath)
      const temp = join(dirname(checked), `.${randomUUID()}.${basename(checked)}.tmp`)
      let handle: Awaited<ReturnType<typeof open>> | undefined
      let moved = false
      try {
        handle = await open(temp, "wx", 0o600)
        await handle.writeFile(contents)
        await handle.sync()
        await handle.close()
        handle = undefined
        await rename(temp, checked)
        moved = true
        const directory = await open(dirname(checked), "r")
        try {
          await directory.sync()
        } finally {
          await directory.close()
        }
      } finally {
        await handle?.close()
        if (!moved) {
          await unlink(temp).catch((error: unknown) => {
            if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error
          })
        }
      }
    },
    async delete(relativePath) {
      const path = await resolveExistingGamePath(gameRoot, relativePath)
      try {
        await unlink(path)
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") {
          return
        }
        throw error
      }
      const directory = await open(dirname(path), "r")
      try {
        await directory.sync()
      } finally {
        await directory.close()
      }
    },
    async withLocks(keys, operation) {
      return withGameFileLocks(gameRoot, keys, operation)
    },
  }
}

/** Creates the capability-bounded context passed to trusted tool handlers. */
export function createWorkbenchExtensionContext(
  options: CreateWorkbenchExtensionContextOptions,
): WorkbenchExtensionContext {
  const videoGeneration = options.videoGeneration ?? unavailableVideoGeneration()
  const unavailable = unavailableModels()
  const models: ModelCapability = Object.freeze({
    generateText: options.models
      ? (input: TextGenerationInput) => options.models!.generateText(options.gameId, input)
      : unavailable.generateText,
    generateImage: options.models
      ? (input: ImageGenerationInput) => options.models!.generateImage(options.gameId, input)
      : unavailable.generateImage,
    // Video must go through the host broker, never the product's legacy gateway.
    generateVideo: (input: VideoGenerationInput) => videoGeneration.generateVideo(input),
  })

  return Object.freeze({
    gameId: options.gameId,
    gameRoot: options.gameRoot,
    media: options.media ?? unavailableMedia(),
    models,
    videoGeneration,
    services: options.services ?? unavailableServices(),
    capabilities: options.capabilities ?? unavailableCapabilities(),
    files: options.files ?? createPathBoundedGameFilesForDevelopment(options.gameRoot),
  })
}

/** Defines the small, product-neutral module surface accepted from a backend. */
export function defineWorkbenchExtension(
  extension: WorkbenchExtensionModule,
): WorkbenchExtensionModule {
  if (typeof extension !== "object" || extension === null) {
    throw new TypeError("Workbench extension must be an object")
  }
  if (
    extension.tools !== undefined &&
    (typeof extension.tools !== "object" || extension.tools === null)
  ) {
    throw new TypeError("Workbench extension tools must be an object")
  }
  for (const [toolId, handler] of Object.entries(extension.tools ?? {})) {
    if (toolId.length === 0 || typeof handler !== "function") {
      throw new TypeError("Workbench extension tools must map ids to functions")
    }
  }
  if (extension.createRouter !== undefined && typeof extension.createRouter !== "function") {
    throw new TypeError("Workbench extension createRouter must be a function")
  }
  return extension
}
