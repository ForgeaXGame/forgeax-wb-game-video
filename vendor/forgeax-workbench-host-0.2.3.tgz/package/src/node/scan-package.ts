import { createRequire } from "node:module"
import { lstat, readFile, realpath, stat } from "node:fs/promises"
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path"
import { fileURLToPath } from "node:url"

import type { ExtensionSource } from "./extension-source.js"
import {
  mergeManifestLayers,
  type ExtensionManifest,
} from "./merge-manifest.js"

const require = createRequire(import.meta.url)

export interface ScannedExtension {
  readonly manifest: ExtensionManifest
  readonly packageRoot: string
  readonly frontendEntry: string
  readonly backendEntry: string
}

function isWithin(root: string, candidate: string): boolean {
  const path = relative(root, candidate)
  return (
    path === "" ||
    (!isAbsolute(path) && path !== ".." && !path.startsWith(`..${sep}`))
  )
}

async function resolveDirectoryRoot(path: string): Promise<string> {
  const root = await realpath(path)
  if (!(await stat(root)).isDirectory()) {
    throw new TypeError(`Extension source is not a directory: ${path}`)
  }
  return root
}

async function resolvePackageRoot(specifier: string): Promise<string> {
  const packageName = packageSpecifierName(specifier)
  try {
    const resolvedExport = require.resolve(specifier)
    const packageJson = await findPackageJson(resolvedExport, packageName)
    return resolveDirectoryRoot(dirname(await realpath(packageJson)))
  } catch {
    const resolvedExport = await resolveEsmExport(specifier, packageName)
    const packageJson = await findPackageJson(resolvedExport, packageName)
    return resolveDirectoryRoot(dirname(await realpath(packageJson)))
  }
}

/** Resolves an ESM public export without executing an extension module. */
async function resolveEsmExport(
  specifier: string,
  packageName: string,
): Promise<string> {
  // Validate the requested subpath against the package export map before
  // asking the runtime to resolve it. Bun and some test runners can return a
  // physical path for an invalid subpath; accepting that path would defer the
  // error until the extension manifest lookup and hide the stable exports
  // boundary error from callers.
  const packageRoot = await findInstalledPackageRoot(packageName)
  const packageMetadata = JSON.parse(
    await readFile(join(packageRoot, "package.json"), "utf8"),
  ) as { readonly exports?: unknown }
  const suffix = specifier.slice(packageName.length)
  const subpath = suffix.length === 0 ? "." : `.${suffix}`
  const target = importExportTarget(packageMetadata.exports, subpath)
  if (target === undefined) {
    throw new Error(`Package subpath '${subpath}' is not defined by "exports"`)
  }

  // Derive the target from the validated export map. This avoids relying on
  // runtime-specific import.meta.resolve bindings while preserving the
  // package's public subpath boundary.
  return resolve(packageRoot, target)
}

function importExportTarget(exportsField: unknown, subpath: string): string | undefined {
  const entry = isExportMap(exportsField)
    ? exportsField[subpath]
    : subpath === "." ? exportsField : undefined
  if (typeof entry === "string") return entry
  if (!isExportMap(entry)) return undefined
  return typeof entry.import === "string"
    ? entry.import
    : typeof entry.default === "string" ? entry.default : undefined
}

function isExportMap(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value)
}

/** Finds an installed package only after its requested ESM subpath is validated. */
async function findInstalledPackageRoot(packageName: string): Promise<string> {
  let directory = dirname(fileURLToPath(import.meta.url))
  while (true) {
    const candidate = join(directory, "node_modules", packageName)
    try {
      const packageJson = join(candidate, "package.json")
      await stat(packageJson)
      return resolveDirectoryRoot(candidate)
    } catch {
      const parent = dirname(directory)
      if (parent === directory) {
        throw new Error(`Could not resolve package root for extension: ${packageName}`)
      }
      directory = parent
    }
  }
}

function packageSpecifierName(specifier: string): string {
  const segments = specifier.split("/")
  return specifier.startsWith("@") ? segments.slice(0, 2).join("/") : segments[0]
}

async function findPackageJson(
  resolvedExport: string,
  packageName: string,
): Promise<string> {
  let directory = dirname(resolvedExport)
  while (true) {
    const packageJson = join(directory, "package.json")
    try {
      const metadata = JSON.parse(await readFile(packageJson, "utf8")) as {
        name?: unknown
      }
      if (metadata.name === packageName) {
        return packageJson
      }
    } catch {
      // Continue walking until the package root is found.
    }

    const parent = dirname(directory)
    if (parent === directory) {
      throw new Error(`Could not resolve package root for extension: ${packageName}`)
    }
    directory = parent
  }
}

async function resolveSourceRoot(source: ExtensionSource): Promise<string> {
  return source.kind === "package"
    ? resolvePackageRoot(source.specifier)
    : resolveDirectoryRoot(source.path)
}

function normalizeRelativeEntry(entry: string): string {
  return entry.split("\\").join("/")
}

async function resolveEntry(root: string, entry: string): Promise<string> {
  const normalized = normalizeRelativeEntry(entry)
  const lexicalPath = resolve(root, normalized)
  if (!isWithin(root, lexicalPath)) {
    throw new Error(`Extension entry is outside extension root: ${entry}`)
  }

  const relativeEntry = relative(root, lexicalPath)
  let cursor = root
  for (const segment of relativeEntry.split(sep)) {
    cursor = resolve(cursor, segment)
    if ((await lstat(cursor)).isSymbolicLink()) {
      throw new Error(`Extension entry must not traverse a symlink: ${entry}`)
    }
  }

  const resolvedEntry = await realpath(lexicalPath)
  if (!isWithin(root, resolvedEntry)) {
    throw new Error(`Extension entry is outside extension root: ${entry}`)
  }
  if (!(await stat(resolvedEntry)).isFile()) {
    throw new TypeError(`Extension entry is not a file: ${entry}`)
  }

  return relativeEntry.split(sep).join("/")
}

async function resolveManifestPath(root: string): Promise<string> {
  const manifestPath = resolve(root, "forgeax-extension.json")
  if (!isWithin(root, manifestPath)) {
    throw new Error("Extension manifest is outside extension root")
  }
  if ((await lstat(manifestPath)).isSymbolicLink()) {
    throw new Error("Extension manifest must not traverse a symlink")
  }

  const resolvedManifest = await realpath(manifestPath)
  if (!isWithin(root, resolvedManifest)) {
    throw new Error("Extension manifest is outside extension root")
  }
  if (!(await stat(resolvedManifest)).isFile()) {
    throw new TypeError("Extension manifest is not a file")
  }
  return resolvedManifest
}

/** Resolves and validates one package or directory extension source. */
export async function scanExtensionSource(
  source: ExtensionSource,
): Promise<ScannedExtension> {
  const packageRoot = await resolveSourceRoot(source)
  const manifestPath = await resolveManifestPath(packageRoot)

  const manifest = mergeManifestLayers([
    JSON.parse(await readFile(manifestPath, "utf8")) as unknown,
  ])
  const [frontendEntry, backendEntry] = await Promise.all([
    resolveEntry(packageRoot, manifest.entry.frontend),
    resolveEntry(packageRoot, manifest.entry.backend),
  ])

  return { manifest, packageRoot, frontendEntry, backendEntry }
}
